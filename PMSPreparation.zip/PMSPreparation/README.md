# PMS Preparation

One Android app (Kotlin + Jetpack Compose) that joins your separate apps. Home page = cards grouped by category;
tapping a card opens that app's own original dashboard; Back on its dashboard returns to the home page.

## Merged so far
| Card | Package (code kept as-is) | Assets |
|---|---|---|
| Complete English Grammar | `com.completeenglishgrammar.app` | `assets/grammar/` |
| PMS/CSS Essay | `com.pmscss.essay` | `assets/essay/` |
| Pak-Studies 1 (PMSNotes) | `com.pmsnotes.pakstudies` | `assets/pakstudies/` |
| Social Work Academy | `com.socialwork.academy` | `assets/socialwork/` |

Package/applicationId: `com.pmscss.essay` (same as the Essay app, so it installs over it and keeps its saved essays/bookmarks).

## Home page features (hub)
Animated splash, welcome (asks your name), 3-page onboarding (Skip / Next / Get Started), first-time guide, greeting with name,
app search, widgets (continue, study streak, study timer, quote), dark mode, 5 colour themes, text size.
Settings of the home page do not change the merged apps; each keeps its own settings. Code: `com/pmspreparation/app/`.

## More home-page features
Favorites (star on an app), exam countdown, daily goal, word of the day, global search (also inside the apps' content),
weekly report, study calendar, badges, mixed MCQ test (Pak-Studies + Social Work + Grammar), notes, checklist, pomodoro,
daily reminder, PIN lock, backup/restore of all app data. Urdu font: `res/font/jameel_noori_nastaleeq.ttf` (`UrduFont`).

## Syllabus tab and study tools (latest)
- Bottom bar: Home | Syllabus. Syllabus data lives in `assets/syllabus/*.json` (any number of files; each holds `groups` of `papers`).
- Tools on the home page: Study planner (coverage, plan, weekly target), Revision (1/3/7/30 day schedule), Flashcards (spaced repetition),
  Daily challenge, Timed paper, Mistake notebook, Saved items (bookmarks with notes), Past papers (your own list), Current affairs diary,
  Essay practice, Timetable, Prayer-time blocks, Focus mode, Level and points, Export to PDF.
- Home-screen widget (streak and today's progress), feedback / rate / share buttons in Settings, content width capped on tablets.
- Generic saved lists use `HubPrefs.recs(name)` (`HubRec`), so new list features need no new storage code.

## Social Work Academy: Paper 1 / Paper 2 design
- Paper screen: navy bar, tabs Topics / Saved / Course Outline / Topic Outline / Study / Guide, chapter bands, numbered topic cards, search by topic or term.
- Topic screen: Save and Mark studied buttons, tabs Notes (Short / Long detail) / Key Points / MCQs / Vocabulary / My Notes. Files: `ui/screens/PaperUi.kt`, `PaperTopicsScreen.kt`, `TopicDetailScreen.kt`.

## More study tools (third batch)
- Weak topics, Smart revision plan, Topic-wise test, Saved questions (star while solving), Open recall, Essay outline builder,
  Precis and comprehension, Writing checker, Quick facts, first-time tips for every tool.
- Settings: Night dark mode (7 PM to 6 AM), Urdu home page and tabs, home widget order and visibility, reminder message, offline status.
- Streak freeze (one missed day forgiven, at most once every 7 days), exam countdown widget, JSON and CSV export,
  highlight button on Social Work notes.

## Adding the next app
1. Copy its Kotlin package into `app/src/main/java/` (keep its package name).
2. Move its assets into `app/src/main/assets/<name>/` and change its `assets.open("x.json")` to `"<name>/x.json"`.
3. Turn its MainActivity content into `fun XxxApp(onExit: () -> Unit)` and call `onExit()` from a `BackHandler` on its dashboard (see `EssayApp.kt`, `GrammarApp.kt`).
4. Merge its manifest bits (permissions, providers) and any res files whose names clash (theme/color names).
5. Add one `SubApp(...)` entry in `com/pmspreparation/app/SubApps.kt`.

## Build the APK (GitHub Actions)
Push to a GitHub repo -> Actions -> **Build APK** -> download **PMS-Preparation-apk** from Artifacts.
Versions: AGP 8.9.2, Kotlin 2.1.20, Gradle 8.14.3, compileSdk 35, minSdk 26.

## Apps merged (latest batch)
Added: Pak-Studies II (`com.pakstudies2.app`), Economy and Development (`com.pmsnotes.economy`),
International Affairs (`com.pmsprep.app`), Islamic Studies Academy (`com.islamicstudies.academy`, uses Room + KSP).
Each app's assets live in their own folder (`assets/pakstudies2`, `economy`, `intlaffairs`, `islamic`).
Removed: Social Work offline note / offline onboarding page / profile screen, and the Complete English Grammar name screen (the hub name is used).

International Affairs: Urdu is now an `EN | اردو` switch in the topic top bar. It translates the whole topic with ML Kit (model downloads once, results are saved on the phone). The Gemini/Claude Urdu button was removed; "Extend online" (with its API key) stays.

Vocabulary tab (third bottom tab): `assets/hubvocab/vocab.json` holds 3,956 words/terms merged from Essay, Grammar, Economy, Islamic Studies, International Affairs, Pak-Studies 1 and II. 1,018 general words also have synonyms, antonyms, word forms and idioms (written by Claude, check before relying on them). Screen: `HubVocab.kt`. Saved/learned words are kept in the hub record lists `vw` and `vl`.

Home page: the Tools section is now split into five tabs (Practice, Plan, Writing, Progress, Study aids).

Practice and writing batch (tools): Vocabulary quiz, Sentence correction, Fill in the blank, Idiom test, One-word substitution, Subject-wise mock, True/False, Speed round, Paper solve and mark (HubPractice2.kt); Essay planner, Thesis and intro builder, Paragraph practice, Writing timer, Linking words, Quotes bank, Templates, Precis checker, My essays, Dictation, Model essays (HubWrite2.kt). MCQ sources now include Pak-Studies II, Economy, International Affairs and Islamic Studies (HubContent). Writing check now also flags passive voice.

Urdu to English practice (Language tab): 30 graded items, mistake feedback, method guide, machine translation via ML Kit (HubUrduEnglish.kt, assets/hubtranslate).
