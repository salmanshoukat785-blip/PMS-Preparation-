# PMS Preparation

One Android app (Kotlin + Jetpack Compose) that joins your separate apps. Home page = cards grouped by category;
tapping a card opens that app's own original dashboard; Back on its dashboard returns to the home page.

## Merged so far
| Card | Package (code kept as-is) | Assets |
|---|---|---|
| Complete English Grammar | `com.completeenglishgrammar.app` | `assets/grammar/` |
| PMS/CSS Essay | `com.pmscss.essay` | `assets/essay/` |

Package/applicationId: `com.pmscss.essay` (same as the Essay app, so it installs over it and keeps its saved essays/bookmarks).

## Adding the next app
1. Copy its Kotlin package into `app/src/main/java/` (keep its package name).
2. Move its assets into `app/src/main/assets/<name>/` and change its `assets.open("x.json")` to `"<name>/x.json"`.
3. Turn its MainActivity content into `fun XxxApp(onExit: () -> Unit)` and call `onExit()` from a `BackHandler` on its dashboard (see `EssayApp.kt`, `GrammarApp.kt`).
4. Merge its manifest bits (permissions, providers) and any res files whose names clash (theme/color names).
5. Add one `SubApp(...)` entry in `com/pmspreparation/app/SubApps.kt`.

## Build the APK (GitHub Actions)
Push to a GitHub repo -> Actions -> **Build APK** -> download **PMS-Preparation-apk** from Artifacts.
Versions: AGP 8.6.0, Kotlin 2.0.20, Gradle 8.9, compileSdk 35, minSdk 26.
