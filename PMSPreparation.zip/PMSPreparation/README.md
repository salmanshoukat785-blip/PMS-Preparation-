# PMS Preparation

One Android app (Kotlin + Jetpack Compose) that joins your separate apps. Home page = cards grouped by category;
tapping a card opens that app's own original dashboard; Back on its dashboard returns to the home page.

## Merged so far
| Card | Package (code kept as-is) | Assets |
|---|---|---|
| Complete English Grammar | `com.completeenglishgrammar.app` | `assets/grammar/` |
| PMS/CSS Essay | `com.pmscss.essay` | `assets/essay/` |
| Pak-Studies 1 (PMSNotes) | `com.pmsnotes.pakstudies` | `assets/pakstudies/` |
| Social Work Academy | `com.socialwork.academy` | `assets/socialwork/` |

Package/applicationId: `com.pmscss.essay` (same as the Essay app, so it installs over it and keeps its saved essays/bookmarks).

## Home page features (hub)
Animated splash, welcome (asks your name), 3-page onboarding (Skip / Next / Get Started), first-time guide, greeting with name,
app search, widgets (continue, study streak, study timer, quote), dark mode, 5 colour themes, text size.
Settings of the home page do not change the merged apps; each keeps its own settings. Code: `com/pmspreparation/app/`.

## Adding the next app
1. Copy its Kotlin package into `app/src/main/java/` (keep its package name).
2. Move its assets into `app/src/main/assets/<name>/` and change its `assets.open("x.json")` to `"<name>/x.json"`.
3. Turn its MainActivity content into `fun XxxApp(onExit: () -> Unit)` and call `onExit()` from a `BackHandler` on its dashboard (see `EssayApp.kt`, `GrammarApp.kt`).
4. Merge its manifest bits (permissions, providers) and any res files whose names clash (theme/color names).
5. Add one `SubApp(...)` entry in `com/pmspreparation/app/SubApps.kt`.

## Build the APK (GitHub Actions)
Push to a GitHub repo -> Actions -> **Build APK** -> download **PMS-Preparation-apk** from Artifacts.
Versions: AGP 8.9.2, Kotlin 2.1.20, Gradle 8.14.3, compileSdk 35, minSdk 26.
