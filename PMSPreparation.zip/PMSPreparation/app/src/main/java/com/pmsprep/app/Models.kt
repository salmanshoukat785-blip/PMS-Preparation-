package com.pmsprep.app

data class IndexEntry(val no: Int, val section: String, val title: String, val file: String?)
data class SubSection(val title: String, val short: String, val long: String, val keyPoints: List<String>)
data class ChronoItem(val year: String, val event: String)
data class Mcq(val q: String, val options: List<String>, val answer: Int, val explanation: String = "", val topicNo: Int = 0, val idx: Int = 0)
data class VocabItem(val term: String, val meaning: String)
data class Extra(val title: String, val text: String)
data class Topic(
    val no: Int,
    val title: String,
    val overview: String,
    val sections: List<SubSection>,
    val chronology: List<ChronoItem>,
    val facts: String,
    val factsTitle: String,
    val extras: List<Extra>,
    val references: List<String>,
    val revision: List<String>,
    val note: String,
    val mcqs: List<Mcq>,
    val vocab: List<VocabItem>
)
