package com.pmsprep.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast

fun copyText(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

fun shareText(ctx: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(send, "Share"))
}

fun sectionText(topicTitle: String, s: SubSection): String = buildString {
    append(s.title).append(" (").append(topicTitle).append(")\n\n")
    append(s.short).append("\n\n").append(s.long)
    if (s.keyPoints.isNotEmpty()) {
        append("\n\nKey points:")
        s.keyPoints.forEach { append("\n\u2022 ").append(it) }
    }
    append("\n\n- PMS International Affairs app")
}

fun mcqText(q: Mcq): String = buildString {
    append(q.q)
    q.options.forEachIndexed { i, o -> append("\n").append("ABCD"[i]).append(". ").append(o) }
    append("\nAnswer: ").append("ABCD"[q.answer])
    if (q.explanation.isNotBlank()) append("\n").append(q.explanation)
}

fun vocabText(v: VocabItem): String = "${v.term}: ${v.meaning}"
