package com.pmsprep.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// ---------- Splash ----------

@Composable
fun SplashScreen() {
    var shown by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(Unit) { shown = true }
    val a by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = androidx.compose.animation.core.tween(800),
        label = "splash"
    )
    val navy = androidx.compose.ui.graphics.Color(0xFF1F3A5F)
    val navyDark = androidx.compose.ui.graphics.Color(0xFF14263F)
    Box(
        modifier = Modifier.fillMaxSize().background(
            androidx.compose.ui.graphics.Brush.verticalGradient(listOf(navyDark, navy))
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.alpha(a)
        ) {
            Box(
                modifier = Modifier
                    .size(128.dp)
                    .background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(text = "\uD83C\uDF0D", fontSize = 60.sp) }
            Spacer(Modifier.height(24.dp))
            Text(
                text = "PMS International Affairs",
                color = androidx.compose.ui.graphics.Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Punjab PMS \u00B7 Paper 9 study companion",
                color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f)
            )
            Spacer(Modifier.height(28.dp))
            androidx.compose.material3.LinearProgressIndicator(
                modifier = Modifier.width(120.dp),
                color = androidx.compose.ui.graphics.Color.White,
                trackColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.25f)
            )
        }
    }
}

// ---------- Onboarding ----------

private data class IntroPage(val icon: String, val title: String, val body: String)

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val pages = remember {
        listOf(
            IntroPage(
                "\uD83D\uDCDA", "Topic-wise notes",
                "Every syllabus topic has short and detailed notes, key points, timelines and current developments. Tap the star to save any note."
            ),
            IntroPage(
                "\uD83D\uDCDD", "MCQ practice",
                "Use the MCQs tab for topic-wise quizzes with instant answers and explanations, timed mock tests, and a bank of your wrong answers."
            ),
            IntroPage(
                "\uD83D\uDCA1", "Difficult words explained",
                "Hard terms are underlined inside the notes. Tap any underlined word to see its meaning in Roman Urdu."
            ),
            IntroPage(
                "\u2705", "Revise and track",
                "Mark topics as revised, search across all notes, and copy or share any note with friends."
            ),
            IntroPage(
                "\uD83C\uDFA8", "Make it yours",
                "Choose light or dark mode, a colour palette and your preferred text size from More > Settings."
            )
        )
    }
    var i by remember { mutableIntStateOf(0) }
    val last = i == pages.lastIndex
    val p = pages[i]
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onDone) { Text("Skip") }
        }
        Column(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = p.icon, fontSize = 72.sp)
            Spacer(Modifier.height(20.dp))
            Text(
                text = p.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Text(text = p.body, textAlign = TextAlign.Center)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            pages.indices.forEach { idx ->
                Box(
                    Modifier
                        .padding(4.dp)
                        .size(if (idx == i) 12.dp else 8.dp)
                        .background(
                            if (idx == i) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline,
                            CircleShape
                        )
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                enabled = i > 0,
                onClick = { i-- },
                modifier = Modifier.weight(1f)
            ) { Text("Back") }
            Button(
                onClick = { if (last) onDone() else i++ },
                modifier = Modifier.weight(1f)
            ) { Text(if (last) "Get started" else "Next") }
        }
    }
}

// ---------- More tab ----------

@Composable
private fun MenuCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text = icon, fontSize = 26.sp, modifier = Modifier.padding(end = 14.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun MoreTab(open: (Screen) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("More")
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { MenuCard("\u2699", "Settings", "Theme, colours, text size, reset") { open(Screen.Settings) } }
            item { MenuCard("\uD83D\uDCD6", "User guide", "How to use every part of the app") { open(Screen.Guide) } }
            item { MenuCard("\uD83D\uDC4B", "Show intro", "Replay the welcome screens") { open(Screen.Intro) } }
            item { MenuCard("\u2139", "About app", "Version, purpose and disclaimer") { open(Screen.About) } }
        }
    }
}

// ---------- Settings ----------

@Composable
fun SettingsScreen(state: AppState, back: () -> Unit, open: (Screen) -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Settings", onBack = back)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("Theme", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Auto", "Light", "Dark").forEachIndexed { idx, label ->
                    FilterChip(
                        selected = state.themeMode == idx,
                        onClick = { state.changeTheme(idx) },
                        label = { Text(label) }
                    )
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Colour palette", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                palettes.forEachIndexed { idx, p ->
                    val selected = state.palette == idx
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { state.changePalette(idx) }
                    ) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .background(p.light, CircleShape)
                                .then(
                                    if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                    else Modifier
                                )
                        )
                        Text(text = p.name, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Text size", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Slider(
                value = state.fontScale,
                onValueChange = { state.changeFontScale(it) },
                valueRange = 0.8f..1.5f,
                steps = 6
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "${(state.fontScale * 100).roundToInt()}%", modifier = Modifier.weight(1f))
                TextButton(onClick = { state.changeFontScale(1f) }) { Text("Reset size") }
            }
            Card(Modifier.fillMaxWidth()) {
                Text(
                    text = "Sample: Globalisation refers to the growing interconnectedness of states, economies and societies.",
                    modifier = Modifier.padding(14.dp)
                )
            }

            Spacer(Modifier.height(24.dp))
            OnlineSettings(state)

            Spacer(Modifier.height(24.dp))
            Text("More", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { open(Screen.Intro) }, modifier = Modifier.fillMaxWidth()) {
                Text("Show intro again")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { open(Screen.Guide) }, modifier = Modifier.fillMaxWidth()) {
                Text("User guide")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Reset saved notes and revised marks")
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Reset progress?") },
            text = { Text("This clears your saved notes and revised marks on this device.") },
            confirmButton = {
                TextButton(onClick = { state.resetProgress(); confirm = false }) { Text("Reset") }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("Cancel") }
            }
        )
    }
}

// ---------- User guide ----------

private val guideItems = listOf(
    "Getting started" to "Open the Topics tab to see all 46 syllabus topics. Topics marked Ready have notes; Pending topics will arrive in app updates.",
    "Reading notes" to "Open a topic and read the short summary of each sub-section. Tap Show detail for the full explanation and key points.",
    "Difficult words" to "Hard terms are underlined inside the notes. Tap an underlined word to see its meaning, and tap Copy in that box if you want to keep it.",
    "MCQs" to "Open the MCQs tab for a mixed quiz or a topic-wise quiz. Tap an option to see the correct answer and explanation at once. Wrong answers can be retried at the end.",
    "Wrong answers bank" to "Every MCQ you get wrong is saved in the MCQs tab. Practise them there; answering correctly removes a question from the bank.",
    "Timed mock test" to "Pick 10, 25 or 50 questions and take an exam-style test with a countdown of one minute per question. Answers appear only after you submit, with a topic-wise score and a review of your mistakes.",
    "Quick revision" to "In the Revise tab, open Quick revision cards and swipe left or right through the key points and revision points of every topic. Use the chips to pick one topic or shuffle the cards.",
    "Master timeline" to "The Revise tab also has one timeline of all dated events, sorted by year. Filter it by topic or by region.",
    "Outlines" to "Each topic has a short outline in the Revise tab: an introduction and the main points. Tap a point to open its key points, or Copy and Share the outline.",
    "Saving notes" to "Tap the star on a note to save it. Find all saved notes in the Saved tab.",
    "Copy and share" to "Use Copy to put a note or a word meaning on the clipboard, and Share to send it through any app on your phone.",
    "Dates and facts" to "Where a topic has a timeline, tap Dates. Facts, current developments, references and revision points appear at the bottom of the topic.",
    "Revision tracking" to "Tap Mark as revised inside a topic. Your progress shows at the top of the Topics tab.",
    "Spaced revision" to "After you mark a topic revised, the app schedules reviews after 3, 7 and 15 days. Due topics appear at the top of the Topics tab; open the topic and tap Mark reviewed.",
    "Search" to "Type in the search box on the Topics tab to search all notes.",
    "Settings" to "In More > Settings you can change the theme, colour palette and text size, or reset your progress.",
    "Updating content" to "New topics come with new versions of the app. Install the latest APK; your saved notes and progress stay on your phone."
)

@Composable
fun GuideScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("User guide", onBack = back)
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(guideItems) { (title, body) ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(text = title, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(text = body)
                    }
                }
            }
        }
    }
}

// ---------- About ----------

@Composable
fun AboutScreen(state: AppState, back: () -> Unit) {
    val ctx = LocalContext.current
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0"
        } catch (e: Exception) {
            "1.0"
        }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("About app", onBack = back)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(
                text = "PMS International Affairs",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(text = "Version $version")
            Spacer(Modifier.height(12.dp))
            Text(
                "A study companion for Punjab PMS Paper 9 (International Affairs): " +
                    "topic-wise notes, timelines, meanings of difficult terms and MCQ practice " +
                    "with mock tests. " +
                    "It works fully offline."
            )
            Spacer(Modifier.height(12.dp))
            Text("Topics added: ${state.topics.size} of ${state.index.size}", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Disclaimer: This is an independent study aid, not an official PPSC publication. " +
                    "Check the latest official PPSC syllabus before the examination, and re-verify " +
                    "current-affairs figures and developments, which can change quickly.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
