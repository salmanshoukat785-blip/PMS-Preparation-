package com.pmsprep.app

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

data class PaletteDef(
    val name: String,
    val light: Color,
    val lightContainer: Color,
    val dark: Color,
    val darkContainer: Color
)

val palettes = listOf(
    PaletteDef("Navy", Color(0xFF1F3A5F), Color(0xFFE3EDF7), Color(0xFF9CC3EB), Color(0xFF1F3A5F)),
    PaletteDef("Green", Color(0xFF2E6B3E), Color(0xFFD1EBD6), Color(0xFF9ED3A8), Color(0xFF2E6B3E)),
    PaletteDef("Maroon", Color(0xFF8A2B3A), Color(0xFFF5D6DA), Color(0xFFE7A3AD), Color(0xFF8A2B3A)),
    PaletteDef("Teal", Color(0xFF00695C), Color(0xFFCCEBE6), Color(0xFF80CBC4), Color(0xFF00695C))
)

fun colorSchemeFor(index: Int, dark: Boolean): ColorScheme {
    val p = palettes.getOrElse(index) { palettes[0] }
    return if (dark) {
        darkColorScheme(
            primary = p.dark,
            onPrimary = Color(0xFF101418),
            background = Color(0xFF0F1720),
            surface = Color(0xFF16202B),
            primaryContainer = p.darkContainer,
            onPrimaryContainer = Color.White,
            secondaryContainer = p.darkContainer,
            onSecondaryContainer = Color.White
        )
    } else {
        lightColorScheme(
            primary = p.light,
            background = Color(0xFFFFFBFE),
            surface = Color(0xFFFFFBFE),
            primaryContainer = p.lightContainer,
            onPrimaryContainer = Color(0xFF10212F),
            secondaryContainer = p.lightContainer,
            onSecondaryContainer = Color(0xFF10212F)
        )
    }
}

/** Colour for top bars and banners: strong primary in light mode, the deep container in dark mode (keeps white text readable). */
@androidx.compose.runtime.Composable
fun barColor(): Color =
    if (androidx.compose.material3.MaterialTheme.colorScheme.background.luminance() < 0.5f)
        androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer
    else androidx.compose.material3.MaterialTheme.colorScheme.primary
