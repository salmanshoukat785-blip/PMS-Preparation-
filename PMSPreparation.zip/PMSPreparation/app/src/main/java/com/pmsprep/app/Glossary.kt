package com.pmsprep.app

import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration

private const val TERM_TAG = "term"

/** Builds text where every difficult term is underlined and tagged for tapping. */
fun AppState.glossaryText(text: String, color: Color): AnnotatedString {
    val regex = glossaryRegex ?: return AnnotatedString(text)
    return buildAnnotatedString {
        var last = 0
        for (m in regex.findAll(text)) {
            append(text.substring(last, m.range.first))
            val start = length
            pushStyle(SpanStyle(textDecoration = TextDecoration.Underline, color = color))
            append(m.value)
            pop()
            addStringAnnotation(TERM_TAG, m.groupValues[1].lowercase(), start, length)
            last = m.range.last + 1
        }
        append(text.substring(last))
    }
}

/** Text with underlined difficult words; tapping one shows its meaning. */
@Composable
fun GText(state: AppState, text: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var shown by remember { mutableStateOf<VocabItem?>(null) }
    val color = MaterialTheme.colorScheme.primary
    val annotated = remember(text, color) { state.glossaryText(text, color) }
    val style = LocalTextStyle.current.copy(color = LocalContentColor.current)
    ClickableText(
        text = annotated,
        modifier = modifier,
        style = style,
        onClick = { offset ->
            annotated.getStringAnnotations(TERM_TAG, offset, offset).firstOrNull()?.let { a ->
                shown = state.glossary[a.item]
            }
        }
    )
    shown?.let { v ->
        AlertDialog(
            onDismissRequest = { shown = null },
            title = { Text(text = v.term, fontWeight = FontWeight.Bold) },
            text = { Text(text = v.meaning) },
            confirmButton = { TextButton(onClick = { shown = null }) { Text("Close") } },
            dismissButton = {
                TextButton(onClick = { copyText(ctx, v.term, vocabText(v)) }) { Text("Copy") }
            }
        )
    }
}
