package com.pmsprep.app

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * English to Urdu translation with ML Kit. The Urdu model (about 30 MB) is downloaded once when
 * Urdu is switched on for the first time; after that translating works offline.
 */
object UrduMl {
    private val translator: Translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.URDU)
                .build()
        )
    }

    @Volatile
    private var ready = false

    /** Makes sure the Urdu model is on the phone (downloads it if needed). Throws when it cannot. */
    suspend fun prepare() {
        if (ready) return
        suspendCancellableCoroutine<Unit> { cont ->
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener { if (cont.isActive) cont.resume(Unit) }
                .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
        }
        ready = true
    }

    private suspend fun one(text: String): String = suspendCancellableCoroutine { cont ->
        translator.translate(text)
            .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
            .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
    }

    /** Splits long text into pieces of at most about 400 characters, at line or sentence ends. */
    private fun pieces(text: String): List<String> {
        val out = mutableListOf<String>()
        for (line in text.split("\n")) {
            if (line.isBlank()) { out.add(""); continue }
            var cur = StringBuilder()
            for (sentence in line.split(Regex("(?<=[.!?])\\s+"))) {
                if (cur.isNotEmpty() && cur.length + sentence.length > 400) {
                    out.add(cur.toString()); cur = StringBuilder()
                }
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(sentence)
            }
            if (cur.isNotEmpty()) out.add(cur.toString())
        }
        return out
    }

    suspend fun translate(text: String): String {
        if (text.isBlank()) return text
        val parts = pieces(text)
        val done = mutableListOf<String>()
        for (piece in parts) done.add(if (piece.isBlank()) "" else one(piece))
        return done.joinToString("\n")
    }
}
