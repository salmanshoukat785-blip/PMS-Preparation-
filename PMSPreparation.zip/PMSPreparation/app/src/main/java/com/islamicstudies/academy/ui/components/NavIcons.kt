package com.islamicstudies.academy.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.islamicstudies.academy.ui.LocalStrings
import com.islamicstudies.academy.ui.theme.DeepGreen
import com.islamicstudies.academy.ui.theme.Gold

/** Three vertical bars (progress / statistics icon). */
@Composable
fun BarsIcon(modifier: Modifier = Modifier, color: Color) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val corner = CornerRadius(w * 0.05f, w * 0.05f)
        drawRoundRect(color, Offset(w * 0.12f, h * 0.55f), Size(w * 0.2f, h * 0.35f), corner)
        drawRoundRect(color, Offset(w * 0.40f, h * 0.32f), Size(w * 0.2f, h * 0.58f), corner)
        drawRoundRect(color, Offset(w * 0.68f, h * 0.10f), Size(w * 0.2f, h * 0.80f), corner)
    }
}

/** A small trophy drawn with shapes. */
@Composable
fun TrophyIcon(modifier: Modifier = Modifier, color: Color) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cup = Path().apply {
            moveTo(w * 0.26f, h * 0.14f)
            lineTo(w * 0.74f, h * 0.14f)
            lineTo(w * 0.66f, h * 0.52f)
            lineTo(w * 0.34f, h * 0.52f)
            close()
        }
        drawPath(cup, color)
        drawRect(color, Offset(w * 0.45f, h * 0.52f), Size(w * 0.10f, h * 0.20f))
        drawRoundRect(color, Offset(w * 0.30f, h * 0.72f), Size(w * 0.40f, h * 0.12f), CornerRadius(w * 0.03f, w * 0.03f))
        val handle = Stroke(width = w * 0.06f, cap = StrokeCap.Round)
        drawArc(color, 90f, 180f, false, Offset(w * 0.08f, h * 0.18f), Size(w * 0.28f, h * 0.28f), style = handle)
        drawArc(color, 270f, 180f, false, Offset(w * 0.64f, h * 0.18f), Size(w * 0.28f, h * 0.28f), style = handle)
    }
}

/** Bottom navigation used on the four main screens: home, chapters, progress, settings. */
@Composable
fun AcademyBottomBar(current: String, onTab: (String) -> Unit) {
    val s = LocalStrings.current
    val inactive = Color.White.copy(alpha = 0.85f)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepGreen, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (tab in listOf("home", "chapters", "progress", "settings")) {
            val selected = tab == current
            val tint = if (selected) Gold else inactive
            val label = when (tab) {
                "home" -> s.navHome
                "chapters" -> s.tileChapters
                "progress" -> s.navProgress
                else -> s.tileSettings
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onTab(tab) }
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (tab) {
                    "home" -> Icon(Icons.Filled.Home, contentDescription = null, tint = tint, modifier = Modifier.size(28.dp))
                    "chapters" -> BookIcon(modifier = Modifier.size(28.dp), color = tint)
                    "progress" -> BarsIcon(modifier = Modifier.size(28.dp), color = tint)
                    else -> Icon(Icons.Filled.Settings, contentDescription = null, tint = tint, modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = label,
                    color = tint,
                    fontSize = 12.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
}
