package com.islamicstudies.academy.ui.lesson

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.islamicstudies.academy.data.db.LessonSectionEntity
import com.islamicstudies.academy.data.db.QuestionEntity
import com.islamicstudies.academy.data.glossary.GlossaryStore
import com.islamicstudies.academy.data.glossary.GlossaryTerm
import com.islamicstudies.academy.data.glossary.findGlossaryHits
import com.islamicstudies.academy.data.settings.AppSettings
import com.islamicstudies.academy.data.translate.sha256Hex
import com.islamicstudies.academy.ui.EnStrings
import com.islamicstudies.academy.ui.LocalAppLanguage
import com.islamicstudies.academy.ui.LocalStrings
import com.islamicstudies.academy.ui.UrStrings
import com.islamicstudies.academy.ui.components.LevelChip
import com.islamicstudies.academy.ui.isEnglishPrimary
import com.islamicstudies.academy.ui.pickTitle
import com.islamicstudies.academy.ui.quiz.optionsFor
import com.islamicstudies.academy.ui.screenTitleStyle
import com.islamicstudies.academy.ui.theme.UrduText
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonScreen(
    onBack: () -> Unit,
    onOpenLesson: (String) -> Unit,
    viewModel: LessonViewModel = viewModel()
) {
    val s = LocalStrings.current
    val uiLang = LocalAppLanguage.current

    val heading by viewModel.heading.collectAsStateWithLifecycle()
    val chapter by viewModel.chapter.collectAsStateWithLifecycle()
    val siblings by viewModel.siblings.collectAsStateWithLifecycle()
    val sections by viewModel.sections.collectAsStateWithLifecycle()
    val bookmarked by viewModel.bookmarked.collectAsStateWithLifecycle()
    val completed by viewModel.completed.collectAsStateWithLifecycle()
    val note by viewModel.note.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val translated by viewModel.translated.collectAsStateWithLifecycle()
    val translating by viewModel.translating.collectAsStateWithLifecycle()
    val translateFailed by viewModel.translateFailed.collectAsStateWithLifecycle()

    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showNote by rememberSaveable { mutableStateOf(false) }

    val scale = settings.textScalePercent / 100f
    val contentLang = if (settings.contentLanguage.isBlank()) uiLang else settings.contentLanguage
    val langs = if (contentLang == "both") listOf("ur", "en") else listOf(contentLang)
    val level = settings.level
    // Short = basic text only; Long = basic + intermediate + advanced.
    val isLong = level != "basic"
    val levelsShown = if (isLong) listOf("basic", "intermediate", "advanced") else listOf("basic")
    val questions by viewModel.questions.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(0) }
    val context = LocalContext.current
    val glossary = remember { GlossaryStore.get(context) }
    var shownTerm by remember { mutableStateOf<GlossaryTerm?>(null) }
    val lessonTerms = remember(sections, glossary) {
        sections
            .filter { sec -> sec.kind != "reference" }
            .flatMap { sec -> findGlossaryHits(sec.body, sec.lang, glossary).map { hit -> hit.term } }
            .distinctBy { term -> term.id }
    }

    val index = siblings.indexOfFirst { h -> h.id == viewModel.headingId }
    val prev = if (index > 0) siblings[index - 1] else null
    val next = if (index >= 0 && index < siblings.size - 1) siblings[index + 1] else null

    val headingUr = heading?.titleUr.orEmpty()
    val headingEn = heading?.titleEn.orEmpty()
    val englishFirst = isEnglishPrimary(headingEn, uiLang)
    val chapterTitle = pickTitle(chapter?.titleUr.orEmpty(), chapter?.titleEn.orEmpty(), uiLang)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = chapterTitle,
                        style = screenTitleStyle(),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = s.back
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showNote = true }) {
                        Text(text = "📝", fontSize = 20.sp)
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Text(
                            text = "Aa",
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Heading
            Text(
                text = if (englishFirst) headingEn else headingUr,
                style = if (englishFirst) {
                    MaterialTheme.typography.headlineSmall
                } else {
                    UrduText.title.copy(fontSize = (22 * scale).sp, lineHeight = (46 * scale).sp)
                },
                modifier = Modifier.fillMaxWidth()
            )

            // Save / Mark studied buttons
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { viewModel.toggleBookmark() }, modifier = Modifier.weight(1f)) {
                    Text((if (bookmarked) "★ " else "☆ ") + (if (bookmarked) s.btnSaved else s.btnSave))
                }
                if (completed) {
                    Button(
                        onClick = { viewModel.toggleCompleted() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) { Text(s.studiedLabel) }
                } else {
                    OutlinedButton(onClick = { viewModel.toggleCompleted() }, modifier = Modifier.weight(1f)) {
                        Text(s.markStudied)
                    }
                }
            }

            // Tabs
            val lessonTabs = listOf(s.tabNotes, s.tabKeyPoints, s.tabMcqs, s.tabVocabulary, s.tabMyNotes)
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
                lessonTabs.forEachIndexed { tabIndex, label ->
                    Tab(selected = tab == tabIndex, onClick = { tab = tabIndex }, text = { Text(text = label, maxLines = 1) })
                }
            }

            // Short / Long switch (Notes tab only)
            if (tab == 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = s.shortLabel,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (isLong) FontWeight.Normal else FontWeight.Bold
                    )
                    Switch(
                        checked = isLong,
                        onCheckedChange = { on -> viewModel.setLevel(if (on) "advanced" else "basic") }
                    )
                    Text(
                        text = s.longLabel,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (isLong) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

        // Urdu is missing but English exists: offer an online Urdu translation (Quran/Hadith references stay English).
        val levelEn = sections.filter { sec -> sec.lang == "en" && levelsShown.contains(sec.level) }
        val hasRealUrdu = sections.any { sec -> sec.lang == "ur" && levelsShown.contains(sec.level) }
        val translatable = levelEn.filter { sec -> sec.kind != "reference" && sec.body.isNotBlank() }
        val needsTranslation = langs.contains("ur") && !hasRealUrdu && translatable.isNotEmpty()
        val translationReady = needsTranslation &&
            translatable.all { sec -> translated.containsKey(sha256Hex(sec.body)) }
        // Urdu mode is on and the lesson is English-only: translate automatically, no permission prompt.
        LaunchedEffect(needsTranslation, translationReady, translateFailed, isLong) {
            if (needsTranslation && !translationReady && !translateFailed) {
                viewModel.translateLesson(levelsShown)
            }
        }
        val translatedUrdu = remember(sections, levelsShown, translated, translationReady) {
            if (translationReady) {
                levelEn.map { sec ->
                    if (sec.kind == "reference" || sec.body.isBlank()) {
                        sec
                    } else {
                        sec.copy(lang = "ur", body = translated[sha256Hex(sec.body)].orEmpty())
                    }
                }
            } else {
                emptyList()
            }
        }


            // Content (Notes tab)
            if (tab == 0) {
            val wanted = langs.map { lang ->
                if (lang == "ur" && translationReady) {
                    Pair(lang, translatedUrdu)
                } else {
                    Pair(lang, sections.filter { sec -> sec.lang == lang && levelsShown.contains(sec.level) })
                }
            }
            val otherLangs = listOf("ur", "en").filter { l -> !langs.contains(l) }
            val others = otherLangs.map { lang ->
                Pair(lang, sections.filter { sec -> sec.lang == lang && levelsShown.contains(sec.level) })
            }
            val usingFallback = wanted.all { b -> b.second.isEmpty() } && others.any { b -> b.second.isNotEmpty() }
            val blocks = if (usingFallback) others else wanted
            if (sections.isEmpty()) {
                InfoCard(text = s.noContent, isWarning = false)
            } else if (blocks.all { b -> b.second.isEmpty() }) {
                InfoCard(text = s.noContentForSelection, isWarning = false)
            } else {
                if (needsTranslation && !translationReady) {
                    TranslateCard(
                        working = translating,
                        failed = translateFailed,
                        onTranslate = { viewModel.translateLesson(levelsShown) }
                    )
                } else if (usingFallback) {
                    InfoCard(text = s.fallbackLanguageNotice, isWarning = false)
                }
                for (block in blocks) {
                    if (block.second.isNotEmpty()) {
                        if (langs.size > 1) {
                            Text(
                                text = if (block.first == "ur") "اردو" else "English",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        for (sec in withoutRepeatedReferences(block.second)) {
                            SectionBlock(
                                section = sec,
                                scale = scale,
                                terms = glossary,
                                onTerm = { term -> shownTerm = term }
                            )
                        }
                    }
                }
            }

            // Personal note preview
            if (note.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showNote = true }
                ) {
                    Text(
                        text = "📝  " + note,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            }

            if (tab == 1) {
                val keyPoints = keyPointsOf(
                    if (translationReady && langs.first() == "ur") translatedUrdu else sections,
                    langs.first()
                )
                if (keyPoints.items.isEmpty()) {
                    InfoCard(text = s.noKeyPoints, isWarning = false)
                } else {
                    for (point in keyPoints.items) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "• " + point,
                                style = if (keyPoints.lang == "ur") UrduText.body else MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                }
            }

            if (tab == 2) {
                if (questions.isEmpty()) {
                    InfoCard(text = s.noMcqs, isWarning = false)
                } else {
                    for (question in questions) {
                        McqCard(question = question, uiLang = uiLang)
                    }
                }
            }

            if (tab == 3) {
                if (lessonTerms.isEmpty()) {
                    InfoCard(text = s.noVocab, isWarning = false)
                } else {
                    for (term in lessonTerms) {
                        TermCard(term = term, uiLang = uiLang)
                    }
                }
            }

            if (tab == 4) {
                if (note.isBlank()) {
                    InfoCard(text = s.noNotesYet, isWarning = false)
                } else {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = note,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
                OutlinedButton(onClick = { showNote = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(s.editNoteLabel)
                }
            }

            // Previous / next lesson in this chapter
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (prev != null) {
                    OutlinedButton(onClick = { onOpenLesson(prev.id) }) { Text(s.previous) }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }
                if (next != null) {
                    OutlinedButton(onClick = { onOpenLesson(next.id) }) { Text(s.next) }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }
            }
        }
    }

    val termForDialog = shownTerm
    if (termForDialog != null) {
        AlertDialog(
            onDismissRequest = { shownTerm = null },
            title = { Text(termTitle(termForDialog, uiLang)) },
            text = { Text(termMeaning(termForDialog, uiLang)) },
            confirmButton = { TextButton(onClick = { shownTerm = null }) { Text(s.close) } }
        )
    }
    if (showSettings) {
        ReaderSettingsDialog(
            settings = settings,
            effectiveLanguage = contentLang,
            onDismiss = { showSettings = false },
            onContentLanguage = { l -> viewModel.setContentLanguage(l) },
            onTextScale = { p -> viewModel.setTextScale(p) },
            onTheme = { t -> viewModel.setTheme(t) }
        )
    }
    if (showNote) {
        NoteDialog(
            initial = note,
            onSave = { text -> viewModel.saveNote(text) },
            onDismiss = { showNote = false }
        )
    }
}

@Composable
private fun InfoCard(text: String, isWarning: Boolean) {
    Surface(
        color = if (isWarning) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = if (isWarning) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(14.dp)
        )
    }
}

@Composable
private fun TranslateCard(working: Boolean, failed: Boolean, onTranslate: () -> Unit) {
    val s = LocalStrings.current
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = s.translateNotice,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
            if (working) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text(s.translating, style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                Button(onClick = onTranslate, modifier = Modifier.fillMaxWidth()) { Text(s.translateButton) }
            }
            if (failed && !working) {
                Text(
                    text = s.translateFailed,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            Text(
                text = s.referenceNotTranslated,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
    }
}

@Composable
private fun SectionBlock(
    section: LessonSectionEntity,
    scale: Float,
    terms: List<GlossaryTerm>,
    onTerm: (GlossaryTerm) -> Unit
) {
    val isUrdu = section.lang == "ur"
    val direction = if (isUrdu) LayoutDirection.Rtl else LayoutDirection.Ltr
    val bodyStyle = if (isUrdu) {
        UrduText.body.copy(fontSize = (18 * scale).sp, lineHeight = (44 * scale).sp)
    } else {
        MaterialTheme.typography.bodyLarge.copy(fontSize = (16 * scale).sp, lineHeight = (26 * scale).sp)
    }

    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        when (section.kind) {
            "point" -> Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Spacer(modifier = Modifier.width(4.dp))
                Spacer(
                    modifier = Modifier
                        .padding(top = (10 * scale).dp)
                        .size(7.dp)
                        .background(MaterialTheme.colorScheme.tertiary, CircleShape)
                )
                Spacer(modifier = Modifier.width(12.dp))
                GlossaryText(
                    text = section.body,
                    lang = section.lang,
                    style = bodyStyle,
                    terms = terms,
                    onTerm = onTerm,
                    modifier = Modifier.weight(1f)
                )
            }
            "reference" -> Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (isUrdu) UrStrings.referenceLabel else EnStrings.referenceLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = section.body,
                        style = bodyStyle,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            else -> GlossaryText(
                text = section.body,
                lang = section.lang,
                style = bodyStyle,
                terms = terms,
                onTerm = onTerm,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ReaderSettingsDialog(
    settings: AppSettings,
    effectiveLanguage: String,
    onDismiss: () -> Unit,
    onContentLanguage: (String) -> Unit,
    onTextScale: (Int) -> Unit,
    onTheme: (String) -> Unit
) {
    val s = LocalStrings.current
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text(s.close) } },
        title = { Text(s.readerSettings) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(s.readerLanguageTitle, style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LevelChip(s.langUrdu, effectiveLanguage == "ur", { onContentLanguage("ur") }, Modifier.weight(1f))
                    LevelChip(s.langEnglish, effectiveLanguage == "en", { onContentLanguage("en") }, Modifier.weight(1f))
                    LevelChip(s.langBoth, effectiveLanguage == "both", { onContentLanguage("both") }, Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(s.textSizeTitle, style = MaterialTheme.typography.titleSmall)
                Slider(
                    value = settings.textScalePercent.toFloat(),
                    onValueChange = { v -> onTextScale(v.roundToInt()) },
                    valueRange = 80f..160f,
                    steps = 7
                )
                Text("${settings.textScalePercent}%", style = MaterialTheme.typography.bodySmall)

                Spacer(modifier = Modifier.height(4.dp))
                Text(s.themeTitle, style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LevelChip(s.themeSystem, settings.theme == "system", { onTheme("system") }, Modifier.weight(1f))
                    LevelChip(s.themeLight, settings.theme == "light", { onTheme("light") }, Modifier.weight(1f))
                    LevelChip(s.themeDark, settings.theme == "dark", { onTheme("dark") }, Modifier.weight(1f))
                }
            }
        }
    )
}

@Composable
private fun NoteDialog(
    initial: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val s = LocalStrings.current
    var text by rememberSaveable { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(s.noteTitle) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { v -> text = v },
                placeholder = { Text(s.noteHint) },
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(text)
                onDismiss()
            }) { Text(s.save) }
        },
        dismissButton = {
            Row {
                if (initial.isNotBlank()) {
                    TextButton(onClick = {
                        onSave("")
                        onDismiss()
                    }) { Text(s.deleteNote) }
                }
                TextButton(onClick = onDismiss) { Text(s.cancel) }
            }
        }
    )
}


/** Keeps only the first copy of each reference (the intermediate and advanced levels repeat them). */
private fun withoutRepeatedReferences(list: List<LessonSectionEntity>): List<LessonSectionEntity> {
    val seen = HashSet<String>()
    return list.filter { sec -> sec.kind != "reference" || seen.add(sec.body) }
}

private data class KeyPoints(val lang: String, val items: List<String>)

/** Key points are the sentences of the basic text, in the preferred language when it exists. */
private fun keyPointsOf(sections: List<LessonSectionEntity>, preferred: String): KeyPoints {
    val basic = sections.filter { sec -> sec.level == "basic" && sec.kind != "reference" && sec.body.isNotBlank() }
    val lang = if (basic.any { sec -> sec.lang == preferred }) preferred else (basic.firstOrNull()?.lang ?: preferred)
    val text = basic.filter { sec -> sec.lang == lang }.joinToString(" ") { sec -> sec.body }
    val items = text.split("۔", ". ", "؟", "? ", "\n")
        .map { part -> part.trim().trimEnd('.') }
        .filter { part -> part.length > 3 }
    return KeyPoints(lang = lang, items = items)
}

@Composable
private fun McqCard(question: QuestionEntity, uiLang: String) {
    val s = LocalStrings.current
    var selected by rememberSaveable(question.id) { mutableStateOf(-1) }
    val lang = if (uiLang == "en" && question.textEn.isNotBlank()) {
        "en"
    } else if (question.textUr.isNotBlank()) {
        "ur"
    } else {
        "en"
    }
    val otherLang = if (lang == "ur") "en" else "ur"
    val text = if (lang == "ur") question.textUr else question.textEn
    val options = question.optionsFor(lang).ifEmpty { question.optionsFor(otherLang) }
    val explanation = if (lang == "ur") {
        question.explanationUr.ifBlank { question.explanationEn }
    } else {
        question.explanationEn.ifBlank { question.explanationUr }
    }
    val textStyle = if (lang == "ur") UrduText.subheading else MaterialTheme.typography.titleMedium
    val optionStyle = if (lang == "ur") UrduText.body else MaterialTheme.typography.bodyLarge

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(text = text, style = textStyle, modifier = Modifier.fillMaxWidth())
            options.forEachIndexed { index, option ->
                val answered = selected >= 0
                val container = if (answered && index == question.correctIndex) {
                    MaterialTheme.colorScheme.primaryContainer
                } else if (answered && index == selected) {
                    MaterialTheme.colorScheme.errorContainer
                } else {
                    MaterialTheme.colorScheme.surface
                }
                Surface(
                    color = container,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !answered) { selected = index }
                ) {
                    Text(
                        text = option + if (answered && index == question.correctIndex) "  ✓" else "",
                        style = optionStyle,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
            if (selected >= 0 && explanation.isNotBlank()) {
                Text(
                    text = s.explanationLabel + ": " + explanation,
                    style = optionStyle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}


private fun termTitle(term: GlossaryTerm, uiLang: String): String =
    if (uiLang == "en") term.termEn + " (" + term.termUr + ")" else term.termUr + " (" + term.termEn + ")"

private fun termMeaning(term: GlossaryTerm, uiLang: String): String =
    if (uiLang == "en") term.meaningEn.ifBlank { term.meaningUr } else term.meaningUr.ifBlank { term.meaningEn }

@Composable
private fun TermCard(term: GlossaryTerm, uiLang: String) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = termTitle(term, uiLang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = termMeaning(term, uiLang),
                style = if (uiLang == "en") MaterialTheme.typography.bodyLarge else UrduText.body,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

/** Lesson text in which glossary words are underlined; tapping one opens its meaning. */
@Composable
private fun GlossaryText(
    text: String,
    lang: String,
    style: TextStyle,
    terms: List<GlossaryTerm>,
    onTerm: (GlossaryTerm) -> Unit,
    modifier: Modifier
) {
    val hits = remember(text, lang, terms) { findGlossaryHits(text, lang, terms) }
    if (hits.isEmpty()) {
        Text(text = text, style = style, modifier = modifier)
        return
    }
    val linkColor = MaterialTheme.colorScheme.primary
    val textColor = MaterialTheme.colorScheme.onSurface
    val annotated = remember(text, hits, linkColor) {
        buildAnnotatedString {
            var pos = 0
            for (hit in hits) {
                append(text.substring(pos, hit.start))
                pushStringAnnotation(tag = "term", annotation = hit.term.id)
                pushStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline))
                append(text.substring(hit.start, hit.end))
                pop()
                pop()
                pos = hit.end
            }
            append(text.substring(pos))
        }
    }
    ClickableText(
        text = annotated,
        style = style.copy(color = textColor),
        modifier = modifier,
        onClick = { offset ->
            val tapped = annotated.getStringAnnotations(tag = "term", start = offset, end = offset).firstOrNull()
            if (tapped != null) {
                val term = terms.firstOrNull { t -> t.id == tapped.item }
                if (term != null) onTerm(term)
            }
        }
    )
}
