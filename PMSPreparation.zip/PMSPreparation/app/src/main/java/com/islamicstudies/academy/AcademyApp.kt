package com.islamicstudies.academy

import android.content.Context
import android.content.ContextWrapper
import com.islamicstudies.academy.data.db.AppDatabase
import com.islamicstudies.academy.data.importer.ContentImporter
import com.islamicstudies.academy.data.importer.OutlineImporter
import com.islamicstudies.academy.data.importer.QuestionImporter
import com.islamicstudies.academy.data.settings.SettingsRepository
import com.islamicstudies.academy.reminder.ReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Holder of the Islamic Studies database, settings and content import.
 * In the original app this was the Application class; inside PMS Preparation it is a
 * singleton created on first use (it is a Context so it can be passed wherever one is needed).
 */
class AcademyApp private constructor(base: Context) : ContextWrapper(base) {

    val database: AppDatabase by lazy { AppDatabase.build(this) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _importState = MutableStateFlow<ImportState>(ImportState.Loading)
    val importState: StateFlow<ImportState> = _importState.asStateFlow()
    private var started = false

    /** Schedules the reminder and imports the course content (first run only does real work). Safe to call many times. */
    @Synchronized
    fun start() {
        if (started) return
        started = true
        appScope.launch {
            try {
                val settings = settingsRepository.settings.first()
                if (settings.reminderEnabled) {
                    ReminderScheduler.schedule(this@AcademyApp, settings.reminderHour, settings.reminderMinute)
                }
            } catch (e: Exception) {
                // reminders are optional; ignore
            }
        }
        appScope.launch {
            try {
                OutlineImporter.importIfNeeded(this@AcademyApp, database)
                ContentImporter.importIfNeeded(this@AcademyApp, database)
                QuestionImporter.importIfNeeded(this@AcademyApp, database)
                _importState.value = ImportState.Ready
            } catch (e: Exception) {
                _importState.value = ImportState.Failed(e.message ?: e.javaClass.simpleName)
            }
        }
    }

    companion object {
        @Volatile
        private var instance: AcademyApp? = null

        fun get(context: Context): AcademyApp =
            instance ?: synchronized(this) {
                instance ?: AcademyApp(context.applicationContext).also { instance = it }
            }
    }
}
