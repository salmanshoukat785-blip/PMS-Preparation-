package com.islamicstudies.academy.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TranslationDao {

    @Query("SELECT * FROM translations WHERE srcHash IN (:hashes)")
    suspend fun getMany(hashes: List<String>): List<TranslationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(item: TranslationEntity)

    @Query("SELECT COUNT(*) FROM translations")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM translations")
    suspend fun clear()
}
