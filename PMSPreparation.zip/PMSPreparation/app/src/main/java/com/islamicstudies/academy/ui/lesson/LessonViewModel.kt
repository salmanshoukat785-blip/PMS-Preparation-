package com.islamicstudies.academy.ui.lesson

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.islamicstudies.academy.AcademyApp
import com.islamicstudies.academy.data.db.BookmarkEntity
import com.islamicstudies.academy.data.db.ChapterEntity
import com.islamicstudies.academy.data.db.HeadingEntity
import com.islamicstudies.academy.data.db.LessonSectionEntity
import com.islamicstudies.academy.data.db.PersonalNoteEntity
import com.islamicstudies.academy.data.db.QuestionEntity
import com.islamicstudies.academy.data.db.UserProgressEntity
import com.islamicstudies.academy.data.db.TranslationEntity
import com.islamicstudies.academy.data.settings.AppSettings
import com.islamicstudies.academy.data.translate.Translators
import com.islamicstudies.academy.data.translate.sha256Hex
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LessonViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle
) : AndroidViewModel(application) {

    private val app = AcademyApp.get(application)
    private val contentDao = app.database.contentDao()
    private val userDao = app.database.userDao()
    private val repo = app.settingsRepository

    val headingId: String = savedStateHandle.get<String>("headingId") ?: ""

    // Heading ids look like "ch06-s02-t03": the chapter id is the part before the first "-".
    private val chapterId: String = headingId.substringBefore("-")

    private val keepAlive = SharingStarted.WhileSubscribed(5000)

    val heading: StateFlow<HeadingEntity?> = contentDao.observeHeading(headingId)
        .stateIn(viewModelScope, keepAlive, null)

    val chapter: StateFlow<ChapterEntity?> = contentDao.observeChapter(chapterId)
        .stateIn(viewModelScope, keepAlive, null)

    val siblings: StateFlow<List<HeadingEntity>> = contentDao.observeHeadings(chapterId)
        .stateIn(viewModelScope, keepAlive, emptyList())

    val sections: StateFlow<List<LessonSectionEntity>> = contentDao.observeSections(headingId)
        .stateIn(viewModelScope, keepAlive, emptyList())

    val questions: StateFlow<List<QuestionEntity>> = app.database.quizDao().observeQuestionsForHeading(headingId)
        .stateIn(viewModelScope, keepAlive, emptyList())

    val bookmarked: StateFlow<Boolean> = userDao.observeBookmarkCount(headingId)
        .map { n -> n > 0 }
        .stateIn(viewModelScope, keepAlive, false)

    val completed: StateFlow<Boolean> = userDao.observeCompletedFlag(headingId)
        .map { n -> n > 0 }
        .stateIn(viewModelScope, keepAlive, false)

    val note: StateFlow<String> = userDao.observeNote(headingId)
        .map { text -> text ?: "" }
        .stateIn(viewModelScope, keepAlive, "")

    val settings: StateFlow<AppSettings> = repo.settings
        .stateIn(viewModelScope, keepAlive, AppSettings())

    private val translationDao = app.database.translationDao()
    private val translator = Translators.default

    /** SHA-256 of an English lesson text -> its saved Urdu translation. */
    private val _translated = MutableStateFlow<Map<String, String>>(emptyMap())
    val translated: StateFlow<Map<String, String>> = _translated.asStateFlow()

    private val _translating = MutableStateFlow(false)
    val translating: StateFlow<Boolean> = _translating.asStateFlow()

    private val _translateFailed = MutableStateFlow(false)
    val translateFailed: StateFlow<Boolean> = _translateFailed.asStateFlow()

    init {
        // Saved translations are shown without the internet.
        viewModelScope.launch {
            sections.collect { list ->
                val hashes = list
                    .filter { sec -> sec.lang == "en" && sec.kind != "reference" && sec.body.isNotBlank() }
                    .map { sec -> sha256Hex(sec.body) }
                    .distinct()
                if (hashes.isNotEmpty()) {
                    val saved = translationDao.getMany(hashes)
                    if (saved.isNotEmpty()) {
                        _translated.value = _translated.value + saved.associate { t -> t.srcHash to t.textUr }
                    }
                }
            }
        }
    }

    init {
        // Remember the last opened lesson (used by "Continue where you left off").
        viewModelScope.launch {
            repo.recordStudyDay()
            val existing = userDao.getProgress(headingId)
            userDao.upsertProgress(
                UserProgressEntity(
                    headingId = headingId,
                    completed = existing?.completed ?: false,
                    lastOpenedAt = System.currentTimeMillis()
                )
            )
        }
    }

    /** Translates the English text of this lesson (given levels) into Urdu, saving each piece as it finishes. */
    fun translateLesson(levels: List<String>) {
        if (_translating.value) return
        viewModelScope.launch {
            _translating.value = true
            _translateFailed.value = false
            try {
                val todo = sections.value.filter { sec ->
                    sec.lang == "en" && levels.contains(sec.level) && sec.kind != "reference" && sec.body.isNotBlank()
                }
                for (sec in todo) {
                    val hash = sha256Hex(sec.body)
                    if (_translated.value.containsKey(hash)) continue
                    val ur = translator.translate(sec.body, "en", "ur")
                    translationDao.put(TranslationEntity(hash, ur, System.currentTimeMillis()))
                    _translated.value = _translated.value + (hash to ur)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _translateFailed.value = true
            } finally {
                _translating.value = false
            }
        }
    }

    fun allowOnlineTranslation() {
        viewModelScope.launch { repo.setOnlineTranslation(true) }
    }

    fun toggleBookmark() {
        viewModelScope.launch {
            if (bookmarked.value) {
                userDao.removeBookmark(headingId)
            } else {
                userDao.addBookmark(BookmarkEntity(headingId, System.currentTimeMillis()))
            }
        }
    }

    fun saveNote(text: String) {
        viewModelScope.launch {
            val trimmed = text.trim()
            if (trimmed.isEmpty()) {
                userDao.deleteNote(headingId)
            } else {
                userDao.upsertNote(PersonalNoteEntity(headingId, trimmed, System.currentTimeMillis()))
            }
        }
    }

    fun toggleCompleted() {
        viewModelScope.launch {
            userDao.upsertProgress(
                UserProgressEntity(headingId, !completed.value, System.currentTimeMillis())
            )
        }
    }

    fun setLevel(level: String) {
        viewModelScope.launch { repo.setLevel(level) }
    }

    fun setContentLanguage(language: String) {
        viewModelScope.launch { repo.setContentLanguage(language) }
    }

    fun setTextScale(percent: Int) {
        viewModelScope.launch { repo.setTextScale(percent) }
    }

    fun setTheme(theme: String) {
        viewModelScope.launch { repo.setTheme(theme) }
    }
}
