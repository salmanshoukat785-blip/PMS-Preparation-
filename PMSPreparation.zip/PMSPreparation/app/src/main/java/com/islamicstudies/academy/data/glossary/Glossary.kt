package com.islamicstudies.academy.data.glossary

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** One glossary word with the spellings used to find it in lesson text. */
data class GlossaryTerm(
    val id: String,
    val termEn: String,
    val termUr: String,
    val matchEn: List<String>,
    val matchUr: List<String>,
    val meaningEn: String,
    val meaningUr: String
)

/** A glossary word found inside a piece of text. */
data class GlossaryHit(val start: Int, val end: Int, val term: GlossaryTerm)

/** Loads the glossary from assets/glossary.json once and keeps it in memory. */
object GlossaryStore {
    @Volatile
    private var cached: List<GlossaryTerm>? = null

    fun get(context: Context): List<GlossaryTerm> {
        val existing = cached
        if (existing != null) return existing
        val loaded = try {
            val text = context.applicationContext.assets.open("islamic/glossary.json")
                .bufferedReader(Charsets.UTF_8)
                .use { reader -> reader.readText() }
            parse(text)
        } catch (e: Exception) {
            emptyList()
        }
        cached = loaded
        return loaded
    }

    fun parse(json: String): List<GlossaryTerm> {
        val arr = JSONObject(json).getJSONArray("terms")
        val out = ArrayList<GlossaryTerm>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                GlossaryTerm(
                    id = o.getString("id"),
                    termEn = o.getString("termEn"),
                    termUr = o.getString("termUr"),
                    matchEn = strings(o.optJSONArray("matchEn")),
                    matchUr = strings(o.optJSONArray("matchUr")),
                    meaningEn = o.getString("meaningEn"),
                    meaningUr = o.getString("meaningUr")
                )
            )
        }
        return out
    }

    private fun strings(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) out.add(arr.getString(i))
        return out
    }
}

private fun isWordChar(c: Char): Boolean =
    c.isLetterOrDigit() || Character.getType(c) == Character.NON_SPACING_MARK.toInt()

private fun isWholeWord(text: String, start: Int, end: Int): Boolean {
    val before = if (start > 0) text[start - 1] else ' '
    val after = if (end < text.length) text[end] else ' '
    return !isWordChar(before) && !isWordChar(after)
}

/**
 * Finds glossary words in [text]. Each word is linked only at its first occurrence, and
 * overlapping matches are dropped (the earlier and longer match wins).
 */
fun findGlossaryHits(text: String, lang: String, terms: List<GlossaryTerm>): List<GlossaryHit> {
    val candidates = ArrayList<GlossaryHit>()
    val urdu = lang == "ur"
    for (term in terms) {
        val needles = if (urdu) term.matchUr else term.matchEn
        var best: GlossaryHit? = null
        for (needle in needles) {
            if (needle.isEmpty()) continue
            var from = 0
            while (from <= text.length) {
                val i = text.indexOf(needle, from, ignoreCase = !urdu)
                if (i < 0) break
                val end = i + needle.length
                if (isWholeWord(text, i, end)) {
                    val current = best
                    if (current == null || i < current.start) best = GlossaryHit(i, end, term)
                    break
                }
                from = i + 1
            }
        }
        if (best != null) candidates.add(best)
    }
    val sorted = candidates.sortedWith(
        compareBy<GlossaryHit> { h -> h.start }.thenByDescending { h -> h.end - h.start }
    )
    val out = ArrayList<GlossaryHit>()
    var lastEnd = -1
    for (h in sorted) {
        if (h.start >= lastEnd) {
            out.add(h)
            lastEnd = h.end
        }
    }
    return out
}
