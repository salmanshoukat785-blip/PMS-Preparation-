package com.socialwork.academy.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.socialwork.academy.data.ChapterCatalog
import com.socialwork.academy.data.ContentState
import com.socialwork.academy.data.GlossaryTerm
import com.socialwork.academy.data.Topic
import com.socialwork.academy.data.TopicCatalog
import com.socialwork.academy.ui.AppStrings

/**
 * One paper: a navy title bar, tabs (Topics, Saved, Course Outline, Topic Outline, Study, Guide)
 * and numbered topic cards grouped under chapter bands.
 */
@Composable
fun PaperTopicsScreen(
    strings: AppStrings,
    isUrdu: Boolean,
    paperId: Int,
    completedTopics: Set<String>,
    bookmarks: Set<String>,
    content: ContentState,
    terms: List<GlossaryTerm>,
    onOpenTopic: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ps = PaperStrings.of(isUrdu)
    val p = paperPalette()
    val title = if (paperId == 2) strings.paper2 else strings.paper1
    val chapters = ChapterCatalog.forPaper(paperId)
    // A chapter is only a heading; the numbered topics are the ones inside it.
    val topics: List<Topic> = chapters.flatMap { ch -> ch.childTopicIds.mapNotNull { TopicCatalog.byId(it) } }
    var tab by rememberSaveable(paperId) { mutableIntStateOf(0) }
    var query by rememberSaveable(paperId) { mutableStateOf("") }
    val studied = topics.count { it.id in completedTopics }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().background(p.header).padding(start = 4.dp, end = 16.dp, top = 12.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back, tint = p.onHeader)
            }
            Text(text = title, style = MaterialTheme.typography.titleLarge, color = p.onHeader, modifier = Modifier.asHeading())
        }
        PaperTabs(
            listOf(ps.topics, ps.saved, ps.courseOutline, ps.topicOutline, ps.study, ps.guide),
            tab
        ) { tab = it }

        when (tab) {
            0 -> TopicsTab(ps, isUrdu, chapters.map { it }, topics.size, studied, completedTopics, bookmarks, terms, query, { query = it }, onOpenTopic)
            1 -> SimpleScroll {
                val saved = topics.filter { it.id in bookmarks }
                if (saved.isEmpty()) EmptyText(ps.nothingSaved)
                saved.forEachIndexed { i, t ->
                    PaperRow(i + 1, t.title(isUrdu), if (t.id in completedTopics) "✓" else "", { onOpenTopic(t.id) })
                }
            }
            2 -> SimpleScroll {
                chapters.forEachIndexed { i, ch ->
                    PaperBand("${'A' + i % 26}. ${ch.title(isUrdu)}")
                    ch.childTopicIds.forEach { id ->
                        val t = TopicCatalog.byId(id) ?: return@forEach
                        Text("•  ${t.title(isUrdu)}", color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(start = 8.dp))
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
            3 -> SimpleScroll {
                topics.forEachIndexed { i, t ->
                    PaperRow(i + 1, t.title(isUrdu), if (t.id in completedTopics) "✓" else "", { onOpenTopic(t.id) })
                    val sections = (content as? ContentState.Ready)?.bundle?.forTopic(t.id)?.sections.orEmpty()
                    sections.map { it.heading(isUrdu) }.filter { it.isNotBlank() }.forEach { h ->
                        Text("•  $h", color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(start = 20.dp))
                    }
                }
            }
            4 -> SimpleScroll {
                val left: List<Topic> = topics.filter { it.id !in completedTopics }
                Text("${ps.studiedLabel} $studied / ${topics.size}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                LinearProgressIndicator(
                    progress = { if (topics.isEmpty()) 0f else studied.toFloat() / topics.size },
                    modifier = Modifier.fillMaxWidth(), color = p.accent, trackColor = p.card, drawStopIndicator = {}
                )
                if (left.isEmpty()) {
                    EmptyText(ps.allStudied)
                } else {
                    Text("${ps.continueStudy}:", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { onOpenTopic(left.first().id) }, modifier = Modifier.fillMaxWidth()) {
                        Text(left.first().title(isUrdu))
                    }
                    Text("${ps.remaining} (${left.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    left.forEachIndexed { i, t -> PaperRow(i + 1, t.title(isUrdu), "", { onOpenTopic(t.id) }) }
                }
            }
            else -> SimpleScroll {
                ps.guideLines.forEach { line ->
                    Text(
                        line, color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(p.card, RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyText(text: String) {
    Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
}

@Composable
private fun SimpleScroll(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) { content() }
}

@Composable
private fun TopicsTab(
    ps: PaperStrings,
    isUrdu: Boolean,
    chapters: List<com.socialwork.academy.data.Chapter>,
    total: Int,
    studied: Int,
    completedTopics: Set<String>,
    bookmarks: Set<String>,
    terms: List<GlossaryTerm>,
    query: String,
    onQuery: (String) -> Unit,
    onOpenTopic: (String) -> Unit
) {
    val p = paperPalette()
    val q = query.trim()
    // Topics whose name, or one of whose terms, matches the search text.
    val matchedByTerm = if (q.isEmpty()) emptySet() else terms.filter { it.en.contains(q, true) || it.ur.contains(q) }.map { it.topicId }.toSet()
    fun matches(t: Topic): Boolean =
        q.isEmpty() || t.titleEn.contains(q, true) || t.titleUr.contains(q) || t.id in matchedByTerm

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${ps.studiedLabel} $studied / $total", color = MaterialTheme.colorScheme.onSurfaceVariant)
        LinearProgressIndicator(
            progress = { if (total == 0) 0f else studied.toFloat() / total },
            modifier = Modifier.fillMaxWidth(), color = p.accent, trackColor = p.card, drawStopIndicator = {}
        )
        OutlinedTextField(
            value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(ps.search) }, shape = RoundedCornerShape(10.dp)
        )
        var number = 0
        var shown = 0
        chapters.forEachIndexed { ci, ch ->
            val ids = ch.childTopicIds
            val numbered = ids.map { id -> number++; id to number }
            val visible = numbered.mapNotNull { (id, n) -> TopicCatalog.byId(id)?.takeIf { matches(it) }?.let { it to n } }
            if (visible.isNotEmpty()) {
                PaperBand("${'A' + ci % 26}. ${ch.title(isUrdu)}", onClick = ch.chapterTopicId?.let { id -> { onOpenTopic(id) } })
                visible.forEach { (t, n) ->
                    shown++
                    val mark = (if (t.id in bookmarks) "★ " else "") + (if (t.id in completedTopics) "✓" else "")
                    PaperRow(n, t.title(isUrdu), mark.trim(), { onOpenTopic(t.id) })
                }
            }
        }
        if (shown == 0) EmptyText(ps.noResults)
    }
}
