package com.socialwork.academy.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Colours of the Paper 1 / Paper 2 screens (navy bars, soft blue cards, teal headings). */
class PaperPalette(
    val header: Color,
    val onHeader: Color,
    val band: Color,
    val onBand: Color,
    val card: Color,
    val cardAlt: Color,
    val onCard: Color,
    val accent: Color,
    val outline: Color
)

@Composable
fun paperPalette(): PaperPalette {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (dark) {
        PaperPalette(
            header = Color(0xFF14263F), onHeader = Color.White,
            band = Color(0xFF1F3A5F), onBand = Color.White,
            card = Color(0xFF1E2A36), cardAlt = Color(0xFF17212B), onCard = Color(0xFFE6EDF3),
            accent = Color(0xFF5FD0DD), outline = Color(0xFF55657A)
        )
    } else {
        PaperPalette(
            header = Color(0xFF1F3A5F), onHeader = Color.White,
            band = Color(0xFF1F3A5F), onBand = Color.White,
            card = Color(0xFFE9F1F6), cardAlt = Color(0xFFFFFFFF), onCard = Color(0xFF1B1F24),
            accent = Color(0xFF0F7B8A), outline = Color(0xFF7A8794)
        )
    }
}

/** Texts of the Paper screens, in English and Urdu. */
class PaperStrings(
    val topics: String, val saved: String, val courseOutline: String, val topicOutline: String,
    val study: String, val guide: String,
    val notes: String, val keyPoints: String, val mcqs: String, val vocabulary: String, val myNotes: String,
    val save: String, val savedNow: String, val markStudied: String, val studiedNow: String, val back: String,
    val short: String, val longDetail: String, val studiedLabel: String, val search: String,
    val nothingSaved: String, val noMcqs: String, val noTerms: String, val noResults: String,
    val answered: String, val correct: String, val continueStudy: String, val allStudied: String,
    val remaining: String, val highlight: String, val highlighted: String, val guideLines: List<String>
) {
    companion object {
        private val en = PaperStrings(
            topics = "Topics", saved = "Saved", courseOutline = "Course Outline", topicOutline = "Topic Outline",
            study = "Study", guide = "Guide",
            notes = "Notes", keyPoints = "Key Points", mcqs = "MCQs", vocabulary = "Vocabulary", myNotes = "My Notes",
            save = "☆ Save", savedNow = "★ Saved", markStudied = "Mark studied", studiedNow = "Studied ✓", back = "Back",
            short = "Short", longDetail = "Long detail", studiedLabel = "Studied", search = "Search topics or terms",
            nothingSaved = "No saved topics yet. Open a topic and tap Save.",
            noMcqs = "No practice questions for this topic.", noTerms = "No vocabulary for this topic.",
            noResults = "Nothing found.", answered = "Answered", correct = "correct",
            continueStudy = "Continue with", allStudied = "All topics are studied. Well done!", remaining = "Still to study", highlight = "Highlight", highlighted = "Highlighted \u2713",
            guideLines = listOf(
                "Topics: all topics of the paper, grouped by chapter. Search by topic name or term.",
                "Saved: topics you saved with the Save button.",
                "Course Outline: the chapters and their headings at a glance.",
                "Topic Outline: every topic with the headings of its notes.",
                "Study: your next topic and what is still left.",
                "Inside a topic: Notes (turn on Long detail for the full explanation), Key Points, MCQs, Vocabulary and your own notes.",
                "Tap Mark studied when you finish a topic. Your progress counts on the home page."
            )
        )
        private val ur = PaperStrings(
            topics = "موضوعات", saved = "محفوظ", courseOutline = "کورس آؤٹ لائن", topicOutline = "ٹاپک آؤٹ لائن",
            study = "مطالعہ", guide = "رہنما",
            notes = "نوٹس", keyPoints = "اہم نکات", mcqs = "ایم سی کیوز", vocabulary = "الفاظ", myNotes = "میرے نوٹس",
            save = "☆ محفوظ کریں", savedNow = "★ محفوظ", markStudied = "پڑھ لیا", studiedNow = "پڑھ لیا ✓", back = "واپس",
            short = "مختصر", longDetail = "تفصیلی", studiedLabel = "پڑھے گئے", search = "موضوعات یا اصطلاحات تلاش کریں",
            nothingSaved = "ابھی کوئی موضوع محفوظ نہیں۔ موضوع کھول کر محفوظ کریں دبائیں۔",
            noMcqs = "اس موضوع کے لیے مشقی سوالات نہیں۔", noTerms = "اس موضوع کے لیے الفاظ نہیں۔",
            noResults = "کچھ نہیں ملا۔", answered = "جواب دیے", correct = "درست",
            continueStudy = "اگلا موضوع", allStudied = "تمام موضوعات پڑھ لیے گئے۔ شاباش!", remaining = "ابھی باقی", highlight = "نشان لگائیں", highlighted = "نشان زد \u2713",
            guideLines = listOf(
                "موضوعات: پرچے کے تمام موضوعات، باب کے لحاظ سے۔ نام یا اصطلاح سے تلاش کریں۔",
                "محفوظ: وہ موضوعات جو آپ نے محفوظ کیے۔",
                "کورس آؤٹ لائن: ابواب اور ان کے عنوانات ایک نظر میں۔",
                "ٹاپک آؤٹ لائن: ہر موضوع اور اس کے نوٹس کے عنوانات۔",
                "مطالعہ: آپ کا اگلا موضوع اور جو باقی ہے۔",
                "موضوع کے اندر: نوٹس (مکمل وضاحت کے لیے تفصیلی آن کریں)، اہم نکات، ایم سی کیوز، الفاظ اور اپنے نوٹس۔",
                "موضوع مکمل ہونے پر پڑھ لیا دبائیں۔ آپ کی پیش رفت ہوم پیج پر گنی جاتی ہے۔"
            )
        )
        fun of(isUrdu: Boolean): PaperStrings = if (isUrdu) ur else en
    }
}

/** Scrollable tab row used by the Paper and topic screens. */
@Composable
fun PaperTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val p = paperPalette()
    ScrollableTabRow(
        selectedTabIndex = selected,
        edgePadding = 0.dp,
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = p.accent
    ) {
        labels.forEachIndexed { i, label ->
            Tab(
                selected = i == selected,
                onClick = { onSelect(i) },
                text = {
                    Text(
                        label,
                        fontWeight = if (i == selected) FontWeight.Bold else FontWeight.Medium,
                        color = if (i == selected) p.accent else MaterialTheme.colorScheme.onSurface
                    )
                }
            )
        }
    }
}

/** Dark band with an upper-case heading (a chapter or a section). */
@Composable
fun PaperBand(text: String, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val p = paperPalette()
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(p.band)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(text = text.uppercase(), color = p.onBand, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
    }
}

/** A numbered, rounded row that opens something when tapped. */
@Composable
fun PaperRow(
    number: Int,
    title: String,
    mark: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val p = paperPalette()
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(p.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "$number. $title",
            style = MaterialTheme.typography.titleMedium,
            color = p.onCard,
            modifier = Modifier.weight(1f)
        )
        if (mark.isNotEmpty()) Text(mark, color = p.accent, fontWeight = FontWeight.Bold)
    }
}
