package com.socialwork.academy.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.socialwork.academy.data.ContentState
import com.socialwork.academy.data.FontScale
import com.socialwork.academy.data.GlossaryTerm
import com.socialwork.academy.data.Mcq
import com.socialwork.academy.data.ReadingText
import com.socialwork.academy.data.Topic
import com.socialwork.academy.data.TopicDetails
import com.socialwork.academy.data.TopicSection
import com.socialwork.academy.ui.AppStrings
import com.socialwork.academy.ui.StudyStrings

/**
 * One topic: navy title bar, Save / Mark studied buttons and five tabs
 * (Notes, Key Points, MCQs, Vocabulary, My Notes).
 */
@Composable
fun TopicDetailScreen(
    strings: AppStrings,
    isUrdu: Boolean,
    topic: Topic,
    content: ContentState,
    details: TopicDetails?,
    mcqs: List<Mcq>,
    terms: List<GlossaryTerm>,
    completed: Boolean,
    bookmarked: Boolean,
    fontScale: Float,
    onToggleCompleted: (Boolean) -> Unit,
    onToggleBookmark: () -> Unit,
    onFontScaleChange: (Float) -> Unit,
    st: StudyStrings,
    savedNote: String,
    onNoteSave: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val ps = PaperStrings.of(isUrdu)
    val p = paperPalette()
    var tab by rememberSaveable(topic.id) { mutableIntStateOf(0) }
    val sections: List<TopicSection> =
        (content as? ContentState.Ready)?.bundle?.forTopic(topic.id)?.sections.orEmpty()
    val canShareText = sections.isNotEmpty()

    Column(modifier = modifier.fillMaxSize()) {
        // Navy title bar
        Row(
            modifier = Modifier.fillMaxWidth().background(p.header).padding(start = 8.dp, end = 16.dp, top = 12.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text(ps.back, color = p.onHeader, fontWeight = FontWeight.Bold) }
            Text(
                text = topic.title(isUrdu), style = MaterialTheme.typography.titleLarge, color = p.onHeader,
                modifier = Modifier.weight(1f).asHeading()
            )
        }

        // Save, Mark studied, copy, share
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (bookmarked) {
                Button(onClick = onToggleBookmark, colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = Color.White)) { Text(ps.savedNow) }
            } else {
                OutlinedButton(onClick = onToggleBookmark, border = BorderStroke(1.dp, p.outline)) { Text(ps.save) }
            }
            if (completed) {
                Button(onClick = { onToggleCompleted(false) }, colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = Color.White)) { Text(ps.studiedNow) }
            } else {
                OutlinedButton(onClick = { onToggleCompleted(true) }, border = BorderStroke(1.dp, p.outline)) { Text(ps.markStudied) }
            }
            Spacer(Modifier.weight(1f))
            IconButton(
                enabled = canShareText,
                onClick = { copyText(context, topic.titleEn, ReadingText.build(topic, sections, isUrdu), strings.copiedMessage) }
            ) { Icon(Icons.Filled.ContentCopy, contentDescription = strings.copyLabel) }
            IconButton(
                enabled = canShareText,
                onClick = { shareText(context, topic.title(isUrdu), ReadingText.build(topic, sections, isUrdu), strings.shareLabel) }
            ) { Icon(Icons.Filled.Share, contentDescription = strings.shareLabel) }
        }

        PaperTabs(listOf(ps.notes, ps.keyPoints, ps.mcqs, ps.vocabulary, ps.myNotes), tab) { tab = it }

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (tab) {
                0 -> NotesTab(strings, ps, isUrdu, topic, content, sections, details, fontScale, onFontScaleChange)
                1 -> KeyPointsTab(strings, isUrdu, content, sections, fontScale)
                2 -> McqTab(ps, mcqs, fontScale)
                3 -> VocabTab(ps, terms, isUrdu)
                else -> NoteCard(topicId = topic.id, st = st, savedNote = savedNote, onSave = onNoteSave)
            }
        }
    }
}

@Composable
private fun scaled(fontScale: Float): androidx.compose.ui.text.TextStyle {
    val base = MaterialTheme.typography.bodyLarge
    return base.copy(fontSize = base.fontSize * fontScale, lineHeight = base.lineHeight * fontScale)
}

@Composable
private fun NotesTab(
    strings: AppStrings,
    ps: PaperStrings,
    isUrdu: Boolean,
    topic: Topic,
    content: ContentState,
    sections: List<TopicSection>,
    details: TopicDetails?,
    fontScale: Float,
    onFontScaleChange: (Float) -> Unit
) {
    val p = paperPalette()
    var long by rememberSaveable(topic.id) { mutableStateOf(false) }
    // Highlighted notes are remembered per topic on this phone.
    val ctx = LocalContext.current
    val hlPrefs = remember { ctx.getSharedPreferences("sw_highlights", Context.MODE_PRIVATE) }
    var marked by remember(topic.id) { mutableStateOf(hlPrefs.getStringSet(topic.id, emptySet())?.toSet() ?: emptySet<String>()) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(ps.short, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.width(10.dp))
        Switch(checked = long, onCheckedChange = { long = it })
        Spacer(Modifier.width(10.dp))
        Text(ps.longDetail, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.weight(1f))
        TextButton(
            enabled = FontScale.canShrink(fontScale), onClick = { onFontScaleChange(FontScale.smaller(fontScale)) },
            modifier = Modifier.semantics { contentDescription = strings.smallerText }
        ) { Text("A-") }
        TextButton(
            enabled = FontScale.canGrow(fontScale), onClick = { onFontScaleChange(FontScale.larger(fontScale)) },
            modifier = Modifier.semantics { contentDescription = strings.largerText }
        ) { Text("A+") }
    }
    when (content) {
        ContentState.Loading -> CircularProgressIndicator(modifier = Modifier.padding(16.dp))
        ContentState.Failed -> InfoCard(text = strings.contentError)
        is ContentState.Ready -> {
            if (sections.isEmpty()) {
                InfoCard(text = strings.noSourcePoints)
            } else {
                val entries = details?.entries(isUrdu).orEmpty()
                val offsets = sections.runningFold(0) { acc, s -> acc + s.items(isUrdu).size }
                var number = 0
                sections.forEachIndexed { si, section ->
                    val heading = section.heading(isUrdu)
                    if (heading.isNotBlank()) PaperBand(heading)
                    section.items(isUrdu).forEachIndexed { i, item ->
                        number++
                        // The explanation is used only when its heading is exactly this point.
                        val d = entries.getOrNull(offsets[si] + i)?.takeIf { it.heading.trim() == item.trim() }
                        val tinted = number % 2 == 1
                        val key = number.toString()
                        val lit = key in marked
                        val ink = Color(0xFF1B1F24)
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (lit) Color(0xFFFFF3B0) else if (tinted) p.card else p.cardAlt, RoundedCornerShape(18.dp))
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SelectionContainer {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("$number. $item", style = scaled(fontScale), fontWeight = FontWeight.Bold, color = if (lit) Color(0xFF7A4A00) else p.accent)
                                    if (d != null) {
                                        Text(
                                            if (long) d.long else d.short, style = scaled(fontScale),
                                            color = if (lit) ink else if (tinted) p.onCard else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                            TextButton(onClick = {
                                marked = if (lit) marked - key else marked + key
                                hlPrefs.edit().putStringSet(topic.id, marked.toSet()).apply()
                            }) { Text(if (lit) ps.highlighted else ps.highlight, color = if (lit) Color(0xFF7A4A00) else p.accent) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KeyPointsTab(
    strings: AppStrings,
    isUrdu: Boolean,
    content: ContentState,
    sections: List<TopicSection>,
    fontScale: Float
) {
    val p = paperPalette()
    when (content) {
        ContentState.Loading -> CircularProgressIndicator(modifier = Modifier.padding(16.dp))
        ContentState.Failed -> InfoCard(text = strings.contentError)
        is ContentState.Ready -> {
            if (sections.isEmpty()) InfoCard(text = strings.noSourcePoints)
            sections.forEach { section ->
                val heading = section.heading(isUrdu)
                if (heading.isNotBlank()) PaperBand(heading)
                Column(
                    modifier = Modifier.fillMaxWidth().background(p.card, RoundedCornerShape(18.dp)).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    section.items(isUrdu).forEach { item ->
                        Text("•  $item", style = scaled(fontScale), color = p.onCard)
                    }
                }
            }
        }
    }
}

@Composable
private fun McqTab(ps: PaperStrings, mcqs: List<Mcq>, fontScale: Float) {
    val p = paperPalette()
    if (mcqs.isEmpty()) {
        Text(ps.noMcqs, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    val picked = remember(mcqs) { mutableStateMapOf<String, Int>() }
    val right = mcqs.count { picked[it.id] == it.answerIndex }
    Text("${ps.answered} ${picked.size} / ${mcqs.size}  ·  $right ${ps.correct}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
    mcqs.forEachIndexed { qi, q ->
        val choice = picked[q.id]
        Column(
            modifier = Modifier.fillMaxWidth().background(p.card, RoundedCornerShape(18.dp)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("${qi + 1}. ${q.question}", style = scaled(fontScale), fontWeight = FontWeight.Bold, color = p.accent)
            q.options.forEachIndexed { oi, option ->
                val shade = when {
                    choice == null -> MaterialTheme.colorScheme.surface
                    oi == q.answerIndex -> Color(0xFFCDEBD3)
                    oi == choice -> Color(0xFFF6D0D0)
                    else -> MaterialTheme.colorScheme.surface
                }
                Text(
                    text = option,
                    style = scaled(fontScale),
                    color = if (choice != null && (oi == q.answerIndex || oi == choice)) Color(0xFF1B1F24) else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(shade, RoundedCornerShape(12.dp))
                        .clickable(enabled = choice == null) { picked[q.id] = oi }
                        .padding(12.dp)
                )
            }
            if (choice != null && q.explanation.isNotBlank()) {
                Text(q.explanation, style = MaterialTheme.typography.bodyMedium, color = p.onCard)
            }
        }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun VocabTab(ps: PaperStrings, terms: List<GlossaryTerm>, isUrdu: Boolean) {
    val p = paperPalette()
    val list = terms.distinctBy { it.en to it.ur }
    if (list.isEmpty()) {
        Text(ps.noTerms, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    list.forEachIndexed { i, t ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (i % 2 == 0) p.card else p.cardAlt, RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(if (isUrdu) t.ur else t.en, fontWeight = FontWeight.Bold, color = p.accent, style = MaterialTheme.typography.titleMedium)
            Text(if (isUrdu) t.en else t.ur, color = if (i % 2 == 0) p.onCard else MaterialTheme.colorScheme.onSurface)
        }
    }
}

private fun copyText(context: Context, label: String, text: String, copiedMessage: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
    // Android 13 and newer show their own "copied" confirmation.
    if (Build.VERSION.SDK_INT < 33) {
        Toast.makeText(context, copiedMessage, Toast.LENGTH_SHORT).show()
    }
}

private fun shareText(context: Context, subject: String, text: String, chooserTitle: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, chooserTitle))
}
