package com.completeenglishgrammar.app

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.completeenglishgrammar.app.data.UserSettings
import com.completeenglishgrammar.app.ui.nav.AppNav
import com.completeenglishgrammar.app.ui.theme.GrammarTheme
import com.completeenglishgrammar.app.viewmodel.MainViewModel

/** The whole original "Complete English Grammar" app (what its MainActivity used to show). [onExit] returns to the PMS Preparation home. */
@Composable
fun GrammarApp(onExit: () -> Unit) {
    val viewModel: MainViewModel = viewModel()
    val settings by viewModel.settings.collectAsState()
    // Until the saved settings load, use the defaults so the splash still draws.
    GrammarTheme(settings = settings ?: UserSettings()) {
        AppNav(vm = viewModel, settings = settings, onExit = onExit)
    }
}
