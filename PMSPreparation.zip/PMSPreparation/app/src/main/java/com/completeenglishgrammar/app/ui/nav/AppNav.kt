package com.completeenglishgrammar.app.ui.nav

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.completeenglishgrammar.app.data.Topics
import com.completeenglishgrammar.app.data.UserSettings
import com.completeenglishgrammar.app.ui.screens.AiTutorScreen
import com.completeenglishgrammar.app.ui.screens.BackupScreen
import com.completeenglishgrammar.app.ui.screens.FlashcardsScreen
import com.completeenglishgrammar.app.ui.screens.HelpScreen
import com.completeenglishgrammar.app.ui.screens.HomeScreen
import com.completeenglishgrammar.app.ui.screens.LibraryScreen
import com.completeenglishgrammar.app.ui.screens.ProgressScreen
import com.completeenglishgrammar.app.ui.screens.LearnScreen
import com.completeenglishgrammar.app.ui.screens.LessonScreen
import com.completeenglishgrammar.app.ui.screens.MoreScreen
import com.completeenglishgrammar.app.ui.screens.NameScreen
import com.completeenglishgrammar.app.ui.screens.OnboardingScreen
import com.completeenglishgrammar.app.ui.screens.PracticeScreen
import com.completeenglishgrammar.app.ui.screens.ProfileScreen
import com.completeenglishgrammar.app.ui.screens.QuestionBankScreen
import com.completeenglishgrammar.app.ui.screens.QuizScreen
import com.completeenglishgrammar.app.ui.screens.ResultScreen
import com.completeenglishgrammar.app.ui.screens.SettingsScreen
import com.completeenglishgrammar.app.ui.screens.SplashScreen
import com.completeenglishgrammar.app.ui.screens.WelcomeScreen
import com.completeenglishgrammar.app.viewmodel.AiViewModel
import com.completeenglishgrammar.app.viewmodel.LearnViewModel
import com.completeenglishgrammar.app.viewmodel.MainViewModel
import com.completeenglishgrammar.app.viewmodel.QuizConfig
import com.completeenglishgrammar.app.viewmodel.QuizMode
import com.completeenglishgrammar.app.viewmodel.QuizViewModel
import kotlinx.coroutines.launch

object Routes {
    const val SPLASH = "splash"
    const val WELCOME = "welcome"
    const val ONBOARDING = "onboarding"
    const val NAME = "name"
    const val HOME = "home"
    const val LEARN = "learn"
    const val PRACTICE = "practice"
    const val MORE = "more"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val LESSON = "lesson"
    const val QUIZ = "quiz"
    const val RESULT = "result"
    const val BANK = "bank"
    const val FLASHCARDS = "flashcards"
    const val LIBRARY = "library"
    const val PROGRESS = "progress"
    const val AI = "ai"
    const val BACKUP = "backup"
    const val HELP = "help"
}

private data class BottomItem(val route: String, val label: String, val icon: ImageVector)

private val bottomItems = listOf(
    BottomItem(Routes.HOME, "Home", Icons.Filled.Home),
    BottomItem(Routes.LEARN, "Learn", Icons.Filled.Book),
    BottomItem(Routes.PRACTICE, "Practice", Icons.Filled.Quiz),
    BottomItem(Routes.MORE, "More", Icons.Filled.Menu)
)

@Composable
fun AppNav(vm: MainViewModel, settings: UserSettings?, onExit: () -> Unit = {}) {
    val quizVm: QuizViewModel = viewModel()
    val learnVm: LearnViewModel = viewModel()
    val aiVm: AiViewModel = viewModel()
    val aiSettings by aiVm.settings.collectAsState()
    val learn by learnVm.state.collectAsState()
    val builtInCards by learnVm.builtInCards.collectAsState()
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBottomBar = route in bottomItems.map { it.route }
    // Back from this app's own dashboard (or its first-run welcome) returns to the PMS Preparation home page.
    BackHandler(enabled = route == Routes.HOME || route == Routes.SPLASH || route == Routes.WELCOME) { onExit() }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val query by vm.query.collectAsState()
    val questions by quizVm.questions.collectAsState()
    val stats by quizVm.stats.collectAsState()
    val history by quizVm.history.collectAsState()
    val loadFailed by quizVm.loadFailed.collectAsState()

    fun toast(message: String) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(message)
        }
    }

    /** Pops the screen only if it is still the visible one, so a repeated call does nothing. */
    fun leave(from: String) {
        if (nav.currentBackStackEntry?.destination?.route == from) nav.popBackStack()
    }

    fun startQuiz(config: QuizConfig): Boolean {
        val started = quizVm.startQuiz(config)
        if (started) nav.navigate(Routes.QUIZ)
        return started
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        // Each screen handles its own status bar padding; the bottom bar handles the nav bar.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = route == item.route,
                            onClick = { nav.navigateToTab(item.route) },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.SPLASH,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(ready = settings != null) {
                    val target = if (settings?.onboardingDone == true) Routes.HOME else Routes.WELCOME
                    nav.navigate(target) { popUpTo(Routes.SPLASH) { inclusive = true } }
                }
            }
            composable(Routes.WELCOME) {
                WelcomeScreen(onContinue = { nav.navigate(Routes.ONBOARDING) })
            }
            composable(Routes.ONBOARDING) {
                OnboardingScreen(onFinished = { nav.navigate(Routes.NAME) })
            }
            composable(Routes.NAME) {
                NameScreen(onContinue = { name ->
                    vm.completeOnboarding(name)
                    nav.navigate(Routes.HOME) { popUpTo(Routes.WELCOME) { inclusive = true } }
                })
            }

            composable(Routes.HOME) {
                if (settings != null) {
                    HomeScreen(
                        settings = settings,
                        query = query,
                        onQueryChange = vm::setQuery,
                        onSearch = { nav.navigateToTab(Routes.LEARN) },
                        onOpenTopic = { id -> nav.openLesson(vm, id) },
                        onOpenLearn = { nav.navigateToTab(Routes.LEARN) },
                        onOpenPractice = { nav.navigateToTab(Routes.PRACTICE) },
                        onOpenBank = { nav.navigate(Routes.BANK) },
                        todayAnswered = QuizViewModel.answeredToday(history),
                        onOpenProfile = { nav.navigate(Routes.PROFILE) },
                        onOpenSettings = { nav.navigate(Routes.SETTINGS) },
                        onOpenFlashcards = { nav.navigate(Routes.FLASHCARDS) },
                        onOpenLibrary = { nav.navigate(Routes.LIBRARY) },
                        onOpenAi = { nav.navigate(Routes.AI) },
                        showGuide = !settings.guideSeen,
                        onGuideDone = vm::markGuideSeen
                    )
                }
            }
            composable(Routes.LEARN) {
                LearnScreen(
                    query = query,
                    onQueryChange = vm::setQuery,
                    onOpenTopic = { id -> nav.openLesson(vm, id) }
                )
            }
            composable(Routes.PRACTICE) {
                PracticeScreen(
                    questions = questions,
                    stats = stats,
                    loadFailed = loadFailed,
                    poolSize = { config -> quizVm.poolFor(config).size },
                    onStart = ::startQuiz,
                    onOpenBank = { nav.navigate(Routes.BANK) },
                    onMessage = ::toast
                )
            }
            composable(Routes.MORE) {
                if (settings != null) {
                    MoreScreen(
                        settings = settings,
                        onOpenProfile = { nav.navigate(Routes.PROFILE) },
                        onOpenSettings = { nav.navigate(Routes.SETTINGS) },
                        onOpenFlashcards = { nav.navigate(Routes.FLASHCARDS) },
                        onOpenLibrary = { nav.navigate(Routes.LIBRARY) },
                        onOpenProgress = { nav.navigate(Routes.PROGRESS) },
                        onOpenAi = { nav.navigate(Routes.AI) },
                        onOpenBackup = { nav.navigate(Routes.BACKUP) },
                        onOpenHelp = { nav.navigate(Routes.HELP) }
                    )
                }
            }

            composable(Routes.PROFILE) {
                if (settings != null) {
                    ProfileScreen(
                        settings = settings,
                        onSaveName = vm::setUserName,
                        onBack = { nav.popBackStack() }
                    )
                }
            }
            composable(Routes.SETTINGS) {
                if (settings != null) {
                    SettingsScreen(
                        settings = settings,
                        onThemeMode = vm::setThemeMode,
                        onPalette = vm::setPalette,
                        onFontScale = vm::setFontScale,
                        onAccessibility = vm::setAccessibilityMode,
                        onReduceMotion = vm::setReduceMotion,
                        onDailyGoal = vm::setDailyGoal,
                        onBack = { nav.popBackStack() }
                    )
                }
            }

            composable("${Routes.LESSON}/{id}") { entry ->
                val id = entry.arguments?.getString("id").orEmpty()
                LessonScreen(
                    topic = Topics.byId(id),
                    onBack = { nav.popBackStack() },
                    onOpenTopic = { other -> nav.openLesson(vm, other) },
                    onPractice = { topicId ->
                        val ok = startQuiz(QuizConfig(QuizMode.PRACTICE, topicId, null, 10))
                        if (!ok) toast("No questions for this topic yet")
                    },
                    bookmarked = id in learn.bookmarks,
                    onToggleBookmark = learnVm::toggleBookmark,
                    onSaveNote = { t, title, body -> learnVm.saveNote(null, t, title, body, 0L) },
                    onStudyStart = learnVm::beginStudy,
                    onStudyEnd = learnVm::endStudy
                )
            }
            composable(Routes.BANK) {
                QuestionBankScreen(
                    questions = questions,
                    stats = stats,
                    favourites = learn.favourites,
                    onToggleFavourite = learnVm::toggleFavourite,
                    onBack = { nav.popBackStack() }
                )
            }
            composable(Routes.FLASHCARDS) {
                FlashcardsScreen(
                    builtIn = builtInCards,
                    state = learn,
                    onReview = learnVm::reviewCard,
                    onAdd = learnVm::addCard,
                    onDelete = learnVm::deleteCard,
                    onBack = { nav.popBackStack() }
                )
            }
            composable(Routes.LIBRARY) {
                LibraryScreen(
                    state = learn,
                    questions = questions,
                    stats = stats,
                    onSaveNote = learnVm::saveNote,
                    onDeleteNote = learnVm::deleteNote,
                    onToggleBookmark = learnVm::toggleBookmark,
                    onToggleFavourite = learnVm::toggleFavourite,
                    onOpenTopic = { id -> nav.openLesson(vm, id) },
                    onBack = { nav.popBackStack() }
                )
            }
            composable(Routes.PROGRESS) {
                ProgressScreen(
                    state = learn,
                    questions = questions,
                    stats = stats,
                    history = history,
                    onBack = { nav.popBackStack() }
                )
            }
            composable(Routes.AI) {
                AiTutorScreen(
                    settings = aiSettings,
                    messages = aiVm.messages,
                    loading = aiVm.loading,
                    error = aiVm.error,
                    onSend = aiVm::send,
                    onClear = aiVm::clearChat,
                    onSaveSettings = aiVm::saveSettings,
                    onBack = { nav.popBackStack() }
                )
            }
            composable(Routes.BACKUP) { BackupScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.HELP) { HelpScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.QUIZ) {
                QuizScreen(
                    vm = quizVm,
                    onExit = {
                        quizVm.clear()
                        leave(Routes.QUIZ)
                    },
                    onFinished = {
                        if (nav.currentBackStackEntry?.destination?.route == Routes.QUIZ) {
                            nav.navigate(Routes.RESULT) {
                                popUpTo(Routes.QUIZ) { inclusive = true }
                            }
                        }
                    }
                )
            }
            composable(Routes.RESULT) {
                ResultScreen(
                    vm = quizVm,
                    onDone = {
                        quizVm.clear()
                        leave(Routes.RESULT)
                    },
                    onRetryMistakes = {
                        if (quizVm.retryMistakes()) {
                            nav.navigate(Routes.QUIZ) {
                                popUpTo(Routes.RESULT) { inclusive = true }
                            }
                        }
                    }
                )
            }
        }
    }
}

private fun NavHostController.navigateToTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private fun NavHostController.openLesson(vm: MainViewModel, id: String) {
    vm.recordTopicViewed(id)
    navigate("${Routes.LESSON}/$id")
}
