package com.pmspreparation.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Common frame for the tool screens: coloured top bar with a back arrow. */
@Composable
fun ToolScaffold(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val header = hubHeaderColor(LocalHubPalette.current, LocalHubDark.current)
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(
            Modifier.fillMaxWidth().background(header).padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        content()
    }
}

@Composable
private fun SoftCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    Card(
        modifier = if (onClick != null) modifier.clickable(onClick = onClick) else modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp),
    ) { Box(Modifier.padding(14.dp)) { content() } }
}

private fun minutesText(ms: Long): String {
    val min = (ms / 60_000L).toInt()
    return if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"
}

// ------------------------------------------------------------------ Notes
@Composable
fun NotesScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var editing by remember { mutableStateOf<HubNote?>(null) }
    var creating by remember { mutableStateOf(false) }
    ToolScaffold("My notes", onBack) {
        Button(onClick = { creating = true }, modifier = Modifier.padding(16.dp).fillMaxWidth()) { Text("+ New note") }
        if (prefs.notes.isEmpty()) {
            Text(
                "No notes yet. Write quick notes for any subject here.",
                modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(
            Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(prefs.notes, key = { it.id }) { n ->
                SoftCard(Modifier.fillMaxWidth(), onClick = { editing = n }) {
                    Column {
                        if (n.title.isNotBlank()) Text(n.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        if (n.text.isNotBlank()) Text(
                            n.text, maxLines = 4, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp,
                        )
                    }
                }
            }
        }
    }
    if (creating || editing != null) {
        val note = editing
        var title by remember(note) { mutableStateOf(note?.title ?: "") }
        var text by remember(note) { mutableStateOf(note?.text ?: "") }
        val close = { creating = false; editing = null }
        AlertDialog(
            onDismissRequest = close,
            title = { Text(if (note == null) "New note" else "Edit note") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it.take(80) }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Note") }, minLines = 4, maxLines = 8)
                }
            },
            confirmButton = { TextButton(onClick = { prefs.saveNote(note?.id, title, text); close() }) { Text("Save") } },
            dismissButton = {
                Row {
                    if (note != null) TextButton(onClick = { prefs.deleteNote(note.id); close() }) { Text("Delete") }
                    TextButton(onClick = close) { Text("Cancel") }
                }
            },
        )
    }
}

// ------------------------------------------------------------------ Checklist
@Composable
fun ChecklistScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val done = prefs.tasks.count { it.done }
    ToolScaffold("My checklist", onBack) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "Add your own syllabus topics or tasks and tick them off.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it.take(120) }, modifier = Modifier.weight(1f),
                    singleLine = true, placeholder = { Text("New item") },
                )
                Button(onClick = { prefs.addTask(input); input = "" }) { Text("Add") }
            }
            if (prefs.tasks.isNotEmpty()) Text("$done of ${prefs.tasks.size} done", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
            itemsIndexed(prefs.tasks) { i, t ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = t.done, onCheckedChange = { prefs.toggleTask(i) })
                    Text(
                        t.text, Modifier.weight(1f),
                        color = if (t.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    )
                    IconButton(onClick = { prefs.deleteTask(i) }) { Icon(Icons.Filled.Close, contentDescription = "Delete") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Pomodoro
@Composable
fun PomodoroScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var focus by rememberSaveable { mutableStateOf(true) }
    var remaining by rememberSaveable { mutableIntStateOf(25 * 60) }
    var running by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(running, focus) {
        while (running) {
            delay(1000)
            remaining -= 1
            if (remaining <= 0) {
                if (focus) prefs.recordPomodoro()
                focus = !focus
                remaining = if (focus) 25 * 60 else 5 * 60
                running = false
            }
        }
    }

    ToolScaffold("Pomodoro timer", onBack) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            Text(
                if (focus) "Focus time" else "Break time", fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "%02d:%02d".format(remaining / 60, remaining % 60), fontSize = 72.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { running = !running }) { Text(if (running) "Pause" else "Start") }
                OutlinedButton(onClick = { running = false; remaining = if (focus) 25 * 60 else 5 * 60 }) { Text("Reset") }
                OutlinedButton(onClick = { running = false; focus = !focus; remaining = if (focus) 25 * 60 else 5 * 60 }) {
                    Text(if (focus) "Skip to break" else "Skip to focus")
                }
            }
            Spacer(Modifier.height(28.dp))
            Text("Completed focus sessions: ${prefs.pomodoros}", color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(6.dp))
            Text(
                "25 minutes focus, then 5 minutes break. Each finished focus session is added to your study time. Keep this screen open while the timer runs.",
                fontSize = 12.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ------------------------------------------------------------------ Streak calendar
@Composable
fun CalendarScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val version = prefs.logVersion
    val active = remember(version) { prefs.activeDays() }
    var offset by rememberSaveable { mutableIntStateOf(0) }

    val cal = Calendar.getInstance()
    cal.set(Calendar.DAY_OF_MONTH, 1)
    cal.add(Calendar.MONTH, offset)
    val year = cal.get(Calendar.YEAR)
    val month = cal.get(Calendar.MONTH)
    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstColumn = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Monday = 0
    val monthName = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(cal.time)
    val today = prefs.today()

    ToolScaffold("Study calendar", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SoftCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🔥", fontSize = 28.sp)
                    Spacer(Modifier.size(10.dp))
                    Column {
                        Text("${prefs.streak} day streak", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text("${active.size} days studied in total", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            SoftCard(Modifier.fillMaxWidth()) {
                Column {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { offset-- }) { Text("<") }
                        Text(
                            monthName, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        TextButton(onClick = { offset++ }, enabled = offset < 0) { Text(">") }
                    }
                    Row(Modifier.fillMaxWidth()) {
                        listOf("M", "T", "W", "T", "F", "S", "S").forEach {
                            Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    val cells = firstColumn + daysInMonth
                    val rows = (cells + 6) / 7
                    for (r in 0 until rows) {
                        Row(Modifier.fillMaxWidth()) {
                            for (c in 0 until 7) {
                                val day = r * 7 + c - firstColumn + 1
                                Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp), contentAlignment = Alignment.Center) {
                                    if (day in 1..daysInMonth) {
                                        val dc = Calendar.getInstance()
                                        dc.set(year, month, day, 12, 0, 0)
                                        val dn = epochDayOf(dc)
                                        val on = dn in active
                                        Box(
                                            Modifier.fillMaxSize().clip(CircleShape)
                                                .background(if (on) MaterialTheme.colorScheme.primary else if (dn == today) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text(
                                                "$day", fontSize = 12.sp,
                                                color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text(
                "A coloured day means you spent time studying inside the apps or with the timer.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ------------------------------------------------------------------ Badges
private class Badge(val title: String, val text: String, val earned: Boolean)

@Composable
fun BadgesScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val version = prefs.logVersion
    val totalHours = remember(version) { prefs.totalMs() / 3_600_000.0 }
    val appsUsed = remember(version) { prefs.appsUsed() }
    val badges = listOf(
        Badge("First steps", "Study for 10 minutes in total", totalHours >= 10.0 / 60.0),
        Badge("3-day streak", "Open the app 3 days in a row", prefs.streak >= 3),
        Badge("Week warrior", "7-day streak", prefs.streak >= 7),
        Badge("Month master", "30-day streak", prefs.streak >= 30),
        Badge("10 hours", "Study 10 hours in total", totalHours >= 10.0),
        Badge("50 hours", "Study 50 hours in total", totalHours >= 50.0),
        Badge("Explorer", "Use every app at least once", appsUsed >= SUB_APPS.size),
        Badge("Test taker", "Finish a mixed MCQ test", prefs.mockTests >= 1),
        Badge("Test champion", "Finish 10 mixed MCQ tests", prefs.mockTests >= 10),
        Badge("Focused", "Finish 5 pomodoro sessions", prefs.pomodoros >= 5),
        Badge("Note keeper", "Write a note", prefs.notes.isNotEmpty()),
        Badge("Planner", "Set an exam date", prefs.examDay >= 0),
    )
    ToolScaffold("Badges", onBack) {
        Text(
            "${badges.count { it.earned }} of ${badges.size} earned", modifier = Modifier.padding(16.dp),
            fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground,
        )
        LazyColumn(
            Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(badges) { b ->
                SoftCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (b.earned) "🏆" else "🔒", fontSize = 26.sp)
                        Spacer(Modifier.size(12.dp))
                        Column {
                            Text(
                                b.title, fontWeight = FontWeight.Bold,
                                color = if (b.earned) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(b.text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Weekly report
@Composable
fun ReportScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val version = prefs.logVersion
    val today = prefs.today()
    val days = remember(version) { (6 downTo 0).map { today - it } }
    val values = remember(version) { days.map { prefs.dayMs(it) } }
    val labels = remember {
        (6 downTo 0).map {
            val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, -it)
            SimpleDateFormat("EEE", Locale.ENGLISH).format(c.time)
        }
    }
    val perApp = remember(version) { SUB_APPS.map { app -> app to days.sumOf { d -> prefs.appMs(d, app.id) } } }
    val total = values.sum()
    val maxV = (values.maxOrNull() ?: 0L).coerceAtLeast(1L)
    val goalMs = prefs.dailyGoal * 60_000L
    val goalDays = values.count { it >= goalMs }

    ToolScaffold("Weekly report", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SoftCard(Modifier.fillMaxWidth()) {
                Column {
                    Text("Last 7 days", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        "Total ${minutesText(total)}  ·  average ${minutesText(total / 7)} per day  ·  goal reached on $goalDays of 7 days",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().height(150.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        values.forEachIndexed { i, v ->
                            Column(Modifier.weight(1f).fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                                Text(if (v > 0) "${v / 60_000L}" else "", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Box(
                                    Modifier.fillMaxWidth().height((100.0 * v / maxV).dp.coerceAtLeast(3.dp))
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (v >= goalMs) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary)
                                )
                                Text(labels[i], fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Text("Numbers on the bars are minutes.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            SoftCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Time per app", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    perApp.forEach { (app, ms) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).clip(CircleShape).background(app.accent))
                            Spacer(Modifier.size(8.dp))
                            Text(app.title, Modifier.weight(1f), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(minutesText(ms), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            val missed = perApp.filter { it.second == 0L }.map { it.first.title }
            SoftCard(Modifier.fillMaxWidth()) {
                Column {
                    Text("Not opened this week", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        if (missed.isEmpty()) "Great, you opened every app." else missed.joinToString(", "),
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
