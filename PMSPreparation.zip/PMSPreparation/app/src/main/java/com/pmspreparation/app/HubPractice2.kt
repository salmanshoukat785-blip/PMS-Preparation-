package com.pmspreparation.app

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

// ---------------------------------------------------------------- question builders

private fun readAsset(ctx: Context, path: String): String? = try {
    ctx.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
} catch (e: Exception) { null }

/** Makes a multiple-choice question with the right answer at a random position. */
private fun mcq(source: String, q: String, right: String, wrong: List<String>, topic: String, explanation: String = ""): HubContent.Mcq {
    val opts = (wrong.filter { it != right }.distinct().take(3) + right).shuffled()
    return HubContent.Mcq(source, q, opts, opts.indexOf(right), explanation, topic)
}

private fun grammarQuestions(ctx: Context, keep: (JSONObject) -> Boolean): List<HubContent.Mcq> {
    val s = readAsset(ctx, "grammar/questions.json") ?: return emptyList()
    val arr = JSONArray(s)
    val out = ArrayList<HubContent.Mcq>()
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        if (!keep(o)) continue
        val opts = o.optJSONArray("options")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: continue
        val ans = o.optInt("answer", 0)
        if (opts.size < 2 || ans !in opts.indices) continue
        out.add(HubContent.Mcq("English Grammar", o.optString("q"), opts, ans, o.optString("explanation"), o.optString("topic").replace('_', ' ')))
    }
    return out
}

private fun idiomQuestions(ctx: Context): List<HubContent.Mcq> {
    val s = readAsset(ctx, "essay/idioms.json") ?: return emptyList()
    val arr = JSONObject(s).optJSONArray("idioms") ?: return emptyList()
    val items = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.filter { it.optString("phrase").isNotBlank() && it.optString("meaning").isNotBlank() }
    val meanings = items.map { it.optString("meaning") }
    val fromEssay = items.map { o ->
        mcq("Idioms", "What does \"${o.optString("phrase")}\" mean?", o.optString("meaning"), meanings.shuffled(), "Idioms and phrases",
            o.optString("example").let { if (it.isBlank()) "" else "Example: $it" })
    }
    return fromEssay + grammarQuestions(ctx) { it.optString("topic") == "idioms" }
}

/** Definition to the one word that means it. */
private val ONE_WORD = listOf(
    "A person who loves books" to "bibliophile", "One who lives in a foreign country permanently" to "expatriate",
    "A government by the people" to "democracy", "A government by a few" to "oligarchy", "Rule by one person with absolute power" to "autocracy",
    "Killing of a king or a political leader" to "assassination", "A person who does not believe in God" to "atheist",
    "One who believes that God and nature are the same" to "pantheist", "A person who is present everywhere" to "omnipresent",
    "Having power to do anything" to "omnipotent", "Knowing everything" to "omniscient", "A person who eats too much" to "glutton",
    "A person who does not eat meat" to "vegetarian", "One who eats human flesh" to "cannibal", "A person who walks in sleep" to "somnambulist",
    "A medicine that prevents disease" to "preventive", "A cure for all diseases" to "panacea", "That which cannot be read" to "illegible",
    "That which cannot be heard" to "inaudible", "That which cannot be seen" to "invisible", "That which cannot be defeated" to "invincible",
    "That which cannot be avoided" to "inevitable", "That which cannot be believed" to "incredible", "That which cannot be corrected" to "incorrigible",
    "A person who is fond of fighting" to "belligerent", "The study of ancient things" to "archaeology", "The study of birds" to "ornithology",
    "The study of the human mind" to "psychology", "The study of the origin of words" to "etymology", "The study of earthquakes" to "seismology",
    "A person who leaves one country to settle in another" to "immigrant", "A person who leaves his own country to settle abroad" to "emigrant",
    "A speech made without preparation" to "extempore", "A speech delivered by one person alone" to "monologue", "A talk between two persons" to "dialogue",
    "A place where birds are kept" to "aviary", "A place where bees are kept" to "apiary", "A place where monks live" to "monastery",
    "A place where weapons are stored" to "arsenal", "A place for burying the dead" to "cemetery", "A collection of poems" to "anthology",
    "A government by priests" to "theocracy", "A government run by officials" to "bureaucracy", "A rule by the rich" to "plutocracy",
    "Fear of open spaces" to "agoraphobia", "Fear of closed places" to "claustrophobia", "Fear of water" to "hydrophobia",
    "A person who cannot be bribed" to "incorruptible", "Life history of a person written by himself" to "autobiography",
    "Life history of a person written by another" to "biography", "A person who talks too much" to "garrulous",
    "A sudden and violent attack by an enemy" to "raid", "Official order forbidding something" to "ban", "A person who is new to a field" to "novice",
    "Easy to understand and clear" to "lucid", "Too proud and haughty" to "arrogant", "Willing to spend and give freely" to "generous",
)

private fun oneWordQuestions(): List<HubContent.Mcq> {
    val words = ONE_WORD.map { it.second }
    return ONE_WORD.map { (def, w) -> mcq("One word", "One word for: $def", w, words.shuffled(), "One-word substitution") }
}

private fun vocabQuestions(ctx: Context, mode: String): List<HubContent.Mcq> {
    val all = loadVocab(ctx).filter { it.general }
    val withUrdu = all.filter { it.urdu.isNotBlank() && it.urdu.length < 40 }
    return when (mode) {
        "enur" -> withUrdu.map { mcq("Vocabulary", "Urdu meaning of \"${it.word}\"?", it.urdu, withUrdu.shuffled().take(8).map { x -> x.urdu }, "Vocabulary", it.meaning) }
        "uren" -> withUrdu.map { mcq("Vocabulary", "Which word means: ${it.urdu}", it.word, withUrdu.shuffled().take(8).map { x -> x.word }, "Vocabulary", it.meaning) }
        "syn" -> all.filter { it.syn.isNotEmpty() }.map { w ->
            mcq("Vocabulary", "Closest in meaning to \"${w.word}\"", w.syn.random(), all.shuffled().take(12).map { x -> x.word }.filter { x -> x !in w.syn && x != w.word }, "Synonyms", "Synonyms: " + w.syn.joinToString(", "))
        }
        else -> all.filter { it.ant.isNotEmpty() }.map { w ->
            mcq("Vocabulary", "Opposite of \"${w.word}\"", w.ant.random(), all.shuffled().take(12).map { x -> x.word }.filter { x -> x !in w.ant && x != w.word }, "Antonyms", "Antonyms: " + w.ant.joinToString(", "))
        }
    }
}

/** True/False statements made from normal MCQs: a question with one proposed answer. */
private fun trueFalse(ctx: Context): List<HubContent.Mcq> {
    val pool = HubContent.MCQ_SOURCES.flatMap { HubContent.mcqs(ctx, it.first) }.shuffled().take(300)
    return pool.map { m ->
        val showRight = (0..1).random() == 0
        val wrongIdx = m.options.indices.filter { it != m.answer }.random()
        val shown = if (showRight) m.options[m.answer] else m.options[wrongIdx]
        HubContent.Mcq(
            m.source, "True or false?\n${m.q}\nProposed answer: $shown", listOf("True", "False"),
            if (showRight) 0 else 1, "Correct answer: ${m.options[m.answer]}. ${m.explanation}".trim(), m.topic,
        )
    }
}

// ---------------------------------------------------------------- shared test screen

/** Builds the questions in the background, then runs them with the normal MCQ runner. */
@Composable
private fun GeneratedTest(
    prefs: HubPrefs, title: String, onBack: () -> Unit, intro: String, limitSec: Int, count: Int,
    key: Any, build: (Context) -> List<HubContent.Mcq>,
) {
    val ctx = LocalContext.current.applicationContext
    var questions by remember(key) { mutableStateOf<List<HubContent.Mcq>?>(null) }
    var running by remember(key) { mutableStateOf(false) }
    LaunchedEffect(key) {
        questions = withContext(Dispatchers.Default) {
            build(ctx).filter { it.q.isNotBlank() && it.options.size >= 2 && it.answer in it.options.indices }.shuffled().take(count)
        }
    }
    ToolScaffold(title, onBack) {
        val qs = questions
        when {
            qs == null -> Text("Preparing questions...", modifier = Modifier.padding(16.dp))
            qs.isEmpty() -> Text("No questions available for this test.", modifier = Modifier.padding(16.dp))
            !running -> Column(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(intro, color = MaterialTheme.colorScheme.onBackground)
                Text(
                    "${qs.size} questions" + if (limitSec > 0) "  •  ${limitSec / 60}:%02d".format(limitSec % 60) else "",
                    fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary,
                )
                Button(onClick = { running = true }, modifier = Modifier.fillMaxWidth()) { Text("Start") }
            }
            else -> Box(Modifier.weight(1f)) {
                McqRunner(
                    prefs = prefs, questions = qs, limitSec = limitSec,
                    onResult = { q, ok -> if (!ok) prefs.addMistake(q) },
                    onFinished = { _, _ -> prefs.recordMock() },
                    onClose = onBack,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- screens

@Composable
fun VocabQuizScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var mode by remember { mutableStateOf("") }
    if (mode.isEmpty()) {
        ToolScaffold("Vocabulary quiz", onBack) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Choose a quiz type. 15 questions from the Vocabulary tab words.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                listOf(
                    "enur" to "English word to Urdu meaning", "uren" to "Urdu meaning to English word",
                    "syn" to "Pick the synonym", "ant" to "Pick the antonym",
                ).forEach { (k, label) -> Button(onClick = { mode = k }, modifier = Modifier.fillMaxWidth()) { Text(label) } }
            }
        }
    } else {
        GeneratedTest(prefs, "Vocabulary quiz", { mode = "" }, "Pick the right answer.", 0, 15, mode) { vocabQuestions(it, mode) }
    }
}

@Composable
fun SentenceFixScreen(prefs: HubPrefs, onBack: () -> Unit) =
    GeneratedTest(prefs, "Sentence correction", onBack, "Find the correct form of each sentence.", 0, 15, "sc") { ctx ->
        grammarQuestions(ctx) { it.optString("topic") == "sentence_correction" || it.optString("topic") == "subject_verb_agreement" }
    }

@Composable
fun ClozeScreen(prefs: HubPrefs, onBack: () -> Unit) =
    GeneratedTest(prefs, "Fill in the blank", onBack, "Choose the word that completes the sentence.", 0, 15, "cloze") { ctx ->
        grammarQuestions(ctx) { it.optString("type") == "FILL" }
    }

@Composable
fun IdiomTestScreen(prefs: HubPrefs, onBack: () -> Unit) =
    GeneratedTest(prefs, "Idiom and phrase test", onBack, "Meanings and use of idioms from the Essay app and the Grammar app.", 0, 15, "idiom") { idiomQuestions(it) }

@Composable
fun OneWordScreen(prefs: HubPrefs, onBack: () -> Unit) =
    GeneratedTest(prefs, "One-word substitution", onBack, "Choose the single word that replaces the phrase.", 0, 15, "ow") { oneWordQuestions() }

@Composable
fun TrueFalseScreen(prefs: HubPrefs, onBack: () -> Unit) =
    GeneratedTest(prefs, "True or false", onBack, "Questions from all apps turned into statements. Decide if the proposed answer is right.", 0, 20, "tf") { trueFalse(it) }

@Composable
fun SpeedRoundScreen(prefs: HubPrefs, onBack: () -> Unit) =
    GeneratedTest(prefs, "Speed round", onBack, "Answer as many as you can in 60 seconds.", 60, 100, "speed") { ctx ->
        HubContent.MCQ_SOURCES.flatMap { HubContent.mcqs(ctx, it.first) }
    }

/** Subject-wise mock: all questions of one subject across the merged apps. */
@Composable
fun SubjectMockScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var subject by remember { mutableStateOf("") }
    var count by remember { mutableIntStateOf(20) }
    var timed by remember { mutableStateOf(true) }
    var started by remember { mutableStateOf(false) }
    if (!started) {
        ToolScaffold("Subject-wise mock", onBack) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Subject", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                HubContent.SUBJECTS.forEach { (name, _) ->
                    FilterChip(selected = subject == name, onClick = { subject = name }, label = { Text(name) })
                }
                Text("Questions", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(10, 20, 30, 50).forEach { n -> FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") }) }
                }
                FilterChip(selected = timed, onClick = { timed = !timed }, label = { Text(if (timed) "Timed: 1 minute per question" else "No time limit") })
                Button(onClick = { started = true }, enabled = subject.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Prepare test") }
            }
        }
    } else {
        val sources = HubContent.SUBJECTS.firstOrNull { it.first == subject }?.second ?: emptyList()
        GeneratedTest(prefs, subject, { started = false }, "Questions from the $subject app(s), mixed together.", if (timed) count * 60 else 0, count, subject + count) { ctx ->
            sources.flatMap { HubContent.mcqs(ctx, it) }
        }
    }
}

/** Solve a past paper against the clock, then give yourself marks question by question. */
@Composable
fun PaperMarkerScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var total by remember { mutableStateOf("100") }
    var minutes by remember { mutableStateOf("180") }
    var questions by remember { mutableStateOf("5") }
    var phase by remember { mutableStateOf("setup") }   // setup | solving | marking | done
    var left by remember { mutableIntStateOf(0) }
    val marks = remember { mutableStateOf(mapOf<Int, String>()) }
    LaunchedEffect(phase) {
        if (phase == "solving") {
            while (left > 0 && phase == "solving") { delay(1000); left -= 1 }
            if (phase == "solving") phase = "marking"
        }
    }
    val qn = questions.toIntOrNull()?.coerceIn(1, 30) ?: 5
    val tot = total.toIntOrNull() ?: 100
    ToolScaffold("Paper solve and mark", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (phase) {
                "setup" -> {
                    Text("Solve a real past paper on paper with a timer, then mark yourself. Past papers are not bundled; use the Past papers tool to keep your links.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(name, { name = it }, label = { Text("Paper (subject and year)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(total, { total = it.filter(Char::isDigit) }, label = { Text("Total marks") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit) }, label = { Text("Time in minutes") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(questions, { questions = it.filter(Char::isDigit) }, label = { Text("Number of questions") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { left = (minutes.toIntOrNull() ?: 180) * 60; phase = "solving" }, modifier = Modifier.fillMaxWidth()) { Text("Start the clock") }
                    val history = prefs.recs("pmark")
                    if (history.isNotEmpty()) {
                        Text("Earlier attempts", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                        history.take(10).forEach { Text("${it.a}: ${it.n} / ${it.b}", fontSize = 13.sp) }
                    }
                }
                "solving" -> {
                    Text("%d:%02d left".format(left / 60, left % 60), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = if (left < 600) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    Text(name.ifBlank { "Paper" }, color = MaterialTheme.colorScheme.onBackground)
                    Button(onClick = { phase = "marking" }, modifier = Modifier.fillMaxWidth()) { Text("I have finished") }
                }
                "marking" -> {
                    Text("Marks per question (out of ${tot / qn} each if equal)", color = MaterialTheme.colorScheme.onBackground)
                    for (i in 1..qn) {
                        OutlinedTextField(
                            marks.value[i] ?: "", { v -> marks.value = marks.value + (i to v.filter(Char::isDigit)) },
                            label = { Text("Question $i") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    Button(onClick = {
                        val got = marks.value.values.sumOf { it.toIntOrNull() ?: 0 }
                        prefs.addRec("pmark", HubRec(System.currentTimeMillis(), name.ifBlank { "Paper" }, tot.toString(), "", "", got, System.currentTimeMillis()))
                        phase = "done"
                    }, modifier = Modifier.fillMaxWidth()) { Text("Save result") }
                }
                else -> {
                    val got = marks.value.values.sumOf { it.toIntOrNull() ?: 0 }
                    Text("Result: $got / $tot  (${if (tot > 0) got * 100 / tot else 0}%)", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(if (tot > 0 && got * 100 / tot >= 40) "Above the usual 40% pass line." else "Below the usual 40% pass line. Revise the weakest questions.", color = MaterialTheme.colorScheme.onBackground)
                    Spacer(Modifier.height(4.dp))
                    Button(onClick = { marks.value = emptyMap(); phase = "setup" }, modifier = Modifier.fillMaxWidth()) { Text("New attempt") }
                }
            }
        }
    }
}
