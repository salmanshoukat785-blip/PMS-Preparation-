@file:OptIn(ExperimentalMaterial3Api::class)

package com.pmspreparation.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val SEP2 = "\u001F"

private fun allMcqs(ctx: android.content.Context, ids: Collection<String>): List<HubContent.Mcq> =
    ids.flatMap { HubContent.mcqs(ctx, it) }

private fun recToMcq(r: HubRec): HubContent.Mcq {
    val parts = r.d.split(SEP2)
    return HubContent.Mcq(parts[0], r.a, r.b.split(SEP2), r.n, r.c, parts.getOrElse(1) { "" })
}

// ------------------------------------------------------------------ Weak topics
@Composable
fun WeakTopicsScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val groups by produceState<List<SylGroup>>(emptyList()) { value = withContext(Dispatchers.IO) { HubSyllabus.load(ctx) } }
    val mist = prefs.recs("mist")
    val grouped = mist.groupBy { r -> r.d.split(SEP2).filter { it.isNotBlank() }.joinToString(" · ") }
        .map { it.key to it.value }.sortedByDescending { it.second.size }
    var practicing by remember { mutableStateOf<List<HubContent.Mcq>?>(null) }
    val today = prefs.today()
    val overdue = prefs.recs("rev").filter { it.n < 4 && it.m + intArrayOf(1, 3, 7, 30)[it.n] < today }
    val papers = groups.flatMap { g -> g.papers.map { g to it } }
        .filter { it.second.topicCount > 0 }
        .sortedBy { doneCount(prefs, it.first, it.second).toFloat() / it.second.topicCount }

    ToolScaffold("Weak topics", onBack) {
        val run = practicing
        if (run != null) {
            McqRunner(prefs, run, 0, onResult = { q, ok -> if (ok) prefs.removeRec("mist", q.q.hashCode().toLong()) }, onFinished = { _, _ -> }, onClose = { practicing = null })
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    "Worked out from your wrong answers, overdue revisions and syllabus coverage.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text("Topics with the most mistakes", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                if (grouped.isEmpty()) Text("No mistakes yet. Take a test first.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                grouped.take(10).forEach { (label, list) ->
                    SoftCard(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(label.ifBlank { "Other" }, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                Text("${list.size} mistake${if (list.size > 1) "s" else ""}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            OutlinedButton(onClick = { practicing = list.map { recToMcq(it) }.shuffled() }) { Text("Practice") }
                        }
                    }
                }
                Text("Revisions overdue: ${overdue.size}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                overdue.take(5).forEach { Text("•  ${it.a}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface) }
                Text("Least covered papers", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                papers.take(3).forEach { (g, p) ->
                    val d = doneCount(prefs, g, p)
                    Text("Paper ${p.no}: ${p.title}  ($d / ${p.topicCount})", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Smart revision plan
@Composable
fun SmartPlanScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val groups by produceState<List<SylGroup>>(emptyList()) { value = withContext(Dispatchers.IO) { HubSyllabus.load(ctx) } }
    val today = prefs.today()
    val daysLeft = if (prefs.examDay >= 0) (prefs.examDay - today).toInt() else -1
    // Topics not ticked yet, in syllabus order.
    val remaining = ArrayList<String>()
    groups.forEach { g ->
        g.papers.forEach { p ->
            p.sections.forEachIndexed { s, sec ->
                sec.items.forEachIndexed { i, item ->
                    if (doneKey(g, p, s, i) !in prefs.sylDone) remaining.add("Paper ${p.no}: $item")
                }
            }
        }
    }
    ToolScaffold("Smart revision plan", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (daysLeft <= 0) {
                Text("Set your exam date in Settings. The plan is made from the days that are left.", color = MaterialTheme.colorScheme.onSurface)
            } else {
                // The last 7 days are kept for revision when there is enough time.
                val studyDays = if (daysLeft > 14) daysLeft - 7 else daysLeft
                val perDay = ((remaining.size + studyDays - 1) / studyDays).coerceAtLeast(1)
                Text(
                    "$daysLeft days left  ·  ${remaining.size} topics to go  ·  about $perDay topics a day" +
                        if (daysLeft > 14) "  ·  last 7 days for revision" else "",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                val rev = prefs.recs("rev")
                val offsets = intArrayOf(1, 3, 7, 30)
                for (i in 0 until minOf(14, daysLeft)) {
                    val day = today + i
                    val revDue = rev.count { it.n < 4 && maxOf(it.m + offsets[it.n], today) == day }
                    val isRevisionWeek = daysLeft > 14 && i >= studyDays
                    val slice = if (isRevisionWeek) emptyList() else remaining.drop(i * perDay).take(perDay)
                    SoftCard(Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                (if (i == 0) "Today  ·  " else "") + xDayText(day), fontWeight = FontWeight.Bold,
                                color = if (i == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            )
                            if (isRevisionWeek) Text("Revision week: go through all papers again.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            slice.take(6).forEach { Text("•  $it", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface) }
                            if (slice.size > 6) Text("+ ${slice.size - 6} more", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (slice.isEmpty() && !isRevisionWeek) Text("Nothing new planned. Use the time for revision and tests.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (revDue > 0) Text("Revisions due: $revDue", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Topic-wise test
@Composable
fun TopicTestScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    var source by remember { mutableStateOf("pak") }
    val questions by produceState<List<HubContent.Mcq>?>(null, source) {
        value = null
        value = withContext(Dispatchers.IO) { allMcqs(ctx, listOf(source)) }
    }
    var run by remember { mutableStateOf<List<HubContent.Mcq>?>(null) }
    ToolScaffold("Topic-wise test", onBack) {
        val r = run
        if (r != null) {
            McqRunner(prefs, r, 0, onResult = { q, ok -> if (!ok) prefs.addMistake(q) }, onFinished = { _, _ -> prefs.recordMock() }, onClose = { run = null })
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HubContent.MCQ_SOURCES.forEach { (id, label) ->
                        FilterChip(selected = source == id, onClick = { source = id }, label = { Text(label, fontSize = 12.sp) })
                    }
                }
                val list = questions
                if (list == null) {
                    Text("Loading...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val topics = list.groupBy { it.topic.ifBlank { "Other" } }.toList().sortedBy { it.first }
                    Text("${topics.size} topics", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    topics.forEach { (name, qs) ->
                        SoftCard(Modifier.fillMaxWidth(), onClick = { run = qs.shuffled().take(20) }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(name, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                                Text("${qs.size} Qs", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Saved questions
@Composable
fun SavedQuestionsScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val list = prefs.recs("qbm")
    var run by remember { mutableStateOf<List<HubContent.Mcq>?>(null) }
    ToolScaffold("Saved questions", onBack) {
        val r = run
        if (r != null) {
            McqRunner(prefs, r, 0, onResult = { q, ok -> if (!ok) prefs.addMistake(q) }, onFinished = { _, _ -> }, onClose = { run = null })
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Questions you starred while solving a test.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { run = list.map { recToMcq(it) }.shuffled() }, enabled = list.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                    Text("Practice ${list.size} saved questions")
                }
                list.forEach { rec ->
                    SoftCard(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text(rec.a, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                Text(rec.d.split(SEP2).filter { it.isNotBlank() }.joinToString(" · "), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { prefs.removeRec("qbm", rec.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Remove") }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Open recall
@Composable
fun RecallScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val cards by produceState<List<HubContent.Recall>?>(null) { value = withContext(Dispatchers.IO) { HubContent.recallCards(ctx).shuffled().take(25) } }
    var index by remember { mutableIntStateOf(0) }
    var shown by remember { mutableStateOf(false) }
    var knew by remember { mutableIntStateOf(0) }
    ToolScaffold("Open recall", onBack) {
        val list = cards
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when {
                list == null -> Text("Loading...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                list.isEmpty() -> Text("No cards found.", color = MaterialTheme.colorScheme.error)
                index >= list.size -> {
                    Text("Done: you knew $knew of ${list.size}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Button(onClick = { index = 0; knew = 0; shown = false }, modifier = Modifier.fillMaxWidth()) { Text("Go again") }
                }
                else -> {
                    val c = list[index]
                    Text("Card ${index + 1} of ${list.size}  ·  ${c.topic}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Say or write everything you remember about:", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    SoftCard(Modifier.fillMaxWidth()) {
                        Text(c.heading, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    if (!shown) {
                        Button(onClick = { shown = true }, modifier = Modifier.fillMaxWidth()) { Text("Show answer") }
                    } else {
                        SoftCard(Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(c.short, color = MaterialTheme.colorScheme.onSurface)
                                if (c.long.isNotBlank()) Text(c.long, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = { index++; shown = false }, modifier = Modifier.weight(1f)) { Text("Need practice") }
                            Button(onClick = { knew++; index++; shown = false }, modifier = Modifier.weight(1f)) { Text("I knew it") }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Essay outline builder
@Composable
fun OutlineScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val titles by produceState<List<String>>(emptyList()) { value = withContext(Dispatchers.IO) { HubContent.essayTitles(ctx) } }
    var title by remember { mutableStateOf("") }
    var hook by remember { mutableStateOf("") }
    var thesis by remember { mutableStateOf("") }
    val body = remember { mutableStateListOf("", "", "") }
    var counter by remember { mutableStateOf("") }
    var conclusion by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    ToolScaffold("Essay outline builder", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Essay title") }, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { if (titles.isNotEmpty()) title = titles.random() }, enabled = titles.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Random title from the Essay app") }
            Text("Introduction", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            OutlinedTextField(value = hook, onValueChange = { hook = it }, label = { Text("Hook (quote, fact or question)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = thesis, onValueChange = { thesis = it }, label = { Text("Thesis statement") }, modifier = Modifier.fillMaxWidth())
            Text("Body points", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            body.forEachIndexed { i, v ->
                OutlinedTextField(value = v, onValueChange = { body[i] = it }, label = { Text("Point ${i + 1}") }, modifier = Modifier.fillMaxWidth())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { if (body.size < 8) body.add("") }) { Text("+ Add point") }
                OutlinedButton(onClick = { if (body.size > 1) body.removeAt(body.size - 1) }) { Text("Remove last") }
            }
            OutlinedTextField(value = counter, onValueChange = { counter = it }, label = { Text("Counter-argument and reply") }, modifier = Modifier.fillMaxWidth())
            Text("Conclusion", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            OutlinedTextField(value = conclusion, onValueChange = { conclusion = it }, label = { Text("Restate thesis and close") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                val sb = StringBuilder()
                sb.append("Hook: ").append(hook).append("\n")
                sb.append("Thesis: ").append(thesis).append("\n\n")
                body.filter { it.isNotBlank() }.forEachIndexed { i, p -> sb.append("${i + 1}. ").append(p).append("\n") }
                if (counter.isNotBlank()) sb.append("\nCounter-argument: ").append(counter).append("\n")
                sb.append("\nConclusion: ").append(conclusion)
                prefs.saveNote(null, "Outline: ${title.ifBlank { "Essay" }}", sb.toString())
                saved = true
            }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Save outline to My notes") }
            if (saved) Text("Saved in My notes.", color = MaterialTheme.colorScheme.primary)
        }
    }
}

// ------------------------------------------------------------------ Writing checker
private val FILLERS = listOf("very", "really", "thing", "things", "nice", "good", "bad", "stuff", "basically", "actually", "lots", "a lot")

@Composable
fun WritingReport(text: String) {
    val words = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (words.isEmpty()) return
    val sentences = text.split(Regex("(?<=[.!?؟۔])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
    val lens = sentences.map { s -> s.split(Regex("\\s+")).count { it.isNotEmpty() } }
    val avg = if (lens.isEmpty()) 0 else lens.sum() / lens.size
    val longOnes = sentences.filterIndexed { i, _ -> lens[i] > 30 }
    val lower = words.map { it.lowercase().trim { c -> !c.isLetter() } }.filter { it.isNotEmpty() }
    val repeated = lower.filter { it.length >= 5 }.groupingBy { it }.eachCount().filter { it.value >= 4 }.entries.sortedByDescending { it.value }.take(5)
    val fillerCounts = FILLERS.map { f -> f to lower.count { it == f } }.filter { it.second > 0 }
    val starts = sentences.map { s -> s.split(Regex("\\s+")).first().lowercase().trim { c -> !c.isLetter() } }
        .groupingBy { it }.eachCount().filter { it.key.isNotEmpty() && it.value >= 3 }.entries.sortedByDescending { it.value }.take(3)
    val paragraphs = text.split(Regex("\\n\\s*\\n")).count { it.isNotBlank() }
    SoftCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Writing check", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text("${words.size} words  ·  ${sentences.size} sentences  ·  $paragraphs paragraphs", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
            Text("Average sentence: $avg words", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
            if (longOnes.isNotEmpty()) {
                Text("Long sentences (over 30 words): ${longOnes.size}. Consider splitting:", fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                longOnes.take(2).forEach { Text("•  ${it.take(90)}...", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            if (repeated.isNotEmpty()) Text("Repeated words: " + repeated.joinToString { "${it.key} (${it.value})" }, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
            if (fillerCounts.isNotEmpty()) Text("Weak or vague words: " + fillerCounts.joinToString { "${it.first} (${it.second})" }, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
            if (starts.isNotEmpty()) Text("Many sentences start with: " + starts.joinToString { "${it.key} (${it.value})" }, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
            if (longOnes.isEmpty() && repeated.isEmpty() && fillerCounts.isEmpty() && starts.isEmpty()) Text("No common problems found.", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
            Text("This is a basic offline check, not a full grammar checker.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun WritingCheckerScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var checked by remember { mutableStateOf("") }
    ToolScaffold("Writing checker", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Paste or write your text") }, modifier = Modifier.fillMaxWidth(), minLines = 8)
            Button(onClick = { checked = text }, enabled = text.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Check") }
            if (checked.isNotBlank()) WritingReport(checked)
        }
    }
}

// ------------------------------------------------------------------ Precis and comprehension
@Composable
fun PrecisScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var mode by remember { mutableStateOf("precis") }
    var passage by remember { mutableStateOf("") }
    var task by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var minutes by remember { mutableIntStateOf(30) }
    var left by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(running) {
        if (running) {
            while (left > 0 && running) { delay(1000); left -= 1 }
            if (running) { running = false; done = true }
        }
    }
    fun count(s: String) = s.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
    val pw = count(passage)
    val aw = count(answer)
    ToolScaffold("Precis and comprehension", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!running && !done) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = mode == "precis", onClick = { mode = "precis" }, label = { Text("Precis") })
                    FilterChip(selected = mode == "comp", onClick = { mode = "comp" }, label = { Text("Comprehension") })
                }
                OutlinedTextField(value = passage, onValueChange = { passage = it }, label = { Text("Paste the passage") }, modifier = Modifier.fillMaxWidth(), minLines = 6)
                if (mode == "comp") OutlinedTextField(value = task, onValueChange = { task = it }, label = { Text("Question") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 30, 45).forEach { m -> FilterChip(selected = minutes == m, onClick = { minutes = m }, label = { Text("$m min") }) }
                }
                if (mode == "precis" && pw > 0) Text("Passage: $pw words. A good precis is about ${pw / 3} words (one third).", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { answer = ""; left = minutes * 60; running = true }, enabled = pw > 0, modifier = Modifier.fillMaxWidth()) { Text("Start") }
            } else if (running) {
                Text("Time left: %d:%02d  ·  %d words".format(left / 60, left % 60, aw), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                if (mode == "precis") Text("Target about ${pw / 3} words", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (task.isNotBlank()) Text(task, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                OutlinedTextField(value = answer, onValueChange = { answer = it }, modifier = Modifier.fillMaxWidth(), minLines = 10)
                Button(onClick = { running = false; done = true }, modifier = Modifier.fillMaxWidth()) { Text("Finish") }
            } else {
                LaunchedEffect(done) {
                    prefs.saveNote(null, (if (mode == "precis") "Precis" else "Comprehension") + " practice", (if (task.isNotBlank()) "Q: $task\n\n" else "") + answer)
                }
                Text("Saved to My notes", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                if (mode == "precis" && pw > 0) {
                    val ratio = aw * 100 / pw
                    Text("Your precis is $aw words, $ratio% of the passage. A good precis is about 33%.", color = if (ratio in 25..40) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }
                WritingReport(answer)
                Button(onClick = { done = false; answer = ""; passage = ""; task = "" }, modifier = Modifier.fillMaxWidth()) { Text("New practice") }
            }
        }
    }
}

// ------------------------------------------------------------------ Quick facts sheet
@Composable
fun FactsScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val all = prefs.recs("facts")
    var query by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    val open = remember { mutableStateListOf<Long>() }
    val list = all.filter { query.isBlank() || it.a.contains(query, true) || it.b.contains(query, true) || it.c.contains(query, true) }
    ToolScaffold("Quick facts", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add fact") }
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Dates, formulas, definitions and numbers you want to remember. Tap a card to show or hide the answer.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            list.forEach { r ->
                SoftCard(Modifier.fillMaxWidth(), onClick = { if (r.id in open) open.remove(r.id) else open.add(r.id) }) {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(r.a, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            if (r.c.isNotBlank()) Text(r.c, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (r.id in open) Text(r.b, color = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { prefs.removeRec("facts", r.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }
    }
    if (adding) {
        var a by remember { mutableStateOf("") }
        var b by remember { mutableStateOf("") }
        var c by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("New fact") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = a, onValueChange = { a = it }, label = { Text("Question or title") })
                    OutlinedTextField(value = b, onValueChange = { b = it }, label = { Text("Answer") }, minLines = 2)
                    OutlinedTextField(value = c, onValueChange = { c = it }, label = { Text("Category (optional)") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(enabled = a.isNotBlank() && b.isNotBlank(), onClick = {
                    prefs.addRec("facts", HubRec(System.currentTimeMillis(), a.trim(), b.trim(), c.trim()))
                    adding = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } },
        )
    }
}
