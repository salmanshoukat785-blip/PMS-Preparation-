package com.pmspreparation.app

/** Urdu labels for the home page and navigation, plus the short tip shown the first time a tool opens. */
object HubText {
    private val UR = mapOf(
        "Home" to "ہوم", "Syllabus" to "نصاب", "Tools" to "ٹولز", "Favorites" to "پسندیدہ", "Search apps" to "ایپس تلاش کریں",
        "Study planner" to "اسٹڈی پلانر", "Revision" to "دہرائی", "Flashcards" to "فلیش کارڈز", "Daily challenge" to "روزانہ چیلنج",
        "Timed paper" to "ٹائمڈ پیپر", "Mistake notebook" to "غلطیوں کی کاپی", "Saved items" to "محفوظ اشیاء",
        "Past papers" to "پچھلے پرچے", "Current affairs" to "حالاتِ حاضرہ", "Essay practice" to "مضمون کی مشق",
        "Timetable" to "ٹائم ٹیبل", "Prayer-time blocks" to "نماز کے اوقات کے وقفے", "Focus mode" to "فوکس موڈ",
        "Level and points" to "لیول اور پوائنٹس", "Export to PDF" to "پی ڈی ایف", "Weak topics" to "کمزور موضوعات",
        "Smart revision plan" to "سمارٹ پلان", "Topic-wise test" to "موضوع وار ٹیسٹ", "Saved questions" to "محفوظ سوالات",
        "Open recall" to "یاد کی مشق", "Essay outline builder" to "مضمون کا خاکہ", "Precis and comprehension" to "پریسی اور فہم",
        "Writing checker" to "تحریر چیکر", "Quick facts" to "اہم حقائق", "My notes" to "میرے نوٹس", "Checklist" to "چیک لسٹ",
        "Pomodoro" to "پومودورو", "Mixed MCQ test" to "ملا جلا ٹیسٹ", "Report" to "رپورٹ", "Calendar" to "کیلنڈر", "Badges" to "بیجز",
    )

    fun t(prefs: HubPrefs, en: String): String = if (prefs.hubUrdu) UR[en] ?: en else en

    val TIPS = mapOf(
        "planner" to "Shows your syllabus coverage, a plan up to the exam and your weekly target. Set the exam date in Settings first.",
        "revision" to "Tick a syllabus topic and it comes back here after 1, 3, 7 and 30 days. Tap Revised when you have revised it.",
        "flashcards" to "Tap a card to see the meaning. Words you know return after longer gaps.",
        "daily" to "Ten questions every day from all your apps. Play once a day to build the habit.",
        "timed" to "Exam-style test with a countdown. The paper ends by itself when time is up.",
        "mistakes" to "Every wrong answer is saved here. Answer it correctly in practice and it leaves the list.",
        "saved" to "Bookmarks from search and the syllabus. Add a note to any item.",
        "pastpapers" to "No papers come with the app. Add your own papers with a link or note.",
        "affairs" to "Write each current-affairs item once, then revise it here. Filter by category.",
        "essay" to "Pick a title, set a timer and write. Your essay is saved in My notes and checked for common problems.",
        "timetable" to "Add study slots with a start time and length. The slot running now is highlighted.",
        "prayer" to "Enter today's prayer times. The app shows the free gaps between prayers for study.",
        "focus" to "The screen stays on during a session. Turn on Do Not Disturb yourself for fewer interruptions.",
        "level" to "Points come from study time, tests, pomodoros, topics and revisions.",
        "export" to "Make a PDF, JSON or CSV file and send or save it with any app.",
        "weak" to "Your weakest topics, from wrong answers, overdue revisions and syllabus coverage.",
        "smartplan" to "A day-by-day plan for the next two weeks. It changes as you tick topics.",
        "topictest" to "Choose a subject and then a topic to practise only that topic.",
        "savedq" to "Star a question while solving a test and practise your starred questions here.",
        "recall" to "Read the heading and try to remember everything before you show the answer.",
        "outline" to "Plan an essay with introduction, body points and conclusion. Save the outline in My notes.",
        "precis" to "Paste a passage and write the precis or the answer against the clock.",
        "checker" to "Paste any text to see long sentences, repeated words and vague words.",
        "facts" to "Your own cards for dates, formulas and definitions. Tap a card to show the answer.",
    )
}
