package com.pmspreparation.app

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** One meaning of a word, taken from one app. */
class VDef(val app: String, val meaning: String, val urdu: String)

class VWord(
    val word: String,
    val pos: String,
    val defs: List<VDef>,
    val examples: List<String>,
    val src: List<Pair<String, String>>,
    val syn: List<String>,
    val ant: List<String>,
    val forms: List<Pair<String, List<String>>>,
    val idioms: List<Pair<String, String>>,
) {
    val id: Long = word.lowercase().hashCode().toLong()
    val general: Boolean get() = syn.isNotEmpty()
    val urdu: String get() = defs.firstOrNull { it.urdu.isNotBlank() }?.urdu ?: ""
    val meaning: String get() = defs.firstOrNull { it.meaning.isNotBlank() }?.meaning ?: ""
    val apps: List<String> get() = src.map { it.first }.distinct()
    val lower: String = word.lowercase()
}

/** Apps whose words and terms are collected in the Vocabulary tab: key to (name, hub app id). */
val VOCAB_APPS = linkedMapOf(
    "essay" to ("PMS/CSS Essay" to "essay"),
    "grammar" to ("English Grammar" to "grammar"),
    "economy" to ("Economy" to "economy"),
    "islamic" to ("Islamic Studies" to "islamic"),
    "intl" to ("International Affairs" to "intlaffairs"),
    "pak1" to ("Pak-Studies 1" to "pakstudies"),
    "pak2" to ("Pak-Studies II" to "pakstudies2"),
)

private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

internal fun loadVocab(ctx: Context): List<VWord> {
    val text = ctx.assets.open("hubvocab/vocab.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
    val arr = JSONArray(text)
    val formNames = listOf("n" to "Noun", "v" to "Verb", "adj" to "Adjective", "adv" to "Adverb")
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val defs = o.optJSONArray("d")?.let { d -> (0 until d.length()).map { VDef(d.getJSONArray(it).getString(0), d.getJSONArray(it).getString(1), d.getJSONArray(it).getString(2)) } } ?: emptyList()
        val src = o.optJSONArray("src")?.let { d -> (0 until d.length()).map { d.getJSONArray(it).getString(0) to d.getJSONArray(it).getString(1) } } ?: emptyList()
        val f = o.optJSONObject("f")
        val forms = formNames.mapNotNull { (k, label) -> f?.optJSONArray(k)?.let { label to strs(it) }?.takeIf { it.second.isNotEmpty() } }
        val idioms = o.optJSONArray("i")?.let { d -> (0 until d.length()).map { d.getJSONObject(it).optString("p") to d.getJSONObject(it).optString("m") } } ?: emptyList()
        VWord(o.getString("w"), o.optString("p"), defs, strs(o.optJSONArray("e")), src, strs(o.optJSONArray("s")), strs(o.optJSONArray("a")), forms, idioms)
    }
}

private fun posName(p: String) = when (p) {
    "n" -> "noun"; "v" -> "verb"; "adj" -> "adjective"; "adv" -> "adverb"; else -> p
}

/** Third tab of the hub: every word and term of every merged app in one searchable list. */
@Composable
fun VocabTab(prefs: HubPrefs, onOpenApp: (String) -> Unit) {
    val ctx = LocalContext.current
    val all by produceState<List<VWord>?>(null) {
        value = withContext(Dispatchers.Default) { runCatching { loadVocab(ctx) }.getOrDefault(emptyList()) }
    }
    var query by rememberSaveable { mutableStateOf("") }
    var mode by rememberSaveable { mutableStateOf("all") }   // all | words | terms | saved | learned
    var app by rememberSaveable { mutableStateOf("") }
    var quiz by rememberSaveable { mutableStateOf(false) }
    var openWord by rememberSaveable { mutableStateOf("") }
    val saved = prefs.recs("vw").map { it.id }.toSet()
    val learned = prefs.recs("vl").map { it.id }.toSet()

    val list = all
    if (list == null) {
        Column(Modifier.fillMaxSize().padding(24.dp)) { Text("Loading vocabulary...") }
        return
    }
    if (quiz) {
        VocabQuiz(prefs, list, onClose = { quiz = false })
        return
    }
    val q = query.trim().lowercase()
    val shown = remember(list, q, mode, app, saved, learned) {
        list.filter { w ->
            (app.isEmpty() || app in w.apps) &&
                when (mode) {
                    "words" -> w.general
                    "terms" -> !w.general
                    "saved" -> w.id in saved
                    "learned" -> w.id in learned
                    else -> true
                } &&
                (q.isEmpty() || w.lower.contains(q) || w.urdu.contains(q) || w.syn.any { it.contains(q) } || w.meaning.lowercase().contains(q))
        }
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(HubText.t(prefs, "Vocabulary"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${list.size} words and terms from all apps  •  ${learned.size} learned",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Button(onClick = { quiz = true }) { Text("Quiz") }
            }
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                label = { Text("Search word, Urdu or synonym") }, modifier = Modifier.fillMaxWidth(),
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                items(listOf("all" to "All", "words" to "Words", "terms" to "Terms", "saved" to "Saved", "learned" to "Learned")) { (k, label) ->
                    FilterChip(selected = mode == k, onClick = { mode = k }, label = { Text(label) })
                }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(VOCAB_APPS.entries.toList()) { e ->
                    FilterChip(selected = app == e.key, onClick = { app = if (app == e.key) "" else e.key }, label = { Text(e.value.first) })
                }
            }
            Text("${shown.size} shown", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(shown.take(400), key = { it.lower }) { w ->
                VocabCard(
                    prefs, w, expanded = openWord == w.lower,
                    isSaved = w.id in saved, isLearned = w.id in learned,
                    onToggle = { openWord = if (openWord == w.lower) "" else w.lower },
                    onOpenApp = onOpenApp,
                )
            }
            if (shown.size > 400) {
                item { Text("Showing the first 400. Type in the search box to narrow down.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            if (shown.isEmpty()) item { Text("Nothing found.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun VocabCard(
    prefs: HubPrefs, w: VWord, expanded: Boolean, isSaved: Boolean, isLearned: Boolean,
    onToggle: () -> Unit, onOpenApp: (String) -> Unit,
) {
    SoftCard(Modifier.fillMaxWidth(), onClick = onToggle) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(w.word, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        if (w.pos.isNotBlank()) {
                            Text("  ${posName(w.pos)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (w.urdu.isNotBlank()) Text(w.urdu, fontFamily = UrduFont, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
                    if (w.meaning.isNotBlank() && !expanded) {
                        Text(w.meaning, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
                TextButton(onClick = { toggleWord(prefs, "vw", w, isSaved) }) { Text(if (isSaved) "★" else "☆", fontSize = 20.sp) }
            }
            if (expanded) {
                Spacer(Modifier.height(6.dp))
                w.defs.forEach { d ->
                    val name = VOCAB_APPS[d.app]?.first ?: d.app
                    Text(
                        buildString {
                            append(name).append(": ")
                            if (d.meaning.isNotBlank()) append(d.meaning)
                            if (d.meaning.isNotBlank() && d.urdu.isNotBlank()) append("  •  ")
                            if (d.urdu.isNotBlank()) append(d.urdu)
                        },
                        fontSize = 13.sp,
                    )
                }
                if (w.examples.isNotEmpty()) {
                    VSection("Example sentences")
                    w.examples.forEach { Text("• $it", fontSize = 13.sp) }
                }
                if (w.syn.isNotEmpty()) { VSection("Synonyms"); Text(w.syn.joinToString(", "), fontSize = 13.sp) }
                if (w.ant.isNotEmpty()) { VSection("Antonyms"); Text(w.ant.joinToString(", "), fontSize = 13.sp) }
                if (w.forms.isNotEmpty()) {
                    VSection("Word forms")
                    w.forms.forEach { (label, l) -> Text("$label: ${l.joinToString(", ")}", fontSize = 13.sp) }
                }
                if (w.idioms.isNotEmpty()) {
                    VSection("Idioms and phrases")
                    w.idioms.forEach { (p, m) -> Text("• $p" + if (m.isNotBlank()) " — $m" else "", fontSize = 13.sp) }
                }
                if (w.src.isNotEmpty()) {
                    VSection("Found in")
                    w.src.take(8).forEach { (a, where) ->
                        Text("• ${VOCAB_APPS[a]?.first ?: a}: $where", fontSize = 13.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                        w.apps.take(3).forEach { a ->
                            VOCAB_APPS[a]?.let { (name, id) -> OutlinedButton(onClick = { onOpenApp(id) }) { Text("Open $name", fontSize = 11.sp, maxLines = 1) } }
                        }
                    }
                }
                Row {
                    TextButton(onClick = { toggleWord(prefs, "vl", w, isLearned) }) {
                        Text(if (isLearned) "✔ Learned" else "Mark as learned")
                    }
                }
            }
        }
    }
}

@Composable
private fun VSection(title: String) {
    Spacer(Modifier.height(6.dp))
    Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
}

private fun toggleWord(prefs: HubPrefs, list: String, w: VWord, on: Boolean) {
    if (on) prefs.removeRec(list, w.id) else prefs.putRec(list, HubRec(w.id, w.word, "", "", "", 0, System.currentTimeMillis()))
}

/** Ten-question quiz: pick the right Urdu meaning for a word. Only words not yet marked learned are asked. */
@Composable
private fun VocabQuiz(prefs: HubPrefs, list: List<VWord>, onClose: () -> Unit) {
    val learned = prefs.recs("vl").map { it.id }.toSet()
    val pool = remember(list) { list.filter { it.urdu.isNotBlank() && it.id !in learned }.ifEmpty { list.filter { it.urdu.isNotBlank() } } }
    val allUrdu = remember(list) { list.map { it.urdu }.filter { it.isNotBlank() && it.length < 40 } }
    val questions = remember(pool) {
        pool.shuffled().take(10).map { w ->
            val wrong = allUrdu.filter { it != w.urdu }.shuffled().take(3)
            Triple(w, (wrong + w.urdu).shuffled(), w.urdu)
        }
    }
    var i by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf("") }
    var score by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (questions.isEmpty()) {
            Text("No words available for the quiz.")
            Button(onClick = onClose) { Text("Back") }
            return@Column
        }
        if (i >= questions.size) {
            Text("Score: $score / ${questions.size}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Button(onClick = onClose) { Text("Back to Vocabulary") }
            return@Column
        }
        val (w, options, answer) = questions[i]
        Text("Question ${i + 1} of ${questions.size}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(w.word, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        if (w.meaning.isNotBlank()) Text(w.meaning, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        options.forEach { o ->
            val mark = when {
                picked.isEmpty() -> ""
                o == answer -> "  ✔"
                o == picked -> "  ✘"
                else -> ""
            }
            OutlinedButton(
                onClick = { if (picked.isEmpty()) { picked = o; if (o == answer) score++ } },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(o + mark, fontFamily = UrduFont, fontSize = 17.sp) }
        }
        if (picked.isNotEmpty()) {
            Button(onClick = { picked = ""; i++ }) { Text(if (i == questions.size - 1) "Finish" else "Next") }
        }
        TextButton(onClick = onClose) { Text("Close") }
    }
}
