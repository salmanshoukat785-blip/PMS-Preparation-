@file:OptIn(ExperimentalMaterial3Api::class)

package com.pmspreparation.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val SEP = "\u001F"

// ------------------------------------------------------------------ Shared question runner
/** Runs a list of MCQs one by one. limitSec = 0 means no time limit. */
@Composable
fun McqRunner(
    prefs: HubPrefs?,
    questions: List<HubContent.Mcq>,
    limitSec: Int,
    onResult: (HubContent.Mcq, Boolean) -> Unit,
    onFinished: (Int, Int) -> Unit,
    onClose: () -> Unit,
) {
    var index by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    var left by remember { mutableIntStateOf(limitSec) }
    var finished by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (limitSec > 0) {
            while (left > 0 && !finished) { delay(1000); left -= 1 }
            if (!finished) finished = true
        }
    }
    LaunchedEffect(finished) { if (finished) onFinished(score, questions.size) }

    if (finished || questions.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text(if (left <= 0 && limitSec > 0) "Time is up" else "Finished", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(8.dp))
            val total = questions.size
            Text("Score: $score / $total  (${if (total > 0) score * 100 / total else 0}%)", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
            Text("Wrong answers are saved in your Mistake notebook.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Close") }
        }
        return
    }

    val q = questions[index]
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (limitSec > 0) {
            Text(
                "Time left: %d:%02d".format(left / 60, left % 60), fontWeight = FontWeight.Bold,
                color = if (left < 60) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            )
        }
        LinearProgressIndicator(progress = { (index + 1f) / questions.size }, modifier = Modifier.fillMaxWidth())
        Text("Question ${index + 1} of ${questions.size}  ·  ${q.source}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(q.q, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
        q.options.forEachIndexed { i, opt ->
            val answered = picked >= 0
            val color = when {
                !answered -> MaterialTheme.colorScheme.onSurface
                i == q.answer -> Color(0xFF2E7D32)
                i == picked -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            OutlinedButton(
                onClick = {
                    if (!answered) {
                        picked = i
                        val ok = i == q.answer
                        if (ok) score++
                        onResult(q, ok)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(if (answered && (i == q.answer || i == picked)) 2.dp else 1.dp, color),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
            ) { Text(opt, modifier = Modifier.padding(vertical = 4.dp)) }
        }
        if (prefs != null) {
            androidx.compose.material3.TextButton(onClick = { prefs.toggleQuestion(q) }) {
                Text(if (prefs.isQuestionSaved(q)) "\u2605 Question saved" else "\u2606 Save this question")
            }
        }
        if (picked >= 0) {
            if (q.explanation.isNotBlank()) Text(q.explanation, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                onClick = { if (index + 1 >= questions.size) finished = true else { index++; picked = -1 } },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (index + 1 >= questions.size) "Finish" else "Next") }
        }
    }
}

private fun allQuestions(ctx: android.content.Context, sources: Collection<String>): List<HubContent.Mcq> =
    sources.flatMap { HubContent.mcqs(ctx, it) }

// ------------------------------------------------------------------ Daily 10-question challenge
@Composable
fun DailyScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val today = prefs.today()
    val doneToday = prefs.recs("daily").firstOrNull { it.id == today }
    var playing by remember { mutableStateOf(false) }
    val qs by produceState<List<HubContent.Mcq>?>(null) {
        value = withContext(Dispatchers.IO) {
            allQuestions(ctx, HubContent.MCQ_SOURCES.map { it.first }).shuffled(java.util.Random(today)).take(10)
        }
    }
    ToolScaffold("Daily challenge", onBack) {
        val list = qs
        when {
            list == null -> Text("Preparing today's questions...", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onBackground)
            list.isEmpty() -> Text("No questions found.", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.error)
            playing -> McqRunner(
                prefs, list, 0,
                onResult = { q, ok -> if (!ok) prefs.addMistake(q) },
                onFinished = { s, t ->
                    prefs.putRec("daily", HubRec(today, n = s, m = t.toLong()))
                    prefs.recordMock()
                },
                onClose = { playing = false },
            )
            else -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(xDayText(today), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Text(
                    "10 questions picked from all your apps. Everyone gets the same set on the same day.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (doneToday != null) {
                    Text("Today's result: ${doneToday.n} / ${doneToday.m}", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                }
                Button(onClick = { playing = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (doneToday != null) "Play again" else "Start today's challenge")
                }
                val days = prefs.recs("daily").size
                Text("Challenges completed so far: $days", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ------------------------------------------------------------------ Timed full paper
@Composable
fun TimedPaperScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    var chosen by remember { mutableStateOf(HubContent.MCQ_SOURCES.map { it.first }.toSet()) }
    var count by remember { mutableIntStateOf(50) }
    var request by remember { mutableIntStateOf(0) }
    var questions by remember { mutableStateOf<List<HubContent.Mcq>?>(null) }
    var loading by remember { mutableStateOf(false) }

    LaunchedEffect(request) {
        if (request > 0) {
            loading = true
            val src = chosen
            questions = withContext(Dispatchers.IO) { allQuestions(ctx, src).shuffled().take(count) }
            loading = false
        }
    }
    ToolScaffold("Timed paper", onBack) {
        val qs = questions
        when {
            loading -> Text("Preparing paper...", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onBackground)
            qs != null && qs.isNotEmpty() -> McqRunner(
                prefs, qs, (qs.size * 54),
                onResult = { q, ok -> if (!ok) prefs.addMistake(q) },
                onFinished = { _, _ -> prefs.recordMock() },
                onClose = { questions = null },
            )
            else -> Column(
                Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (qs != null) Text("No questions found for this choice.", color = MaterialTheme.colorScheme.error)
                Text("Choose subjects", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HubContent.MCQ_SOURCES.forEach { (id, label) ->
                        FilterChip(
                            selected = id in chosen,
                            onClick = { chosen = if (id in chosen) chosen - id else chosen + id },
                            label = { Text(label, fontSize = 12.sp) },
                        )
                    }
                }
                Text("Number of questions", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(25, 50, 75, 100).forEach { n ->
                        FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") })
                    }
                }
                Text(
                    "Exam conditions: ${count * 54 / 60} minutes in total (about 54 seconds a question). The paper ends by itself when the time is up. If fewer questions are available, the time is reduced to match.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = { request++ }, enabled = chosen.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Start paper") }
            }
        }
    }
}

// ------------------------------------------------------------------ Mistake notebook
private fun mistakeToMcq(r: HubRec): HubContent.Mcq {
    val parts = r.d.split(SEP)
    return HubContent.Mcq(parts[0], r.a, r.b.split(SEP), r.n, r.c, parts.getOrElse(1) { "" })
}

@Composable
fun MistakesScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val list = prefs.recs("mist")
    var practicing by remember { mutableStateOf<List<HubContent.Mcq>?>(null) }
    ToolScaffold("Mistake notebook", onBack) {
        val run = practicing
        if (run != null) {
            McqRunner(
                prefs, run, 0,
                onResult = { q, ok -> if (ok) prefs.removeRec("mist", q.q.hashCode().toLong()) },
                onFinished = { _, _ -> },
                onClose = { practicing = null },
            )
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    "Every question you get wrong in a test lands here. Answer it correctly in practice and it leaves the notebook.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(
                    onClick = { practicing = list.map { mistakeToMcq(it) }.shuffled() },
                    enabled = list.isNotEmpty(), modifier = Modifier.fillMaxWidth(),
                ) { Text("Practice ${list.size} mistakes") }
                list.forEach { r ->
                    SoftCard(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text(r.a, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                val opts = r.b.split(SEP)
                                Text("Answer: ${opts.getOrNull(r.n) ?: ""}", fontSize = 13.sp, color = Color(0xFF2E7D32))
                                Text(r.d.split(SEP).filter { it.isNotBlank() }.joinToString(" · "), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { prefs.removeRec("mist", r.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Revision scheduler
private val REV_OFFSETS = intArrayOf(1, 3, 7, 30)

@Composable
fun RevisionScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val today = prefs.today()
    val all = prefs.recs("rev")
    val active = all.filter { it.n < REV_OFFSETS.size }
    val due = active.filter { it.m + REV_OFFSETS[it.n] <= today }
    val upcoming = active.filter { it.m + REV_OFFSETS[it.n] > today }.sortedBy { it.m + REV_OFFSETS[it.n] }
    ToolScaffold("Revision", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                "When you tick a syllabus topic, it comes back for revision after 1, 3, 7 and 30 days.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text("Due now (${due.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            if (due.isEmpty()) Text("Nothing to revise right now.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            due.forEach { r ->
                SoftCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.a, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text("Revision ${r.n + 1} of ${REV_OFFSETS.size}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        OutlinedButton(onClick = { prefs.putRec("rev", HubRec(r.id, r.a, r.b, r.c, r.d, r.n + 1, r.m)) }) { Text("Revised") }
                    }
                }
            }
            if (upcoming.isNotEmpty()) {
                Text("Coming up (${upcoming.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                upcoming.take(30).forEach { r ->
                    SoftCard(Modifier.fillMaxWidth()) {
                        Column {
                            Text(r.a, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(xDayText(r.m + REV_OFFSETS[r.n]), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            val finished = all.size - active.size
            if (finished > 0) Text("Fully revised topics: $finished", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ------------------------------------------------------------------ Flashcards (spaced repetition)
private val FLASH_DAYS = intArrayOf(1, 2, 4, 8, 16, 32)

private fun wordId(w: HubContent.Word): Long = w.word.lowercase().hashCode().toLong()

@Composable
fun FlashcardsScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val words by produceState<List<HubContent.Word>?>(null) { value = withContext(Dispatchers.IO) { HubContent.words(ctx) } }
    var queue by remember { mutableStateOf<List<HubContent.Word>?>(null) }
    var shown by remember { mutableStateOf(false) }
    var reviewed by remember { mutableIntStateOf(0) }
    val today = prefs.today()

    LaunchedEffect(words) {
        val w = words
        if (w != null && queue == null) {
            val saved = prefs.recs("flash").associateBy { it.id }
            queue = w.filter { val r = saved[wordId(it)]; r == null || r.m <= today }.shuffled().take(20)
        }
    }
    ToolScaffold("Flashcards", onBack) {
        val q = queue
        when {
            q == null -> Text("Loading words...", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onBackground)
            q.isEmpty() -> Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (reviewed > 0) "Session finished. Reviewed $reviewed cards." else "No cards are due today.", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Text("Words you know come back after longer gaps (1, 2, 4, 8, 16 and 32 days).", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Mastered so far: ${prefs.recs("flash").count { it.n >= 4 }}", color = MaterialTheme.colorScheme.primary)
            }
            else -> {
                val w = q[0]
                Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("${q.size} cards left", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    SoftCard(Modifier.fillMaxWidth(), onClick = { shown = true }) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(w.word, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            if (shown) {
                                Text(w.meaning, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface)
                                if (w.urdu.isNotBlank()) Text(w.urdu, fontSize = 22.sp, lineHeight = 40.sp, fontFamily = UrduFont, color = MaterialTheme.colorScheme.onSurface)
                                if (w.example.isNotBlank()) Text("“${w.example}”", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                Text("Tap to see the meaning", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (shown) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = {
                                prefs.putRec("flash", HubRec(wordId(w), w.word, n = 0, m = today))
                                queue = q.drop(1) + w
                                shown = false
                            }, modifier = Modifier.weight(1f)) { Text("Again") }
                            Button(onClick = {
                                val box = ((prefs.recs("flash").firstOrNull { it.id == wordId(w) }?.n ?: 0) + 1).coerceAtMost(FLASH_DAYS.size)
                                prefs.putRec("flash", HubRec(wordId(w), w.word, n = box, m = today + FLASH_DAYS[box - 1]))
                                queue = q.drop(1)
                                reviewed++
                                shown = false
                            }, modifier = Modifier.weight(1f)) { Text("I know it") }
                        }
                    }
                }
            }
        }
    }
}
