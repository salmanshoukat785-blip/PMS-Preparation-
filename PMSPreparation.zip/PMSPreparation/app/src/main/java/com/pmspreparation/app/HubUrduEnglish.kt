@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.pmspreparation.app

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

private class TrItem(val level: String, val ur: String, val en: String, val keys: List<String>, val tense: String, val hint: String)

private fun loadTrItems(ctx: android.content.Context): List<TrItem> = try {
    val arr = JSONArray(ctx.assets.open("hubtranslate/items.json").bufferedReader(Charsets.UTF_8).use { it.readText() })
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val k = o.getJSONArray("k")
        TrItem(o.getString("l"), o.getString("ur"), o.getString("en"), (0 until k.length()).map { k.getString(it) }, o.optString("t"), o.optString("h"))
    }
} catch (e: Exception) { emptyList() }

private val TENSE_PATTERNS = mapOf(
    "present continuous" to Regex("\\b(am|is|are)\\s+(\\w+ly\\s+)?\\w+ing\\b", RegexOption.IGNORE_CASE),
    "past continuous" to Regex("\\b(was|were)\\s+(\\w+ly\\s+)?\\w+ing\\b", RegexOption.IGNORE_CASE),
    "present perfect" to Regex("\\b(has|have)\\s+(\\w+\\s+)?\\w+", RegexOption.IGNORE_CASE),
    "future" to Regex("\\b(will|shall)\\b", RegexOption.IGNORE_CASE),
    "passive" to Regex("\\b(is|are|was|were|been|be)\\s+(\\w+ly\\s+)?\\w+(ed|en|n|t)\\b", RegexOption.IGNORE_CASE),
    "conditional" to Regex("\\b(would|if)\\b", RegexOption.IGNORE_CASE),
)

private fun wordsOf(s: String) = s.lowercase().split(Regex("[^a-z']+")).filter { it.isNotEmpty() }

/** Basic offline feedback on a translation. Returns a list of remarks (good and bad) in plain words. */
private fun feedback(item: TrItem?, answer: String): Pair<List<String>, List<String>> {
    val problems = mutableListOf<String>()
    val good = mutableListOf<String>()
    val text = answer.trim()
    if (text.isEmpty()) return problems to good
    if (item != null) {
        val low = text.lowercase()
        val missing = item.keys.filter { k -> !low.contains(if (k.length <= 4) k else k.take(5)) }
        if (missing.isNotEmpty()) problems.add("Key words not found: " + missing.joinToString(", ") + ". Check whether you used another word with the same meaning or left the idea out.")
        else good.add("All key words of the model translation are present.")
        val a = wordsOf(text).toSet()
        val m = wordsOf(item.en).toSet()
        val overlap = if (m.isEmpty()) 0 else a.intersect(m).size * 100 / m.size
        good.add("Word overlap with the model: $overlap%. A different but correct wording is fine.")
        val pat = TENSE_PATTERNS[item.tense]
        if (pat != null) {
            if (!pat.containsMatchIn(text)) problems.add("Expected a ${item.tense} structure, but it was not found. Re-read the tense clue in the Urdu verb ending.")
            else good.add("The ${item.tense} structure is there.")
        }
        val lenA = wordsOf(text).size
        val lenM = wordsOf(item.en).size
        if (lenM > 0 && lenA < lenM * 0.6) problems.add("Your translation is much shorter ($lenA words, model about $lenM). Part of the Urdu may be left out.")
        if (lenM > 0 && lenA > lenM * 1.6) problems.add("Your translation is much longer ($lenA words, model about $lenM). Try to be more direct.")
    }
    if (text.first().isLowerCase()) problems.add("A sentence should begin with a capital letter.")
    if (!text.last().let { it == '.' || it == '?' || it == '!' || it == '"' }) problems.add("The translation does not end with a full stop or question mark.")
    if (Regex("\\s{2,}").containsMatchIn(text)) problems.add("There are double spaces.")
    if (Regex("\\bi\\b").containsMatchIn(text)) problems.add("Write the pronoun I with a capital letter.")
    if (Regex("\\b(\\w+)\\s+\\1\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)) problems.add("A word is repeated twice in a row.")
    if (Regex("[\\u0600-\\u06FF]").containsMatchIn(text)) problems.add("The answer contains Urdu letters. Write the translation in English only.")
    if (problems.isEmpty()) good.add("No common mistakes found.")
    return problems to good
}

private val METHOD = listOf(
    "Steps to translate Urdu into English" to listOf(
        "1. Read the whole Urdu passage once and find its main idea.",
        "2. Split it into sentences. For each, find the doer (subject), the action (verb) and the object. Urdu puts the verb at the end; English puts it after the subject: Subject + Verb + Object.",
        "3. Find the tense from the verb ending (see the table below), then choose the English verb form.",
        "4. Translate idioms and proverbs by meaning, never word by word.",
        "5. Add the articles (a, an, the) and the right prepositions; Urdu has no articles and uses postpositions after the noun.",
        "6. Read your English once more: capital letters, full stops, singular and plural, and subject and verb agreement.",
        "7. In a paragraph keep the order of ideas and join sentences with linking words (however, therefore, moreover).",
    ),
    "Urdu word to English pattern" to listOf(
        "ہے / ہیں  →  is / are (present)",
        "تھا / تھی / تھے  →  was / were",
        "گا / گی / گے  →  will",
        "رہا ہے / رہی ہے / رہے ہیں  →  is / are + verb-ing",
        "رہا تھا / رہی تھی  →  was / were + verb-ing",
        "چکا ہے / لیا ہے / دیا ہے  →  has / have + past participle",
        "نے (with a past action)  →  past simple; the doer is the subject: اس نے کھایا = He ate",
        "کو  →  to, for (or the object itself)",
        "کا / کی / کے  →  of, or 's",
        "سے  →  from, by, with, than (check the sense)",
        "میں  →  in, into, among",
        "پر  →  on, at, upon",
        "کے لیے  →  for, in order to",
        "چاہیے  →  should, ought to, need to",
        "سکتا ہے  →  can, may",
        "جائے / جائیں (passive)  →  be + past participle: دی جائیں = are given",
        "اگر ... تو  →  if ... (then)",
    ),
    "Idioms: translate the meaning" to listOf(
        "آسمان سے باتیں کرنا  →  to reach great heights",
        "دانتوں تلے انگلی دبانا  →  to be astonished",
        "نو دو گیارہ ہونا  →  to run away quickly",
        "اونٹ کے منہ میں زیرہ  →  a drop in the ocean",
        "ایک پنتھ دو کاج  →  to kill two birds with one stone",
        "آنکھوں کا تارا  →  the apple of one's eye",
        "ہاتھ پاؤں پھول جانا  →  to panic",
        "چادر دیکھ کر پاؤں پھیلانا  →  to cut one's coat according to one's cloth",
        "ہاتھ ملتے رہ جانا  →  to be left regretting",
    ),
    "Common mistakes" to listOf(
        "Word-for-word copying: 'He is going to the school' (no article needed with school as an activity) instead of 'He goes to school'.",
        "Wrong tense: Urdu 'کر لیا ہے' is present perfect (has done), not past simple.",
        "Missing articles: say 'the key to success', 'a great poet'.",
        "Wrong preposition: 'depends on', 'interested in', 'afraid of', 'different from'.",
        "Singular and plural: 'Information' and 'advice' have no plural; 'people' is plural.",
        "Pronoun mistakes: the Urdu word 'وہ' can mean he, she, it or they; choose from the context.",
    ),
)

@Composable
fun UrduEnglishScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val items by produceState<List<TrItem>>(emptyList()) { value = withContext(Dispatchers.IO) { loadTrItems(ctx) } }
    var tab by remember { mutableStateOf("practice") }
    var level by remember { mutableStateOf("easy") }
    var index by remember { mutableIntStateOf(0) }
    var answer by remember { mutableStateOf("") }
    var checked by remember { mutableStateOf(false) }
    var ownUr by remember { mutableStateOf("") }
    var machine by remember { mutableStateOf("") }
    var machineBusy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val list = items.filter { it.level == level }
    val item = if (level == "own") null else list.getOrNull(index % list.size.coerceAtLeast(1))
    val ur = if (level == "own") ownUr else item?.ur ?: ""
    LaunchedEffect(level, index) { answer = ""; checked = false; machine = "" }

    ToolScaffold("Urdu to English", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = tab == "practice", onClick = { tab = "practice" }, label = { Text("Practice") })
                FilterChip(selected = tab == "method", onClick = { tab = "method" }, label = { Text("Method") })
            }
            if (tab == "method") {
                METHOD.forEach { (title, lines) ->
                    Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    lines.forEach { Text(it, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground) }
                    Spacer(Modifier.height(6.dp))
                }
            } else {
                androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("easy" to "Sentences", "medium" to "Exam style", "paragraph" to "Paragraphs", "own" to "My own Urdu").forEach { (k, label) ->
                        FilterChip(selected = level == k, onClick = { level = k; index = 0 }, label = { Text(label) })
                    }
                }
                if (level == "own") {
                    OutlinedTextField(ownUr, { ownUr = it; checked = false; machine = "" }, label = { Text("Paste or type Urdu text") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                } else if (item != null) {
                    Text("${index % list.size + 1} of ${list.size}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        item.ur, fontFamily = UrduFont, fontSize = 22.sp, lineHeight = 38.sp, textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.onBackground,
                    )
                } else Text("Loading...", color = MaterialTheme.colorScheme.onSurfaceVariant)

                OutlinedTextField(answer, { answer = it; checked = false }, label = { Text("Your English translation") }, modifier = Modifier.fillMaxWidth(), minLines = if (level == "paragraph") 6 else 3)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { checked = true }, enabled = answer.isNotBlank()) { Text("Check") }
                    if (level != "own") {
                        OutlinedButton(onClick = { index++ }) { Text("Next") }
                        OutlinedButton(onClick = { if (list.isNotEmpty()) index = list.indices.random() }) { Text("Random") }
                    }
                }
                if (checked) {
                    val (problems, good) = feedback(item, answer)
                    Text("Mistakes to fix", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                    if (problems.isEmpty()) Text("None found.", color = MaterialTheme.colorScheme.onBackground)
                    problems.forEach { Text("✘ $it", fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground) }
                    Text("Good points", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    good.forEach { Text("✔ $it", fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground) }
                    if (item != null) {
                        Text("Model translation", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        Text(item.en, fontSize = 15.sp, color = MaterialTheme.colorScheme.onBackground)
                        if (item.tense.isNotBlank()) Text("Tense: ${item.tense}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (item.hint.isNotBlank()) Text("Tip: ${item.hint}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("Basic checker: it cannot judge grammar fully. Compare with the model and with the machine translation.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (ur.isNotBlank()) {
                    OutlinedButton(onClick = {
                        machineBusy = true
                        scope.launch {
                            machine = try {
                                com.pmsprep.app.UrduMl.toEnglish(ur)
                            } catch (e: kotlinx.coroutines.CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                "Machine translation failed. Check your internet (the model downloads once) and try again."
                            }
                            machineBusy = false
                        }
                    }, enabled = !machineBusy) { Text(if (machineBusy) "Please wait..." else "Show machine translation") }
                    if (machine.isNotBlank()) {
                        Text("Machine translation (ML Kit, may be imperfect)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        Text(machine, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
                    }
                }
                if (checked && answer.isNotBlank()) {
                    OutlinedButton(onClick = {
                        prefs.saveNote(null, "Translation practice", "Urdu: $ur\n\nMy translation: $answer" + (item?.let { "\n\nModel: ${it.en}" } ?: ""))
                        Toast.makeText(ctx, "Saved in My notes", Toast.LENGTH_SHORT).show()
                    }) { Text("Save to notes") }
                }
            }
        }
    }
}
