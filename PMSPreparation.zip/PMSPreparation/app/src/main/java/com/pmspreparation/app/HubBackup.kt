package com.pmspreparation.app

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup = one zip with the app's private settings (shared_prefs) and data files (files, incl. datastore),
 * so the progress of ALL merged apps and the home page is saved together.
 */
object HubBackup {
    private val FOLDERS = listOf("shared_prefs", "files")

    fun export(ctx: Context, out: OutputStream) {
        val root = ctx.dataDir
        ZipOutputStream(BufferedOutputStream(out)).use { zip ->
            FOLDERS.forEach { addPath(zip, File(root, it), it) }
        }
    }

    private fun addPath(zip: ZipOutputStream, f: File, name: String) {
        if (f.isDirectory) {
            f.listFiles()?.forEach { addPath(zip, it, name + "/" + it.name) }
        } else if (f.isFile) {
            zip.putNextEntry(ZipEntry(name))
            f.inputStream().use { it.copyTo(zip) }
            zip.closeEntry()
        }
    }

    /** Returns how many files were restored (0 = not a valid backup). */
    fun restore(ctx: Context, input: InputStream): Int {
        val root = ctx.dataDir.canonicalFile
        var count = 0
        ZipInputStream(BufferedInputStream(input)).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                val name = e.name
                if (!e.isDirectory && FOLDERS.any { name.startsWith("$it/") }) {
                    val target = File(root, name).canonicalFile
                    // Refuse paths that would leave the app's own folder.
                    if (target.path.startsWith(root.path + File.separator)) {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { zip.copyTo(it) }
                        count++
                    }
                }
                zip.closeEntry()
                e = zip.nextEntry
            }
        }
        return count
    }
}
