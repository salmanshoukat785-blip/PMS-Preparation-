package com.pmspreparation.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Mixed MCQ test: random questions from the chosen apps (Pak-Studies, Social Work, English Grammar). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    var chosen by remember { mutableStateOf(HubContent.MCQ_SOURCES.map { it.first }.toSet()) }
    var count by remember { mutableIntStateOf(20) }
    var questions by remember { mutableStateOf<List<HubContent.Mcq>?>(null) }
    var loading by remember { mutableStateOf(false) }
    var index by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    var startRequest by remember { mutableIntStateOf(0) }

    // Build a new test whenever Start is pressed.
    LaunchedEffect(startRequest) {
        if (startRequest > 0) {
            loading = true
            val picked0 = chosen
            val list = withContext(Dispatchers.IO) {
                picked0.flatMap { HubContent.mcqs(ctx, it) }.shuffled().take(count)
            }
            questions = list; index = 0; picked = -1; score = 0; finished = false; loading = false
        }
    }

    ToolScaffold("Mixed MCQ test", onBack) {
        val asked = questions
        val qs = asked ?: emptyList()
        when {
            loading -> Text("Preparing questions...", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onBackground)

            qs.isEmpty() -> Column(
                Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (asked != null) Text("No questions found for this choice.", color = MaterialTheme.colorScheme.error)
                Text("Choose subjects", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HubContent.MCQ_SOURCES.forEach { (id, label) ->
                        FilterChip(
                            selected = id in chosen,
                            onClick = { chosen = if (id in chosen) chosen - id else chosen + id },
                            label = { Text(label, fontSize = 12.sp) },
                        )
                    }
                }
                Text("Number of questions", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(10, 20, 30, 50).forEach { n ->
                        FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") })
                    }
                }
                Text(
                    "Questions are picked at random from the apps you choose. Your score is not saved per question; only the number of tests finished counts toward badges.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = { startRequest++ }, enabled = chosen.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Start test") }
            }

            finished -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                val total = qs.size
                Text("Test finished", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.height(8.dp))
                Text("Score: $score / $total  (${if (total > 0) score * 100 / total else 0}%)", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(20.dp))
                Button(onClick = { questions = null; finished = false }, modifier = Modifier.fillMaxWidth()) { Text("New test") }
            }

            else -> {
                val q = qs[index]
                Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    LinearProgressIndicator(progress = { (index + 1f) / qs.size }, modifier = Modifier.fillMaxWidth())
                    Text("Question ${index + 1} of ${qs.size}  ·  ${q.source}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(q.q, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                    q.options.forEachIndexed { i, opt ->
                        val answered = picked >= 0
                        val color = when {
                            !answered -> MaterialTheme.colorScheme.onSurface
                            i == q.answer -> Color(0xFF2E7D32)
                            i == picked -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        OutlinedButton(
                            onClick = { if (!answered) { picked = i; if (i == q.answer) score++ } },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(if (answered && (i == q.answer || i == picked)) 2.dp else 1.dp, color),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
                        ) { Text(opt, modifier = Modifier.padding(vertical = 4.dp)) }
                    }
                    if (picked >= 0) {
                        if (q.explanation.isNotBlank()) Text(q.explanation, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(
                            onClick = {
                                if (index + 1 >= qs.size) { finished = true; prefs.recordMock() } else { index++; picked = -1 }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (index + 1 >= qs.size) "Finish" else "Next") }
                    }
                }
            }
        }
    }
}
