package com.pmspreparation.app

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class SylSection(val heading: String, val items: List<String>)
class SylPaper(val no: Int, val title: String, val meta: String, val sections: List<SylSection>) {
    val topicCount: Int get() = sections.sumOf { it.items.size }
}
class SylGroup(val name: String, val note: String, val papers: List<SylPaper>)

/** Loads every file in assets/syllabus (each file holds one or more groups of papers). */
object HubSyllabus {
    @Volatile private var cache: List<SylGroup>? = null

    fun load(ctx: Context): List<SylGroup> = cache ?: synchronized(this) { cache ?: read(ctx).also { cache = it } }

    private fun read(ctx: Context): List<SylGroup> {
        val out = ArrayList<SylGroup>()
        val files = try { ctx.assets.list("syllabus")?.filter { it.endsWith(".json") }?.sorted() ?: emptyList() } catch (e: Exception) { emptyList() }
        for (f in files) {
            try {
                val text = ctx.assets.open("syllabus/$f").bufferedReader(Charsets.UTF_8).use { it.readText() }
                val groups = JSONObject(text).getJSONArray("groups")
                for (gi in 0 until groups.length()) {
                    val g = groups.getJSONObject(gi)
                    val ps = g.getJSONArray("papers")
                    val papers = (0 until ps.length()).map { pi ->
                        val p = ps.getJSONObject(pi)
                        val secs = p.getJSONArray("sections")
                        SylPaper(
                            p.optInt("no"), p.optString("title"), p.optString("meta"),
                            (0 until secs.length()).map { si ->
                                val s = secs.getJSONObject(si)
                                val its = s.getJSONArray("items")
                                SylSection(s.optString("heading"), (0 until its.length()).map { ii -> its.getString(ii) })
                            },
                        )
                    }
                    out.add(SylGroup(g.optString("name"), g.optString("note"), papers))
                }
            } catch (e: Exception) { /* skip a broken file */ }
        }
        return out
    }
}

private fun key(group: SylGroup, paper: SylPaper, s: Int, i: Int) = "${group.name}|${paper.no}|$s|$i"

private fun doneCount(prefs: HubPrefs, group: SylGroup, paper: SylPaper): Int {
    var n = 0
    paper.sections.forEachIndexed { s, sec -> sec.items.indices.forEach { i -> if (key(group, paper, s, i) in prefs.sylDone) n++ } }
    return n
}

/** The Syllabus tab: list of papers; tapping one opens the course detail (topics you can tick off). */
@Composable
fun SyllabusTab(prefs: HubPrefs) {
    val ctx = LocalContext.current.applicationContext
    val groups by produceState<List<SylGroup>>(emptyList()) { value = withContext(Dispatchers.IO) { HubSyllabus.load(ctx) } }
    var selected by rememberSaveable { mutableStateOf("") }   // "groupIndex|paperIndex" or ""
    val parts = selected.split("|")
    val gi = parts.getOrNull(0)?.toIntOrNull()
    val pi = parts.getOrNull(1)?.toIntOrNull()
    val group = if (gi != null) groups.getOrNull(gi) else null
    val paper = if (group != null && pi != null) group.papers.getOrNull(pi) else null

    if (group != null && paper != null) {
        BackHandler { selected = "" }
        SyllabusDetail(prefs, group, paper) { selected = "" }
        return
    }

    val header = hubHeaderColor(LocalHubPalette.current, LocalHubDark.current)
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxWidth().background(header).padding(20.dp)) {
                Text("Syllabus", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Punjab PMS, paper by paper. Tap a paper for its course detail.", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
            if (groups.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Loading...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    groups.forEachIndexed { g, grp ->
                        item(key = "g-$g") {
                            Column {
                                Text(grp.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                                if (grp.note.isNotBlank()) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(grp.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 17.sp)
                                }
                            }
                        }
                        items(grp.papers.size, key = { "p-$g-$it" }) { p ->
                            val paperItem = grp.papers[p]
                            val done = doneCount(prefs, grp, paperItem)
                            val total = paperItem.topicCount
                            Card(
                                Modifier.fillMaxWidth().clickable { selected = "$g|$p" },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(2.dp),
                            ) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                                        contentAlignment = Alignment.Center,
                                    ) { Text("${paperItem.no}", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold) }
                                    Spacer(Modifier.size(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(paperItem.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        Text(paperItem.meta, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                                        Spacer(Modifier.height(6.dp))
                                        LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth())
                                        Text("$done of $total topics done", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SyllabusDetail(prefs: HubPrefs, group: SylGroup, paper: SylPaper, onBack: () -> Unit) {
    val done = doneCount(prefs, group, paper)
    val total = paper.topicCount
    ToolScaffold("Paper ${paper.no}", onBack) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item(key = "top") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(paper.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        // "100 marks | Objective (MCQs)" -> small chips
                        paper.meta.split("|").map { it.trim() }.filter { it.isNotEmpty() }.forEach { part ->
                            Box(Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 9.dp, vertical = 4.dp)) {
                                Text(part, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                        }
                    }
                    LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth())
                    Text("$done of $total topics done  ·  ${paper.sections.size} sections", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (group.note.isNotBlank()) Text(group.note, fontSize = 11.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(paper.sections.size, key = { "s-$it" }) { s ->
                val sec = paper.sections[s]
                var open by rememberSaveable(group.name, paper.no, s) { mutableStateOf(s == 0) }
                val secDone = sec.items.indices.count { key(group, paper, s, it) in prefs.sylDone }
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                ) {
                    Column {
                        Row(Modifier.fillMaxWidth().clickable { open = !open }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(sec.heading, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                Text("$secDone / ${sec.items.size} topics", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(if (open) "−" else "+", fontSize = 22.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        if (open) {
                            sec.items.forEachIndexed { i, item ->
                                val k = key(group, paper, s, i)
                                val checked = k in prefs.sylDone
                                Row(
                                    Modifier.fillMaxWidth().clickable { prefs.toggleSyl(k) }.padding(start = 6.dp, end = 14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Checkbox(checked = checked, onCheckedChange = { prefs.toggleSyl(k) })
                                    Text(
                                        "${i + 1}. $item", fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(vertical = 6.dp),
                                        color = if (checked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                    )
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                        }
                    }
                }
            }
        }
    }
}
