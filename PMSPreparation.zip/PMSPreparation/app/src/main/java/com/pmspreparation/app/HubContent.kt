package com.pmspreparation.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Reads the merged apps' bundled data for global search, the mixed MCQ test and the word of the day. */
object HubContent {
    class Hit(val text: String, val sub: String, val appId: String)
    class Mcq(val source: String, val q: String, val options: List<String>, val answer: Int, val explanation: String, val topic: String = "")
    class Recall(val heading: String, val short: String, val long: String, val topic: String)
    class Word(val word: String, val meaning: String, val example: String, val urdu: String)

    @Volatile private var hits: List<Hit>? = null
    @Volatile private var wordList: List<Word>? = null

    private fun read(ctx: Context, path: String): String? = try {
        ctx.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
    } catch (e: Exception) { null }

    private fun JSONArray.objects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }

    // ---------- global search ----------
    fun search(ctx: Context, q: String): List<Hit> {
        val all = hits ?: synchronized(this) { hits ?: buildIndex(ctx).also { hits = it } }
        return all.filter { it.text.contains(q, ignoreCase = true) }.take(40)
    }

    private fun buildIndex(ctx: Context): List<Hit> {
        val out = ArrayList<Hit>()
        try {
            read(ctx, "essay/essays.json")?.let { s ->
                JSONObject(s).getJSONArray("categories").objects().forEach { c ->
                    c.optJSONArray("essays")?.objects()?.forEach { e ->
                        val t = e.optString("title"); if (t.isNotBlank()) out.add(Hit(t, "PMS/CSS Essay · essay", "essay"))
                    }
                }
            }
        } catch (e: Exception) { }
        try {
            read(ctx, "pakstudies/topics.json")?.let { s ->
                JSONObject(s).getJSONArray("sections").objects().forEach { sec ->
                    sec.optJSONArray("topics")?.objects()?.forEach { t ->
                        out.add(Hit(t.optString("title"), "Pak-Studies 1 · topic", "pakstudies"))
                        t.optJSONArray("headings")?.objects()?.forEach { h ->
                            val ht = h.optString("title"); if (ht.isNotBlank()) out.add(Hit(ht, "Pak-Studies 1 · ${t.optString("title")}", "pakstudies"))
                        }
                    }
                }
            }
        } catch (e: Exception) { }
        try {
            read(ctx, "grammar/lessons.json")?.let { s ->
                JSONArray(s).objects().forEach { l ->
                    val topic = l.optString("topicId").replace('_', ' ').replaceFirstChar { it.uppercase() }
                    out.add(Hit(topic, "Complete English Grammar · lesson", "grammar"))
                    l.optJSONArray("sections")?.objects()?.forEach { sec ->
                        val t = sec.optString("title"); if (t.isNotBlank()) out.add(Hit(t, "Complete English Grammar · $topic", "grammar"))
                    }
                }
            }
        } catch (e: Exception) { }
        try {
            read(ctx, "socialwork/content/glossary.json")?.let { s ->
                JSONObject(s).getJSONArray("terms").objects().forEach { t ->
                    val en = t.optString("en"); if (en.isNotBlank()) out.add(Hit(en, "Social Work Academy · glossary", "socialwork"))
                }
            }
        } catch (e: Exception) { }
        try {
            HubSyllabus.load(ctx).forEach { g ->
                g.papers.forEach { p ->
                    p.sections.forEach { sec ->
                        sec.items.forEach { out.add(Hit(it, "Syllabus · Paper ${p.no} · ${sec.heading}", "syllabus")) }
                    }
                }
            }
        } catch (e: Exception) { }
        words(ctx).forEach { out.add(Hit("${it.word} - ${it.meaning}", "Vocabulary", "essay")) }
        return out
    }

    fun essayTitles(ctx: Context): List<String> {
        val out = ArrayList<String>()
        try {
            read(ctx, "essay/essays.json")?.let { s ->
                JSONObject(s).getJSONArray("categories").objects().forEach { c ->
                    c.optJSONArray("essays")?.objects()?.forEach { e ->
                        val t = e.optString("title"); if (t.isNotBlank()) out.add(t)
                    }
                }
            }
        } catch (e: Exception) { }
        return out
    }

    // ---------- vocabulary / word of the day ----------
    fun words(ctx: Context): List<Word> = wordList ?: synchronized(this) { wordList ?: buildWords(ctx).also { wordList = it } }

    private fun buildWords(ctx: Context): List<Word> {
        val out = ArrayList<Word>()
        try {
            read(ctx, "essay/vocabulary.json")?.let { s ->
                JSONObject(s).getJSONArray("vocabulary").objects().forEach {
                    out.add(Word(it.optString("word"), it.optString("meaning"), it.optString("example"), it.optString("urdu")))
                }
            }
        } catch (e: Exception) { }
        try {
            read(ctx, "grammar/vocabulary.json")?.let { s ->
                JSONArray(s).objects().forEach {
                    out.add(Word(it.optString("word"), it.optString("meaning"), it.optString("example"), it.optString("urdu")))
                }
            }
        } catch (e: Exception) { }
        return out.filter { it.word.isNotBlank() && it.meaning.isNotBlank() }
    }

    // ---------- recall cards (heading, then the explanation) ----------
    fun recallCards(ctx: Context): List<Recall> {
        val out = ArrayList<Recall>()
        try {
            read(ctx, "socialwork/content/details.json")?.let { s ->
                JSONObject(s).getJSONArray("topics").objects().forEach { t ->
                    val topic = com.socialwork.academy.data.TopicCatalog.byId(t.optString("id"))?.titleEn ?: ""
                    t.optJSONArray("en")?.objects()?.forEach { e ->
                        val h = e.optString("t").trim()
                        if (h.isNotBlank()) out.add(Recall(h, e.optString("s").trim(), e.optString("l").trim(), topic))
                    }
                }
            }
        } catch (e: Exception) { }
        return out
    }

    // ---------- MCQs for the mixed test ----------
    val MCQ_SOURCES = listOf("pak" to "Pak-Studies 1", "social" to "Social Work Academy", "grammar" to "English Grammar")

    fun mcqs(ctx: Context, source: String): List<Mcq> {
        val out = ArrayList<Mcq>()
        try {
            when (source) {
                "pak" -> read(ctx, "pakstudies/mcqs.json")?.let { s ->
                    val names = HashMap<Int, String>()
                    try {
                        read(ctx, "pakstudies/topics.json")?.let { ts ->
                            JSONObject(ts).getJSONArray("sections").objects().forEach { sec ->
                                sec.optJSONArray("topics")?.objects()?.forEach { t -> names[t.optInt("id")] = t.optString("title") }
                            }
                        }
                    } catch (e: Exception) { }
                    JSONArray(s).objects().forEach { o ->
                        val opts = o.optJSONArray("o")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()
                        out.add(Mcq("Pak-Studies 1", o.optString("q"), opts, o.optInt("a", 0), o.optString("e"), names[o.optInt("t")] ?: "Topic ${o.optInt("t")}"))
                    }
                }
                "social" -> read(ctx, "socialwork/content/mcqs.json")?.let { s ->
                    JSONObject(s).getJSONArray("questions").objects().filter { it.optString("lang") == "en" }.forEach { o ->
                        val opts = o.optJSONArray("options")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()
                        out.add(Mcq("Social Work Academy", o.optString("question"), opts, o.optInt("answer", 0), o.optString("explanation"), com.socialwork.academy.data.TopicCatalog.byId(o.optString("topicId"))?.titleEn ?: o.optString("topicId")))
                    }
                }
                "grammar" -> read(ctx, "grammar/questions.json")?.let { s ->
                    JSONArray(s).objects().forEach { o ->
                        val opts = o.optJSONArray("options")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()
                        out.add(Mcq("English Grammar", o.optString("q"), opts, o.optInt("answer", 0), o.optString("explanation"), o.optString("topic").replace('_', ' ').replaceFirstChar { ch -> ch.uppercase() }))
                    }
                }
            }
        } catch (e: Exception) { }
        return out.filter { it.q.isNotBlank() && it.options.size >= 2 && it.answer in it.options.indices }
    }
}
