package com.pmspreparation.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Emerald = Color(0xFF0B5D3B)
private val EmeraldDark = Color(0xFF06251A)
private val Gold = Color(0xFFF2C14E)
private val Paper = Color(0xFFF7F5EC)

@Composable
private fun HubTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Gold, onPrimary = EmeraldDark, background = Color(0xFF0E1511), onBackground = Color(0xFFE8EDE9),
            surface = Color(0xFF17211B), onSurface = Color(0xFFE8EDE9), surfaceVariant = Color(0xFF24312A),
            onSurfaceVariant = Color(0xFFC3CEC7),
        )
    } else {
        lightColorScheme(
            primary = Emerald, onPrimary = Color.White, background = Paper, onBackground = Color(0xFF1B1F1C),
            surface = Color.White, onSurface = Color(0xFF1B1F1C), surfaceVariant = Color(0xFFEAE6D8),
            onSurfaceVariant = Color(0xFF3F4A43),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

/** Joint home page: title, search, and one card per app, grouped by category (2 cards per row). */
@Composable
fun HomeHub(onOpen: (SubApp) -> Unit) {
    HubTheme {
        var query by rememberSaveable { mutableStateOf("") }
        val q = query.trim()
        val apps = remember(q) {
            if (q.isEmpty()) SUB_APPS
            else SUB_APPS.filter { it.title.contains(q, true) || it.subtitle.contains(q, true) || it.category.contains(q, true) }
        }
        val groups = remember(apps) { apps.groupBy { it.category }.toList() }

        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                // Header
                Column(
                    Modifier.fillMaxWidth()
                        .background(Emerald)
                        .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 20.dp)
                ) {
                    Text("PMS Preparation", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Everything for your PMS / CSS preparation", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true, shape = RoundedCornerShape(14.dp),
                        placeholder = { Text("Search apps") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear")
                            }
                        },
                        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                            focusedTextColor = Color(0xFF1B1F1C), unfocusedTextColor = Color(0xFF1B1F1C),
                            focusedBorderColor = Gold, unfocusedBorderColor = Color.Transparent,
                            focusedPlaceholderColor = Color(0xFF6B756E), unfocusedPlaceholderColor = Color(0xFF6B756E),
                            focusedLeadingIconColor = Emerald, unfocusedLeadingIconColor = Emerald,
                            focusedTrailingIconColor = Emerald, unfocusedTrailingIconColor = Emerald,
                            cursorColor = Emerald,
                        ),
                    )
                }

                if (groups.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No app found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        groups.forEach { (category, list) ->
                            item(key = "h-$category") {
                                Text(
                                    category, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    modifier = Modifier.padding(top = 6.dp, start = 4.dp),
                                )
                            }
                            items(list.chunked(2), key = { row -> "r-" + row.joinToString { it.id } }) { row ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    row.forEach { app -> AppCard(app, Modifier.weight(1f)) { onOpen(app) } }
                                    if (row.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppCard(app: SubApp, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.aspectRatio(0.95f).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(app.accent),
                contentAlignment = Alignment.Center,
            ) { Icon(app.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp)) }
            Column {
                Text(
                    app.title, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface, maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    app.subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
