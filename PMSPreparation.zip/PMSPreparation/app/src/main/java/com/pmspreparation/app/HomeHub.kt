package com.pmspreparation.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Spellcheck
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.StickyNote2
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Calendar

private val QUOTES = listOf(
    "Unity, Faith, Discipline." to "Quaid-e-Azam",
    "Small daily improvements add up to big results." to "",
    "Revise today what you learned yesterday." to "",
    "Consistency beats intensity." to "",
    "One essay outline a day keeps the panic away." to "",
    "Success is the sum of small efforts repeated day after day." to "",
    "Start where you are. Use what you have. Do what you can." to "",
)

/** Tool tabs on the home page: tab name to the tool ids it holds. */
private val TOOL_CATS = listOf(
    "Practice" to listOf("mock", "topictest", "daily", "timed", "mistakes", "savedq", "recall", "flashcards", "pastpapers"),
    "Plan" to listOf("planner", "smartplan", "weak", "revision", "timetable", "prayer", "checklist"),
    "Writing" to listOf("essay", "outline", "precis", "checker"),
    "Progress" to listOf("report", "calendar", "badges", "level", "export"),
    "Study aids" to listOf("notes", "saved", "affairs", "facts", "pomodoro", "focus"),
)

private class Tool(val id: String, val title: String, val icon: ImageVector)

private val TOOLS = listOf(
    Tool("report", "Weekly report", Icons.Filled.BarChart),
    Tool("calendar", "Study calendar", Icons.Filled.CalendarMonth),
    Tool("badges", "Badges", Icons.Filled.EmojiEvents),
    Tool("mock", "Mixed MCQ test", Icons.Filled.Quiz),
    Tool("notes", "My notes", Icons.Filled.StickyNote2),
    Tool("checklist", "Checklist", Icons.Filled.Checklist),
    Tool("pomodoro", "Pomodoro", Icons.Filled.Timer),
    Tool("planner", "Study planner", Icons.Filled.Event),
    Tool("revision", "Revision", Icons.Filled.Autorenew),
    Tool("flashcards", "Flashcards", Icons.Filled.Style),
    Tool("daily", "Daily challenge", Icons.Filled.Today),
    Tool("timed", "Timed paper", Icons.Filled.HourglassBottom),
    Tool("mistakes", "Mistake notebook", Icons.Filled.ErrorOutline),
    Tool("saved", "Saved items", Icons.Filled.Bookmark),
    Tool("pastpapers", "Past papers", Icons.Filled.FolderOpen),
    Tool("affairs", "Current affairs", Icons.Filled.Language),
    Tool("essay", "Essay practice", Icons.Filled.Edit),
    Tool("timetable", "Timetable", Icons.Filled.AccessTime),
    Tool("prayer", "Prayer-time blocks", Icons.Filled.WbSunny),
    Tool("focus", "Focus mode", Icons.Filled.CenterFocusStrong),
    Tool("level", "Level and points", Icons.Filled.Star),
    Tool("export", "Export to PDF", Icons.Filled.PictureAsPdf),
    Tool("weak", "Weak topics", Icons.Filled.TrendingDown),
    Tool("smartplan", "Smart revision plan", Icons.Filled.Insights),
    Tool("topictest", "Topic-wise test", Icons.Filled.Quiz),
    Tool("savedq", "Saved questions", Icons.Filled.BookmarkAdded),
    Tool("recall", "Open recall", Icons.Filled.Psychology),
    Tool("outline", "Essay outline builder", Icons.Filled.AccountTree),
    Tool("precis", "Precis and comprehension", Icons.Filled.Description),
    Tool("checker", "Writing checker", Icons.Filled.Spellcheck),
    Tool("facts", "Quick facts", Icons.Filled.Lightbulb),
)

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

private fun formatStudy(ms: Long): String {
    val min = (ms / 60_000L).toInt()
    return if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"
}

/** Joint home page: greeting, search, interactive widgets and one card per app, grouped by category. */
@Composable
fun HomeHub(prefs: HubPrefs, onOpen: (SubApp) -> Unit, onTool: (String) -> Unit) {
    val header = hubHeaderColor(LocalHubPalette.current, LocalHubDark.current)
    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim()
    var toolCat by rememberSaveable { mutableStateOf("Practice") }
    val apps = remember(q) {
        if (q.isEmpty()) SUB_APPS
        else SUB_APPS.filter { it.title.contains(q, true) || it.subtitle.contains(q, true) || it.category.contains(q, true) }
    }
    val groups = remember(apps) { apps.groupBy { it.category }.toList() }
    val lastApp = SUB_APPS.firstOrNull { it.id == prefs.lastApp }
    val ctx = LocalContext.current.applicationContext
    // Search inside the apps' own content (essay titles, topics, lessons, glossary, vocabulary).
    val inside by produceState<List<HubContent.Hit>>(emptyList(), q) {
        value = if (q.length >= 2) {
            delay(250)
            withContext(Dispatchers.IO) { HubContent.search(ctx, q) }
        } else emptyList()
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            // Header: greeting with the user's name, settings, search
            Column(Modifier.fillMaxWidth().background(header).padding(start = 20.dp, end = 8.dp, top = 14.dp, bottom = 18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppLogo(44.dp)
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("PMS Preparation", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(
                            greeting() + if (prefs.name.isNotBlank()) ", ${prefs.name}" else "",
                            color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconButton(onClick = { onTool("settings") }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(end = 12.dp),
                    singleLine = true, shape = RoundedCornerShape(14.dp),
                    placeholder = { Text(HubText.t(prefs, "Search apps")) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear")
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                        focusedTextColor = Color(0xFF1B1F1C), unfocusedTextColor = Color(0xFF1B1F1C),
                        focusedBorderColor = LocalHubPalette.current.accent, unfocusedBorderColor = Color.Transparent,
                        focusedPlaceholderColor = Color(0xFF6B756E), unfocusedPlaceholderColor = Color(0xFF6B756E),
                        focusedLeadingIconColor = Color(0xFF3F4A43), unfocusedLeadingIconColor = Color(0xFF3F4A43),
                        focusedTrailingIconColor = Color(0xFF3F4A43), unfocusedTrailingIconColor = Color(0xFF3F4A43),
                        cursorColor = Color(0xFF1B1F1C),
                    ),
                )
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Widgets are hidden while searching so results stay in view.
                if (q.isEmpty()) {
                    prefs.homeOrder.filter { it !in prefs.homeHidden }.forEach { wid ->
                        when (wid) {
                            "continue" -> item(key = "continue") { ContinueWidget(lastApp, onOpen) }
                            "stats" -> item(key = "stats") {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    StreakWidget(prefs, Modifier.weight(1f))
                                    TimerWidget(prefs, Modifier.weight(1f))
                                }
                            }
                            "goal" -> item(key = "goal") {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    GoalWidget(prefs, Modifier.weight(1f)) { onTool("settings") }
                                    ExamWidget(prefs, Modifier.weight(1f)) { onTool("settings") }
                                }
                            }
                            "word" -> item(key = "word") { WordWidget() }
                            "quote" -> item(key = "quote") { QuoteWidget() }
                        }
                    }
                    val favs = SUB_APPS.filter { it.id in prefs.favorites }
                    if (favs.isNotEmpty()) {
                        item(key = "fh") {
                            Text(
                                HubText.t(prefs, "Favorites"), fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(top = 6.dp, start = 4.dp),
                            )
                        }
                        items(favs, key = { "f-" + it.id }) { app -> AppRow(app, true, { prefs.toggleFavorite(app.id) }) { onOpen(app) } }
                    }
                }
                if (groups.isEmpty() && inside.isEmpty()) {
                    item(key = "none") {
                        Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("No app found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                groups.forEach { (category, list) ->
                    item(key = "h-$category") {
                        Text(
                            category, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.padding(top = 6.dp, start = 4.dp),
                        )
                    }
                    items(list, key = { it.id }) { app -> AppRow(app, app.id in prefs.favorites, { prefs.toggleFavorite(app.id) }) { onOpen(app) } }
                }
                if (q.isEmpty()) {
                    item(key = "th") {
                        Text(
                            HubText.t(prefs, "Tools"), fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(top = 6.dp, start = 4.dp),
                        )
                    }
                    item(key = "tt") {
                        ScrollableTabRow(
                            selectedTabIndex = TOOL_CATS.indexOfFirst { it.first == toolCat }.coerceAtLeast(0),
                            edgePadding = 0.dp,
                            containerColor = Color.Transparent,
                        ) {
                            TOOL_CATS.forEach { (name, _) ->
                                Tab(selected = toolCat == name, onClick = { toolCat = name }, text = { Text(HubText.t(prefs, name), maxLines = 1) })
                            }
                        }
                    }
                    val catTools = (TOOL_CATS.firstOrNull { it.first == toolCat }?.second ?: emptyList()).mapNotNull { id -> TOOLS.firstOrNull { it.id == id } }
                    items(catTools.chunked(2), key = { row -> "t-" + row.joinToString { it.id } }) { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { t -> ToolTile(t, HubText.t(prefs, t.title), Modifier.weight(1f)) { onTool(t.id) } }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
                if (q.isNotEmpty() && inside.isNotEmpty()) {
                    item(key = "ih") {
                        Text(
                            "Inside the apps (opens the app)", fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(top = 6.dp, start = 4.dp),
                        )
                    }
                    items(inside.size, key = { "i-$it" }) { i ->
                        val hit = inside[i]
                        WidgetCard(Modifier.fillMaxWidth(), onClick = {
                            if (hit.appId == "syllabus") onTool("tab:syllabus") else SUB_APPS.firstOrNull { it.id == hit.appId }?.let(onOpen)
                        }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(hit.text, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(hit.sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                val saved = prefs.isBookmarked(hit.text, hit.sub)
                                IconButton(onClick = { prefs.toggleBookmark(hit.text, hit.sub, hit.appId) }) {
                                    Icon(
                                        if (saved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder, contentDescription = "Save",
                                        tint = MaterialTheme.colorScheme.primary,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WidgetCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    Card(
        modifier = if (onClick != null) modifier.clickable(onClick = onClick) else modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) { Box(Modifier.padding(16.dp)) { content() } }
}

@Composable
private fun ContinueWidget(lastApp: SubApp?, onOpen: (SubApp) -> Unit) {
    WidgetCard(Modifier.fillMaxWidth(), onClick = lastApp?.let { app -> { onOpen(app) } }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.PlayCircle, contentDescription = null, modifier = Modifier.size(40.dp),
                tint = lastApp?.accent ?: MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (lastApp != null) "Continue where you left off" else "Welcome! Pick an app below to start",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (lastApp != null) Text(
                    lastApp.title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun StreakWidget(prefs: HubPrefs, modifier: Modifier) {
    WidgetCard(modifier) {
        Column {
            Text("🔥", fontSize = 28.sp)
            Text(
                "${prefs.streak} day" + if (prefs.streak == 1) "" else "s",
                fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface,
            )
            Text("Study streak", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TimerWidget(prefs: HubPrefs, modifier: Modifier) {
    val running = prefs.timerStart > 0L
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(running) {
        while (running) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val live = if (running) (now - prefs.timerStart).coerceIn(0L, 4 * 3_600_000L) else 0L
    WidgetCard(modifier) {
        Column {
            Text(formatStudy(prefs.todayMs + live), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text("Studied today", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            FilledTonalButton(onClick = { if (running) prefs.stopTimer() else prefs.startTimer() }) {
                Icon(if (running) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(4.dp))
                Text(if (running) "Stop" else "Start", fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun QuoteWidget() {
    var index by rememberSaveable {
        mutableIntStateOf((System.currentTimeMillis() / 86_400_000L % QUOTES.size).toInt())
    }
    val (text, author) = QUOTES[index]
    WidgetCard(Modifier.fillMaxWidth(), onClick = { index = (index + 1) % QUOTES.size }) {
        Column {
            Text("Quote of the day (tap for another)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            Text("“$text”", fontSize = 16.sp, lineHeight = 23.sp, color = MaterialTheme.colorScheme.onSurface)
            if (author.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text("— $author", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AppRow(app: SubApp, favorite: Boolean, onToggleFavorite: () -> Unit, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(app.accent),
                contentAlignment = Alignment.Center,
            ) { Icon(app.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(app.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(2.dp))
                Text(app.subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    if (favorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = if (favorite) "Remove from favorites" else "Add to favorites",
                    tint = if (favorite) LocalHubPalette.current.accent else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun GoalWidget(prefs: HubPrefs, modifier: Modifier, onClick: () -> Unit) {
    val doneMin = (prefs.todayMs / 60_000L).toInt()
    val frac = (doneMin.toFloat() / prefs.dailyGoal.coerceAtLeast(1)).coerceIn(0f, 1f)
    WidgetCard(modifier, onClick = onClick) {
        Column {
            Text("Daily goal", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "$doneMin / ${prefs.dailyGoal} min", fontSize = 17.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(4.dp))
            Text(if (frac >= 1f) "Goal reached!" else "Keep going", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ExamWidget(prefs: HubPrefs, modifier: Modifier, onClick: () -> Unit) {
    WidgetCard(modifier, onClick = onClick) {
        Column {
            Text("Exam countdown", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (prefs.examDay < 0) {
                Text("Set exam date", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(8.dp))
                Text("Tap to choose", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val left = prefs.examDay - prefs.today()
                Text(
                    when {
                        left > 1L -> "$left days"
                        left == 1L -> "1 day"
                        left == 0L -> "Today!"
                        else -> "Passed"
                    },
                    fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.height(4.dp))
                Text(if (left >= 0L) "until your exam" else "Set a new date in Settings", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun WordWidget() {
    val ctx = LocalContext.current.applicationContext
    val words by produceState<List<HubContent.Word>>(emptyList()) {
        value = withContext(Dispatchers.IO) { HubContent.words(ctx) }
    }
    if (words.isEmpty()) return
    val w = words[((System.currentTimeMillis() / 86_400_000L) % words.size).toInt()]
    WidgetCard(Modifier.fillMaxWidth()) {
        Column {
            Text("Word of the day", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(w.word, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(w.meaning, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            if (w.urdu.isNotBlank()) Text(w.urdu, fontSize = 20.sp, lineHeight = 36.sp, fontFamily = UrduFont, color = MaterialTheme.colorScheme.onSurface)
            if (w.example.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text("\u201C${w.example}\u201D", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ToolTile(tool: Tool, title: String, modifier: Modifier, onClick: () -> Unit) {
    WidgetCard(modifier, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(tool.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
            Spacer(Modifier.size(10.dp))
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 2)
        }
    }
}
