package com.pmspreparation.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Calendar

class HubNote(val id: Long, val title: String, val text: String)
class HubTask(val text: String, val done: Boolean)

/** Day number (days since 1970, in the phone's time zone) for a calendar. */
fun epochDayOf(c: Calendar): Long = (c.timeInMillis + c.timeZone.getOffset(c.timeInMillis)) / 86_400_000L

/**
 * Settings, study log and small user data for the joint home page.
 * (The merged apps keep their own settings and data.)
 * Note: functions are named change*/add*/... on purpose; names like setX would clash with Kotlin's generated setters.
 */
class HubPrefs(context: Context) {
    private val p = context.getSharedPreferences("hub", Context.MODE_PRIVATE)

    var name by mutableStateOf(p.getString("name", "") ?: ""); private set
    var onboarded by mutableStateOf(p.getBoolean("onboarded", false)); private set
    var guideSeen by mutableStateOf(p.getBoolean("guideSeen", false)); private set
    /** 0 = follow system, 1 = light, 2 = dark. */
    var themeMode by mutableIntStateOf(p.getInt("themeMode", 0)); private set
    var palette by mutableIntStateOf(p.getInt("palette", 0).coerceIn(0, HUB_PALETTES.lastIndex)); private set
    var fontStep by mutableIntStateOf(p.getInt("fontStep", 1).coerceIn(0, FONT_STEPS.lastIndex)); private set
    var lastApp by mutableStateOf(p.getString("lastApp", null)); private set
    var streak by mutableIntStateOf(0); private set
    /** Study time today in ms (timer + time spent inside the apps + pomodoros). */
    var todayMs by mutableLongStateOf(0L); private set
    /** Start time of a running study timer, or 0 when stopped. */
    var timerStart by mutableLongStateOf(p.getLong("timerStart", 0L)); private set
    /** Goal in minutes per day. */
    var dailyGoal by mutableIntStateOf(p.getInt("goal", 60)); private set
    /** Exam day as a day number, or -1 when not set. */
    var examDay by mutableLongStateOf(p.getLong("examDay", -1L)); private set
    /** Hour (0-23) of the daily reminder, or -1 when off. */
    var reminderHour by mutableIntStateOf(p.getInt("reminder", -1)); private set
    var favorites by mutableStateOf<Set<String>>(p.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()); private set
    /** Syllabus topics the user has ticked off (keys built by the syllabus screen). */
    var sylDone by mutableStateOf<Set<String>>(p.getStringSet("sylDone", emptySet())?.toSet() ?: emptySet()); private set
    var hasPin by mutableStateOf(p.getString("pinHash", null) != null); private set
    var mockTests by mutableIntStateOf(p.getInt("mockTests", 0)); private set
    var pomodoros by mutableIntStateOf(p.getInt("pomodoros", 0)); private set
    /** Bumped whenever the study log changes, so screens can recompute. */
    var logVersion by mutableIntStateOf(0); private set
    var notes by mutableStateOf<List<HubNote>>(emptyList()); private set
    var tasks by mutableStateOf<List<HubTask>>(emptyList()); private set

    init {
        val d = today()
        val last = p.getLong("lastDay", -1L)
        var s = p.getInt("streak", 0)
        if (last != d) {
            s = if (last == d - 1) s + 1 else 1
            p.edit().putLong("lastDay", d).putInt("streak", s).apply()
        }
        streak = s
        todayMs = dayMs(d)
        notes = loadNotes()
        tasks = loadTasks()
    }

    fun today(): Long = epochDayOf(Calendar.getInstance())

    // ---- profile / look ----
    fun updateName(v: String) { name = v.trim().take(24); p.edit().putString("name", name).apply() }
    fun finishOnboarding() { onboarded = true; p.edit().putBoolean("onboarded", true).apply() }
    fun markGuideSeen() { guideSeen = true; p.edit().putBoolean("guideSeen", true).apply() }
    fun changeThemeMode(v: Int) { themeMode = v; p.edit().putInt("themeMode", v).apply() }
    fun changePalette(v: Int) { palette = v; p.edit().putInt("palette", v).apply() }
    fun changeFontStep(v: Int) { fontStep = v; p.edit().putInt("fontStep", v).apply() }
    fun updateLastApp(id: String) { lastApp = id; p.edit().putString("lastApp", id).apply() }

    // ---- goals, exam, reminder, favourites ----
    fun changeDailyGoal(min: Int) { dailyGoal = min; p.edit().putInt("goal", min).apply() }
    fun changeExamDay(day: Long) { examDay = day; p.edit().putLong("examDay", day).apply() }
    fun changeReminder(hour: Int) { reminderHour = hour; p.edit().putInt("reminder", hour).apply() }
    fun toggleFavorite(id: String) {
        favorites = if (id in favorites) favorites - id else favorites + id
        p.edit().putStringSet("favorites", favorites.toSet()).apply()
    }

    // ---- study log ----
    fun addTime(appId: String?, ms: Long) {
        if (ms < 1000L) return
        val d = today()
        val e = p.edit()
        e.putLong("d_$d", dayMs(d) + ms)
        if (appId != null) e.putLong("a_${d}_$appId", appMs(d, appId) + ms)
        e.apply()
        todayMs = dayMs(d)
        logVersion++
    }
    fun dayMs(day: Long): Long = p.getLong("d_$day", 0L)
    fun appMs(day: Long, id: String): Long = p.getLong("a_${day}_$id", 0L)
    fun totalMs(): Long = p.all.entries.filter { it.key.startsWith("d_") }.sumOf { (it.value as? Long) ?: 0L }
    fun activeDays(): Set<Long> = p.all.keys.filter { it.startsWith("d_") }
        .mapNotNull { it.removePrefix("d_").toLongOrNull() }.filter { dayMs(it) > 0L }.toSet()
    fun appsUsed(): Int = p.all.keys.filter { it.startsWith("a_") }.map { it.substringAfter('_').substringAfter('_') }.toSet().size

    fun startTimer() {
        timerStart = System.currentTimeMillis()
        p.edit().putLong("timerStart", timerStart).apply()
    }

    fun stopTimer() {
        if (timerStart <= 0L) return
        // A timer someone forgot to stop counts at most 4 hours.
        val elapsed = (System.currentTimeMillis() - timerStart).coerceIn(0L, 4 * 3_600_000L)
        timerStart = 0L
        p.edit().putLong("timerStart", 0L).apply()
        addTime(null, elapsed)
    }

    fun recordMock() { mockTests++; p.edit().putInt("mockTests", mockTests).apply() }
    fun recordPomodoro() {
        pomodoros++; p.edit().putInt("pomodoros", pomodoros).apply()
        addTime(null, 25 * 60_000L)
    }

    fun toggleSyl(key: String) {
        sylDone = if (key in sylDone) sylDone - key else sylDone + key
        p.edit().putStringSet("sylDone", sylDone.toSet()).apply()
    }

    // ---- app lock ----
    private fun hash(pin: String): String {
        val salt = p.getString("pinSalt", null) ?: java.util.UUID.randomUUID().toString().also { p.edit().putString("pinSalt", it).apply() }
        return MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
    }
    fun changePin(pin: String?) {
        if (pin == null) p.edit().remove("pinHash").apply() else p.edit().putString("pinHash", hash(pin)).apply()
        hasPin = pin != null
    }
    fun checkPin(pin: String): Boolean = hash(pin) == p.getString("pinHash", null)

    // ---- notes ----
    private fun loadNotes(): List<HubNote> = try {
        val a = JSONArray(p.getString("notes", "[]") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); HubNote(o.getLong("id"), o.optString("title"), o.optString("text")) }
    } catch (e: Exception) { emptyList() }

    private fun persistNotes(list: List<HubNote>) {
        notes = list
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("text", it.text)) }
        p.edit().putString("notes", a.toString()).apply()
    }

    fun saveNote(id: Long?, title: String, text: String) {
        if (title.isBlank() && text.isBlank()) return
        val list = if (id == null) listOf(HubNote(System.currentTimeMillis(), title.trim(), text.trim())) + notes
        else notes.map { if (it.id == id) HubNote(id, title.trim(), text.trim()) else it }
        persistNotes(list)
    }
    fun deleteNote(id: Long) = persistNotes(notes.filter { it.id != id })

    // ---- checklist ----
    private fun loadTasks(): List<HubTask> = try {
        val a = JSONArray(p.getString("tasks", "[]") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); HubTask(o.optString("text"), o.optBoolean("done")) }
    } catch (e: Exception) { emptyList() }

    private fun persistTasks(list: List<HubTask>) {
        tasks = list
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("text", it.text).put("done", it.done)) }
        p.edit().putString("tasks", a.toString()).apply()
    }
    fun addTask(text: String) { if (text.isNotBlank()) persistTasks(tasks + HubTask(text.trim(), false)) }
    fun toggleTask(index: Int) = persistTasks(tasks.mapIndexed { i, t -> if (i == index) HubTask(t.text, !t.done) else t })
    fun deleteTask(index: Int) = persistTasks(tasks.filterIndexed { i, _ -> i != index })
}
