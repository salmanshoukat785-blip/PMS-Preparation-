package com.pmspreparation.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Calendar

/** Settings and small bits of progress for the joint home page (the merged apps keep their own settings). */
class HubPrefs(context: Context) {
    private val p = context.getSharedPreferences("hub", Context.MODE_PRIVATE)

    var name by mutableStateOf(p.getString("name", "") ?: ""); private set
    var onboarded by mutableStateOf(p.getBoolean("onboarded", false)); private set
    var guideSeen by mutableStateOf(p.getBoolean("guideSeen", false)); private set
    /** 0 = follow system, 1 = light, 2 = dark. */
    var themeMode by mutableStateOf(p.getInt("themeMode", 0)); private set
    var palette by mutableStateOf(p.getInt("palette", 0).coerceIn(0, HUB_PALETTES.lastIndex)); private set
    var fontStep by mutableStateOf(p.getInt("fontStep", 1).coerceIn(0, FONT_STEPS.lastIndex)); private set
    var lastApp by mutableStateOf(p.getString("lastApp", null)); private set
    var streak by mutableStateOf(0); private set
    /** Study time today in ms (finished timer sessions). */
    var todayMs by mutableStateOf(0L); private set
    /** Start time of a running study timer, or 0 when stopped. */
    var timerStart by mutableStateOf(p.getLong("timerStart", 0L)); private set

    init {
        val d = today()
        val last = p.getLong("lastDay", -1L)
        var s = p.getInt("streak", 0)
        if (last != d) {
            s = if (last == d - 1) s + 1 else 1
            p.edit().putLong("lastDay", d).putInt("streak", s).apply()
        }
        streak = s
        todayMs = if (p.getLong("timerDay", -1L) == d) p.getLong("timerMs", 0L) else 0L
    }

    private fun today(): Long {
        val c = Calendar.getInstance()
        return (c.timeInMillis + c.timeZone.getOffset(c.timeInMillis)) / 86_400_000L
    }

    fun updateName(v: String) { name = v.trim().take(24); p.edit().putString("name", name).apply() }
    fun finishOnboarding() { onboarded = true; p.edit().putBoolean("onboarded", true).apply() }
    fun markGuideSeen() { guideSeen = true; p.edit().putBoolean("guideSeen", true).apply() }
    fun changeThemeMode(v: Int) { themeMode = v; p.edit().putInt("themeMode", v).apply() }
    fun changePalette(v: Int) { palette = v; p.edit().putInt("palette", v).apply() }
    fun changeFontStep(v: Int) { fontStep = v; p.edit().putInt("fontStep", v).apply() }
    fun updateLastApp(id: String) { lastApp = id; p.edit().putString("lastApp", id).apply() }

    fun startTimer() {
        timerStart = System.currentTimeMillis()
        p.edit().putLong("timerStart", timerStart).apply()
    }

    fun stopTimer() {
        if (timerStart <= 0L) return
        // A timer someone forgot to stop counts at most 4 hours.
        val elapsed = (System.currentTimeMillis() - timerStart).coerceIn(0L, 4 * 3_600_000L)
        val d = today()
        if (p.getLong("timerDay", -1L) != d) todayMs = 0L
        todayMs += elapsed
        timerStart = 0L
        p.edit().putLong("timerStart", 0L).putLong("timerDay", d).putLong("timerMs", todayMs).apply()
    }
}
