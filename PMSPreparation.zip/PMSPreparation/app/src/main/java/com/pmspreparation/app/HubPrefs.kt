package com.pmspreparation.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Calendar

class HubNote(val id: Long, val title: String, val text: String)
class HubTask(val text: String, val done: Boolean)
/** One generic saved record (used by bookmarks, mistakes, revisions, timetable, past papers, current affairs, flashcards). */
class HubRec(val id: Long, val a: String = "", val b: String = "", val c: String = "", val d: String = "", val n: Int = 0, val m: Long = 0L)

val HOME_WIDGETS = listOf("continue", "stats", "goal", "word", "quote")

val HUB_LEVELS = listOf(
    0 to "Beginner", 50 to "Learner", 150 to "Student", 300 to "Scholar", 500 to "Achiever",
    800 to "Expert", 1200 to "Master", 1800 to "Topper", 2600 to "Champion", 3600 to "Legend",
)

/** Day number (days since 1970, in the phone's time zone) for a calendar. */
fun epochDayOf(c: Calendar): Long = (c.timeInMillis + c.timeZone.getOffset(c.timeInMillis)) / 86_400_000L

/**
 * Settings, study log and small user data for the joint home page.
 * (The merged apps keep their own settings and data.)
 * Note: functions are named change, add, toggle and so on on purpose; names like setX would clash with Kotlin generated setters.
 */
class HubPrefs(context: Context) {
    private val p = context.getSharedPreferences("hub", Context.MODE_PRIVATE)

    var name by mutableStateOf(p.getString("name", "") ?: ""); private set
    var onboarded by mutableStateOf(p.getBoolean("onboarded", false)); private set
    var guideSeen by mutableStateOf(p.getBoolean("guideSeen", false)); private set
    /** 0 = follow system, 1 = light, 2 = dark. */
    var themeMode by mutableIntStateOf(p.getInt("themeMode", 0)); private set
    var palette by mutableIntStateOf(p.getInt("palette", 0).coerceIn(0, HUB_PALETTES.lastIndex)); private set
    var fontStep by mutableIntStateOf(p.getInt("fontStep", 1).coerceIn(0, FONT_STEPS.lastIndex)); private set
    var lastApp by mutableStateOf(p.getString("lastApp", null)); private set
    var streak by mutableIntStateOf(0); private set
    /** Study time today in ms (timer + time spent inside the apps + pomodoros). */
    var todayMs by mutableLongStateOf(0L); private set
    /** Start time of a running study timer, or 0 when stopped. */
    var timerStart by mutableLongStateOf(p.getLong("timerStart", 0L)); private set
    /** Goal in minutes per day. */
    var dailyGoal by mutableIntStateOf(p.getInt("goal", 60)); private set
    /** Exam day as a day number, or -1 when not set. */
    var examDay by mutableLongStateOf(p.getLong("examDay", -1L)); private set
    /** Hour (0-23) of the daily reminder, or -1 when off. */
    var reminderHour by mutableIntStateOf(p.getInt("reminder", -1)); private set
    var favorites by mutableStateOf<Set<String>>(p.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()); private set
    /** Syllabus topics the user has ticked off (keys built by the syllabus screen). */
    var sylDone by mutableStateOf<Set<String>>(p.getStringSet("sylDone", emptySet())?.toSet() ?: emptySet()); private set
    /** Order of the home-page widgets and the ones the user switched off. */
    var homeOrder by mutableStateOf<List<String>>(
        (p.getString("homeOrder", null)?.split(",")?.filter { it in HOME_WIDGETS } ?: emptyList()).let { saved -> saved + HOME_WIDGETS.filter { it !in saved } }
    ); private set
    var homeHidden by mutableStateOf<Set<String>>(p.getStringSet("homeHidden", emptySet())?.toSet() ?: emptySet()); private set
    /** Home page and navigation in Urdu. */
    var hubUrdu by mutableStateOf(p.getBoolean("hubUrdu", false)); private set
    var reminderMsg by mutableStateOf(p.getString("reminderMsg", "") ?: ""); private set
    var tipsSeen by mutableStateOf<Set<String>>(p.getStringSet("tipsSeen", emptySet())?.toSet() ?: emptySet()); private set
    var hasPin by mutableStateOf(p.getString("pinHash", null) != null); private set
    var mockTests by mutableIntStateOf(p.getInt("mockTests", 0)); private set
    var pomodoros by mutableIntStateOf(p.getInt("pomodoros", 0)); private set
    /** Bumped whenever the study log changes, so screens can recompute. */
    var logVersion by mutableIntStateOf(0); private set
    var notes by mutableStateOf<List<HubNote>>(emptyList()); private set
    var tasks by mutableStateOf<List<HubTask>>(emptyList()); private set

    init {
        val d = today()
        val last = p.getLong("lastDay", -1L)
        var s = p.getInt("streak", 0)
        if (last != d) {
            val freezeDay = p.getLong("freezeDay", -100L)
            s = when {
                last == d - 1 -> s + 1
                // One missed day is forgiven, at most once in 7 days (streak freeze).
                last == d - 2 && s > 0 && d - freezeDay >= 7 -> { p.edit().putLong("freezeDay", d).apply(); s + 1 }
                else -> 1
            }
            p.edit().putLong("lastDay", d).putInt("streak", s).apply()
        }
        streak = s
        todayMs = dayMs(d)
        notes = loadNotes()
        tasks = loadTasks()
    }

    fun today(): Long = epochDayOf(Calendar.getInstance())

    // ---- profile / look ----
    fun updateName(v: String) { name = v.trim().take(24); p.edit().putString("name", name).apply() }
    fun finishOnboarding() { onboarded = true; p.edit().putBoolean("onboarded", true).apply() }
    fun markGuideSeen() { guideSeen = true; p.edit().putBoolean("guideSeen", true).apply() }
    fun changeThemeMode(v: Int) { themeMode = v; p.edit().putInt("themeMode", v).apply() }
    fun changePalette(v: Int) { palette = v; p.edit().putInt("palette", v).apply() }
    fun changeFontStep(v: Int) { fontStep = v; p.edit().putInt("fontStep", v).apply() }
    fun updateLastApp(id: String) { lastApp = id; p.edit().putString("lastApp", id).apply() }

    // ---- goals, exam, reminder, favourites ----
    fun changeDailyGoal(min: Int) { dailyGoal = min; p.edit().putInt("goal", min).apply() }
    fun changeExamDay(day: Long) { examDay = day; p.edit().putLong("examDay", day).apply() }
    fun changeReminder(hour: Int) { reminderHour = hour; p.edit().putInt("reminder", hour).apply() }
    fun toggleFavorite(id: String) {
        favorites = if (id in favorites) favorites - id else favorites + id
        p.edit().putStringSet("favorites", favorites.toSet()).apply()
    }

    // ---- study log ----
    fun addTime(appId: String?, ms: Long) {
        if (ms < 1000L) return
        val d = today()
        val e = p.edit()
        e.putLong("d_$d", dayMs(d) + ms)
        if (appId != null) e.putLong("a_${d}_$appId", appMs(d, appId) + ms)
        e.apply()
        todayMs = dayMs(d)
        logVersion++
    }
    fun dayMs(day: Long): Long = p.getLong("d_$day", 0L)
    fun appMs(day: Long, id: String): Long = p.getLong("a_${day}_$id", 0L)
    fun totalMs(): Long = p.all.entries.filter { it.key.startsWith("d_") }.sumOf { (it.value as? Long) ?: 0L }
    fun activeDays(): Set<Long> = p.all.keys.filter { it.startsWith("d_") }
        .mapNotNull { it.removePrefix("d_").toLongOrNull() }.filter { dayMs(it) > 0L }.toSet()
    fun appsUsed(): Int = p.all.keys.filter { it.startsWith("a_") }.map { it.substringAfter('_').substringAfter('_') }.toSet().size

    fun startTimer() {
        timerStart = System.currentTimeMillis()
        p.edit().putLong("timerStart", timerStart).apply()
    }

    fun stopTimer() {
        if (timerStart <= 0L) return
        // A timer someone forgot to stop counts at most 4 hours.
        val elapsed = (System.currentTimeMillis() - timerStart).coerceIn(0L, 4 * 3_600_000L)
        timerStart = 0L
        p.edit().putLong("timerStart", 0L).apply()
        addTime(null, elapsed)
    }

    fun recordMock() { mockTests++; p.edit().putInt("mockTests", mockTests).apply() }
    fun recordPomodoro() {
        pomodoros++; p.edit().putInt("pomodoros", pomodoros).apply()
        addTime(null, 25 * 60_000L)
    }

    /** Ticks or unticks a syllabus topic. Ticking also schedules revisions after 1, 3, 7 and 30 days. */
    fun toggleSyl(key: String, label: String = "") {
        val turnOn = key !in sylDone
        sylDone = if (turnOn) sylDone + key else sylDone - key
        p.edit().putStringSet("sylDone", sylDone.toSet()).apply()
        if (turnOn) {
            if (label.isNotBlank() && recs("rev").none { it.b == key }) addRec("rev", HubRec(System.currentTimeMillis(), label, key, n = 0, m = today()))
        } else {
            replaceRecs("rev", recs("rev").filter { it.b != key })
        }
    }

    // ---- generic record lists ----
    var recVersion by mutableIntStateOf(0); private set
    private val recCache = HashMap<String, List<HubRec>>()

    fun recs(name: String): List<HubRec> {
        if (recVersion < 0) return emptyList()   // reads the state so screens refresh when lists change
        return recCache.getOrPut(name) { loadRecs(name) }
    }

    private fun loadRecs(name: String): List<HubRec> = try {
        val arr = JSONArray(p.getString("rec_$name", "[]") ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HubRec(o.getLong("id"), o.optString("a"), o.optString("b"), o.optString("c"), o.optString("d"), o.optInt("n"), o.optLong("m"))
        }
    } catch (e: Exception) { emptyList() }

    fun replaceRecs(name: String, list: List<HubRec>) {
        recCache[name] = list
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("a", it.a).put("b", it.b).put("c", it.c).put("d", it.d).put("n", it.n).put("m", it.m))
        }
        p.edit().putString("rec_$name", arr.toString()).apply()
        recVersion++
    }
    fun addRec(name: String, rec: HubRec) = replaceRecs(name, listOf(rec) + recs(name))
    fun removeRec(name: String, id: Long) = replaceRecs(name, recs(name).filter { it.id != id })
    fun putRec(name: String, rec: HubRec) {
        val list = recs(name)
        replaceRecs(name, if (list.any { it.id == rec.id }) list.map { if (it.id == rec.id) rec else it } else listOf(rec) + list)
    }

    // ---- mistake notebook and bookmarks ----
    fun addMistake(q: HubContent.Mcq) {
        val id = q.q.hashCode().toLong()
        if (recs("mist").any { it.id == id }) return
        addRec("mist", HubRec(id, q.q, q.options.joinToString("\u001F"), q.explanation, q.source + "\u001F" + q.topic, q.answer, today()))
    }
    private fun bmId(text: String, sub: String): Long = (text + "|" + sub).hashCode().toLong()
    fun isBookmarked(text: String, sub: String): Boolean = recs("bm").any { it.id == bmId(text, sub) }
    fun toggleBookmark(text: String, sub: String, appId: String) {
        val id = bmId(text, sub)
        if (recs("bm").any { it.id == id }) removeRec("bm", id) else addRec("bm", HubRec(id, text, sub, appId, "", 0, today()))
    }

    // ---- points and level ----
    fun points(): Int = (totalMs() / 60_000L).toInt() + mockTests * 20 + pomodoros * 15 + sylDone.size * 5 + streak * 2 +
        recs("flash").count { it.n >= 4 } * 2 + recs("rev").sumOf { it.n } * 3

    // ---- home layout, language, reminder text, tips ----
    fun changeHomeOrder(list: List<String>) { homeOrder = list; p.edit().putString("homeOrder", list.joinToString(",")).apply() }
    fun toggleHomeHidden(id: String) {
        homeHidden = if (id in homeHidden) homeHidden - id else homeHidden + id
        p.edit().putStringSet("homeHidden", homeHidden.toSet()).apply()
    }
    fun changeHubUrdu(v: Boolean) { hubUrdu = v; p.edit().putBoolean("hubUrdu", v).apply() }
    fun changeReminderMsg(v: String) { reminderMsg = v.trim().take(80); p.edit().putString("reminderMsg", reminderMsg).apply() }
    fun markTip(id: String) { tipsSeen = tipsSeen + id; p.edit().putStringSet("tipsSeen", tipsSeen.toSet()).apply() }
    fun freezeAvailable(): Boolean = today() - p.getLong("freezeDay", -100L) >= 7

    // ---- saved (starred) questions ----
    fun isQuestionSaved(q: HubContent.Mcq): Boolean = recs("qbm").any { it.id == q.q.hashCode().toLong() }
    fun toggleQuestion(q: HubContent.Mcq) {
        val id = q.q.hashCode().toLong()
        if (recs("qbm").any { it.id == id }) removeRec("qbm", id)
        else addRec("qbm", HubRec(id, q.q, q.options.joinToString("\u001F"), q.explanation, q.source + "\u001F" + q.topic, q.answer, today()))
    }

    // ---- data export ----
    fun exportJson(): String {
        val o = JSONObject()
        for ((k, v) in p.all) {
            if (k == "pinHash" || k == "pinSalt") continue
            when (v) {
                is Set<*> -> o.put(k, JSONArray(v.map { it.toString() }))
                null -> {}
                else -> o.put(k, v)
            }
        }
        return o.toString(2)
    }
    fun exportCsv(): String {
        val sb = StringBuilder("date,minutes\n")
        activeDays().sorted().forEach { d -> sb.append(java.time.LocalDate.ofEpochDay(d)).append(',').append(dayMs(d) / 60_000L).append('\n') }
        return sb.toString()
    }

    // ---- app lock ----
    private fun hash(pin: String): String {
        val salt = p.getString("pinSalt", null) ?: java.util.UUID.randomUUID().toString().also { p.edit().putString("pinSalt", it).apply() }
        return MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
    }
    fun changePin(pin: String?) {
        if (pin == null) p.edit().remove("pinHash").apply() else p.edit().putString("pinHash", hash(pin)).apply()
        hasPin = pin != null
    }
    fun checkPin(pin: String): Boolean = hash(pin) == p.getString("pinHash", null)

    // ---- notes ----
    private fun loadNotes(): List<HubNote> = try {
        val a = JSONArray(p.getString("notes", "[]") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); HubNote(o.getLong("id"), o.optString("title"), o.optString("text")) }
    } catch (e: Exception) { emptyList() }

    private fun persistNotes(list: List<HubNote>) {
        notes = list
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("text", it.text)) }
        p.edit().putString("notes", a.toString()).apply()
    }

    fun saveNote(id: Long?, title: String, text: String) {
        if (title.isBlank() && text.isBlank()) return
        val list = if (id == null) listOf(HubNote(System.currentTimeMillis(), title.trim(), text.trim())) + notes
        else notes.map { if (it.id == id) HubNote(id, title.trim(), text.trim()) else it }
        persistNotes(list)
    }
    fun deleteNote(id: Long) = persistNotes(notes.filter { it.id != id })

    // ---- checklist ----
    private fun loadTasks(): List<HubTask> = try {
        val a = JSONArray(p.getString("tasks", "[]") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); HubTask(o.optString("text"), o.optBoolean("done")) }
    } catch (e: Exception) { emptyList() }

    private fun persistTasks(list: List<HubTask>) {
        tasks = list
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("text", it.text).put("done", it.done)) }
        p.edit().putString("tasks", a.toString()).apply()
    }
    fun addTask(text: String) { if (text.isNotBlank()) persistTasks(tasks + HubTask(text.trim(), false)) }
    fun toggleTask(index: Int) = persistTasks(tasks.mapIndexed { i, t -> if (i == index) HubTask(t.text, !t.done) else t })
    fun deleteTask(index: Int) = persistTasks(tasks.filterIndexed { i, _ -> i != index })
}
