package com.pmspreparation.app

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmscss.essay.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** The app logo (book + pen) on a round coloured badge. Same artwork as the launcher icon. */
@Composable
fun AppLogo(size: Dp, modifier: Modifier = Modifier) {
    val pal = LocalHubPalette.current
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(pal.p)
            .border(size / 40, pal.accent, CircleShape)
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), contentDescription = "PMS Preparation logo", modifier = Modifier.fillMaxSize())
    }
}

private fun heroBrush(pal: HubPalette) = Brush.verticalGradient(listOf(pal.p, pal.pDark))

/** 1. Animated splash: logo springs in, a ring pulses, title fades up. */
@Composable
fun HubSplash(onDone: () -> Unit) {
    val pal = LocalHubPalette.current
    var started by remember { mutableStateOf(false) }
    val logoScale by animateFloatAsState(
        if (started) 1f else 0.4f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow), label = "logoScale",
    )
    val textAlpha by animateFloatAsState(if (started) 1f else 0f, tween(900, delayMillis = 500), label = "textAlpha")
    val pulse = rememberInfiniteTransition(label = "pulse")
    val ring by pulse.animateFloat(
        1f, 1.18f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "ring",
    )
    LaunchedEffect(Unit) {
        started = true
        delay(2200)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(heroBrush(pal)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.Center) {
                Box(Modifier.size(190.dp).scale(ring).alpha(0.35f).border(3.dp, pal.accent, CircleShape))
                AppLogo(150.dp, Modifier.scale(logoScale))
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "PMS Preparation", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.alpha(textAlpha),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Your complete exam companion", color = pal.accentLight, fontSize = 14.sp,
                modifier = Modifier.alpha(textAlpha),
            )
        }
    }
}

/** 2-3. Welcome screen with the introduction note and the user's name. */
@Composable
fun HubWelcome(prefs: HubPrefs, onContinue: () -> Unit) {
    val pal = LocalHubPalette.current
    var name by rememberSaveable { mutableStateOf(prefs.name) }
    Box(Modifier.fillMaxSize().background(heroBrush(pal)).imePadding()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            AppLogo(110.dp)
            Spacer(Modifier.height(20.dp))
            Text("Welcome!", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text(
                "PMS Preparation brings your study apps together in one place: essays, English grammar, " +
                    "Pakistan Studies and more. Open any subject from one home page, and use most of it offline.",
                color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 22.sp,
            )
            Spacer(Modifier.height(28.dp))
            Text("What should we call you?", color = pal.accentLight, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(24) },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(14.dp),
                placeholder = { Text("Your name (optional)") },
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                    focusedTextColor = Color(0xFF1B1F1C), unfocusedTextColor = Color(0xFF1B1F1C),
                    focusedBorderColor = pal.accent, unfocusedBorderColor = Color.Transparent,
                    focusedPlaceholderColor = Color(0xFF6B756E), unfocusedPlaceholderColor = Color(0xFF6B756E),
                    cursorColor = pal.p,
                ),
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { prefs.updateName(name); onContinue() },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = pal.accent, contentColor = Color(0xFF1B1F1C)),
            ) { Text("Continue", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

private class OnboardPage(val icon: ImageVector, val title: String, val text: String)

private val ONBOARD_PAGES = listOf(
    OnboardPage(Icons.Filled.Dashboard, "All your subjects in one app", "Essays, English grammar, Pakistan Studies and more now live together, so you do not need to switch between apps."),
    OnboardPage(Icons.Filled.TouchApp, "Tap a card to start", "Each card opens the full original app with all its screens. Press Back on its main screen to return to this home page."),
    OnboardPage(Icons.Filled.Palette, "Make it yours", "Choose dark mode, a colour theme and your text size from Settings. Track your study streak and time on the home page."),
)

/** 4-7. Three-page onboarding with Skip, Next and Get Started. */
@Composable
fun HubOnboarding(onFinish: () -> Unit) {
    val pal = LocalHubPalette.current
    val dark = LocalHubDark.current
    val pager = rememberPagerState(pageCount = { ONBOARD_PAGES.size })
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == ONBOARD_PAGES.lastIndex
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onFinish) {
                Text("Skip", fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth()) { i ->
            val page = ONBOARD_PAGES[i]
            Column(
                Modifier.fillMaxSize().padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    Modifier.size(150.dp).clip(CircleShape).background(if (dark) pal.p else pal.container),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(page.icon, contentDescription = null, modifier = Modifier.size(76.dp), tint = if (dark) pal.accent else pal.p)
                }
                Spacer(Modifier.height(32.dp))
                Text(
                    page.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    page.text, fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 22.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(ONBOARD_PAGES.size) { i ->
                    val sel = i == pager.currentPage
                    Box(
                        Modifier.height(8.dp).width(if (sel) 24.dp else 8.dp).clip(CircleShape)
                            .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    )
                }
            }
            Button(
                onClick = {
                    if (last) onFinish() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                },
                shape = RoundedCornerShape(14.dp),
            ) { Text(if (last) "Get Started" else "Next", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

private val GUIDE_STEPS = listOf(
    "Search bar" to "Type a subject name at the top to find an app quickly.",
    "Widgets" to "Continue takes you back to your last app. Track your study streak, start the study timer, and tap the quote card for another one.",
    "App cards" to "Tap a card to open that full app. Press Back on its main screen to return here.",
    "Settings" to "Tap the gear at the top right for dark mode, colour themes, text size and your name. You can replay this guide there too.",
)

/** 9. First-time user guide, shown once after onboarding (and from Settings on request). */
@Composable
fun HubGuideDialog(onDone: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    val last = step == GUIDE_STEPS.lastIndex
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text("${step + 1}/${GUIDE_STEPS.size}  ${GUIDE_STEPS[step].first}", fontWeight = FontWeight.Bold) },
        text = { Text(GUIDE_STEPS[step].second, lineHeight = 22.sp) },
        confirmButton = {
            TextButton(onClick = { if (last) onDone() else step++ }) { Text(if (last) "Got it" else "Next") }
        },
        dismissButton = { if (!last) TextButton(onClick = onDone) { Text("Skip") } },
    )
}
