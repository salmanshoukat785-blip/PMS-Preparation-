@file:OptIn(ExperimentalMaterial3Api::class)

package com.pmspreparation.app

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private fun openLink(ctx: Context, url: String) {
    val u = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not open the link", Toast.LENGTH_SHORT).show()
    }
}

// ------------------------------------------------------------------ Saved items (bookmarks with notes)
@Composable
fun BookmarksScreen(prefs: HubPrefs, onOpenId: (String) -> Unit, onBack: () -> Unit) {
    val list = prefs.recs("bm")
    var editing by remember { mutableStateOf<HubRec?>(null) }
    ToolScaffold("Saved items", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                "Save search results and syllabus topics with the bookmark icon. Add your own note to any saved item.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (list.isEmpty()) Text("Nothing saved yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            list.forEach { r ->
                SoftCard(Modifier.fillMaxWidth(), onClick = { onOpenId(r.c) }) {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(r.a, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            Text(r.b, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (r.d.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text("Note: ${r.d}", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        TextButton(onClick = { editing = r }) { Text(if (r.d.isBlank()) "Add note" else "Edit note", fontSize = 12.sp) }
                        IconButton(onClick = { prefs.removeRec("bm", r.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Remove") }
                    }
                }
            }
        }
    }
    val e = editing
    if (e != null) {
        var text by remember(e.id) { mutableStateOf(e.d) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Note") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 3) },
            confirmButton = {
                TextButton(onClick = { prefs.putRec("bm", HubRec(e.id, e.a, e.b, e.c, text.trim(), e.n, e.m)); editing = null }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } },
        )
    }
}

// ------------------------------------------------------------------ Past papers (your own list)
@Composable
fun PastPapersScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val list = prefs.recs("pp").sortedByDescending { it.n }
    var adding by remember { mutableStateOf(false) }
    ToolScaffold("Past papers", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add past paper") }
            Text(
                "No past papers are bundled with the app. Add each paper with its year, subject and a link (PPSC site, Drive, PDF link) or your own note, and open it from here.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            list.forEach { r ->
                SoftCard(Modifier.fillMaxWidth(), onClick = if (r.b.isNotBlank()) ({ openLink(ctx, r.b) }) else null) {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text("${if (r.n > 0) r.n else ""} ${r.a}".trim(), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            if (r.c.isNotBlank()) Text(r.c, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (r.d.isNotBlank()) Text(r.d, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            if (r.b.isNotBlank()) Text("Tap to open link", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { prefs.removeRec("pp", r.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }
    }
    if (adding) {
        var title by remember { mutableStateOf("") }
        var year by remember { mutableStateOf("") }
        var subject by remember { mutableStateOf("") }
        var link by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("Add past paper") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(
                        value = year, onValueChange = { year = it.filter { c -> c.isDigit() }.take(4) }, label = { Text("Year") }, singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                    )
                    OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Subject or paper") }, singleLine = true)
                    OutlinedTextField(value = link, onValueChange = { link = it }, label = { Text("Link (optional)") }, singleLine = true)
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note (optional)") }, minLines = 2)
                }
            },
            confirmButton = {
                TextButton(enabled = title.isNotBlank(), onClick = {
                    prefs.addRec("pp", HubRec(System.currentTimeMillis(), title.trim(), link.trim(), subject.trim(), note.trim(), year.toIntOrNull() ?: 0))
                    adding = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } },
        )
    }
}

// ------------------------------------------------------------------ Current affairs diary
private val CA_CATEGORIES = listOf("National", "International", "Economy", "Science", "Sports", "Other")

@Composable
fun CurrentAffairsScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val all = prefs.recs("ca")
    var filter by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    val list = all.filter { filter.isEmpty() || it.c == filter }.sortedByDescending { it.m }
    ToolScaffold("Current affairs", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add news item") }
            Text(
                "Your own daily diary of current affairs. Write each item once and revise it here before the exam.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(selected = filter.isEmpty(), onClick = { filter = "" }, label = { Text("All") }) }
                items(CA_CATEGORIES.size) { i ->
                    val c = CA_CATEGORIES[i]
                    FilterChip(selected = filter == c, onClick = { filter = c }, label = { Text(c, fontSize = 12.sp) })
                }
            }
            if (list.isEmpty()) Text("No items yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            list.forEach { r ->
                SoftCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(r.a, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                            if (r.b.isNotBlank()) Text(r.b, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text("${r.c}  ·  ${xDayText(r.m)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { prefs.removeRec("ca", r.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }
    }
    if (adding) {
        var head by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        var cat by remember { mutableStateOf(CA_CATEGORIES[0]) }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("New item") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = head, onValueChange = { head = it }, label = { Text("Headline") })
                    OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Details (optional)") }, minLines = 3)
                    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(CA_CATEGORIES.size) { i ->
                            val c = CA_CATEGORIES[i]
                            FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c, fontSize = 12.sp) })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = head.isNotBlank(), onClick = {
                    prefs.addRec("ca", HubRec(System.currentTimeMillis(), head.trim(), body.trim(), cat, "", 0, prefs.today()))
                    adding = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } },
        )
    }
}

// ------------------------------------------------------------------ Essay practice
@Composable
fun EssayScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val titles by produceState<List<String>>(emptyList()) { value = withContext(Dispatchers.IO) { HubContent.essayTitles(ctx) } }
    var title by remember { mutableStateOf("") }
    var minutes by remember { mutableIntStateOf(40) }
    var text by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var left by remember { mutableIntStateOf(0) }
    var finishedWords by remember { mutableIntStateOf(-1) }
    var usedSec by remember { mutableIntStateOf(0) }

    LaunchedEffect(running) {
        if (running) {
            while (left > 0 && running) { delay(1000); left -= 1 }
            if (running) { running = false; finishedWords = text.trim().split(Regex("\\s+")).count { it.isNotEmpty() } }
        }
    }
    val words = text.trim().split(Regex("\\s+")).count { it.isNotEmpty() }

    ToolScaffold("Essay practice", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            when {
                running -> {
                    Text(
                        "Time left: %d:%02d   ·   %d words".format(left / 60, left % 60, words), fontWeight = FontWeight.Bold,
                        color = if (left < 300) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    )
                    Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                    OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 14)
                    Button(onClick = {
                        usedSec = minutes * 60 - left
                        running = false
                        finishedWords = words
                    }, modifier = Modifier.fillMaxWidth()) { Text("Finish and save") }
                }
                finishedWords >= 0 -> {
                    LaunchedEffect(finishedWords) {
                        prefs.saveNote(null, "Essay: ${title.ifBlank { "Practice" }}", text)
                        prefs.addTime(null, (if (usedSec > 0) usedSec else minutes * 60) * 1000L)
                    }
                    Text("Essay saved to My notes", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Text("$finishedWords words", fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                    Text(
                        if (finishedWords < 600) "Tip: PMS essays usually need a fuller answer. Aim for a clear outline, then 800 or more words."
                        else "Good length. Now check structure, introduction and conclusion.",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(onClick = { finishedWords = -1; text = ""; title = "" }, modifier = Modifier.fillMaxWidth()) { Text("New essay") }
                }
                else -> {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Essay title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(
                        onClick = { if (titles.isNotEmpty()) title = titles.random() },
                        enabled = titles.isNotEmpty(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Pick a random title from the Essay app") }
                    Text("Time", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(20, 40, 60, 90).forEach { m -> FilterChip(selected = minutes == m, onClick = { minutes = m }, label = { Text("$m min") }) }
                    }
                    Button(
                        onClick = { left = minutes * 60; text = ""; running = true },
                        enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Start writing") }
                    Text("The timer runs while you write. When it ends, your essay is saved in My notes.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Focus mode
@Composable
fun FocusScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    var startedAt by remember { mutableLongStateOf(0L) }
    var elapsed by remember { mutableLongStateOf(0L) }
    DisposableEffect(startedAt) {
        view.keepScreenOn = startedAt > 0L
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(startedAt) {
        while (startedAt > 0L) { elapsed = System.currentTimeMillis() - startedAt; delay(1000) }
    }
    ToolScaffold("Focus mode", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val sec = (elapsed / 1000L).toInt()
            Text("%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60), fontSize = 48.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            if (startedAt == 0L) {
                Button(onClick = { startedAt = System.currentTimeMillis(); elapsed = 0L }, modifier = Modifier.fillMaxWidth()) { Text("Start focus session") }
            } else {
                Button(onClick = {
                    prefs.addTime(null, (System.currentTimeMillis() - startedAt).coerceAtMost(4 * 3_600_000L))
                    startedAt = 0L
                    elapsed = 0L
                }, modifier = Modifier.fillMaxWidth()) { Text("Stop and save") }
            }
            Text(
                "While a session runs, the screen stays on. Android does not let an app switch on Do Not Disturb by itself, so turn it on yourself for fewer interruptions.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(onClick = {
                try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                catch (e: Exception) { Toast.makeText(ctx, "Open Do Not Disturb from your phone settings", Toast.LENGTH_SHORT).show() }
            }, modifier = Modifier.fillMaxWidth()) { Text("Open Do Not Disturb settings") }
        }
    }
}

// ------------------------------------------------------------------ PDF export
object HubExport {
    /** Writes a simple multi-page A4 PDF. Lines starting with "# " are drawn as headings. */
    fun buildPdf(ctx: Context, name: String, lines: List<String>): File {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, name)
        val doc = PdfDocument()
        val body = Paint().apply { textSize = 11f; isAntiAlias = true }
        val head = Paint().apply { textSize = 15f; isFakeBoldText = true; isAntiAlias = true }
        val width = 595f - 80f
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
        var y = 50f
        fun newPage() {
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
            y = 50f
        }
        for (raw in lines) {
            val heading = raw.startsWith("# ")
            val text = if (heading) raw.removePrefix("# ") else raw
            val paint = if (heading) head else body
            val step = if (heading) 22f else 15f
            if (heading) y += 8f
            var rest = text
            if (rest.isEmpty()) { y += step; if (y > 790f) newPage(); continue }
            while (rest.isNotEmpty()) {
                var n = paint.breakText(rest, true, width, null)
                if (n <= 0) n = 1
                if (n < rest.length) {
                    val sp = rest.lastIndexOf(' ', n - 1)
                    if (sp > 0) n = sp + 1
                }
                if (y > 790f) newPage()
                page.canvas.drawText(rest.substring(0, n).trimEnd(), 40f, y, paint)
                y += step
                rest = rest.substring(n)
            }
        }
        doc.finishPage(page)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun share(ctx: Context, file: File) {
        val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Save or share PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@Composable
fun ExportScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    fun makePdf(fileName: String, build: () -> List<String>) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                val file = withContext(Dispatchers.IO) { HubExport.buildPdf(ctx, fileName, build()) }
                HubExport.share(ctx, file)
            } catch (e: Exception) {
                Toast.makeText(ctx, "Could not create the PDF", Toast.LENGTH_SHORT).show()
            }
            busy = false
        }
    }

    ToolScaffold("Export to PDF", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Create a PDF and save it or send it with any app (for example Drive or WhatsApp).", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = {
                makePdf("My-notes.pdf") {
                    val out = ArrayList<String>()
                    out.add("# My notes")
                    prefs.notes.forEach { n ->
                        out.add("")
                        if (n.title.isNotBlank()) out.add("# ${n.title}")
                        n.text.split("\n").forEach { out.add(it) }
                    }
                    out
                }
            }, enabled = !busy && prefs.notes.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("My notes (${prefs.notes.size})") }
            OutlinedButton(onClick = {
                makePdf("Syllabus-progress.pdf") {
                    val out = ArrayList<String>()
                    out.add("# Syllabus progress")
                    HubSyllabus.load(ctx.applicationContext).forEach { g ->
                        g.papers.forEach { p ->
                            out.add("")
                            out.add("# Paper ${p.no}: ${p.title}")
                            out.add(p.meta)
                            p.sections.forEachIndexed { s, sec ->
                                out.add("")
                                out.add(sec.heading)
                                sec.items.forEachIndexed { i, item ->
                                    val mark = if (doneKey(g, p, s, i) in prefs.sylDone) "[x]" else "[  ]"
                                    out.add("  $mark ${i + 1}. $item")
                                }
                            }
                        }
                    }
                    out
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Syllabus with my progress") }
            OutlinedButton(onClick = {
                makePdf("Current-affairs.pdf") {
                    val out = ArrayList<String>()
                    out.add("# Current affairs")
                    prefs.recs("ca").sortedByDescending { it.m }.forEach { r ->
                        out.add("")
                        out.add("${xDayText(r.m)}  ·  ${r.c}")
                        out.add(r.a)
                        if (r.b.isNotBlank()) out.add(r.b)
                    }
                    out
                }
            }, enabled = !busy && prefs.recs("ca").isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Current affairs (${prefs.recs("ca").size})") }
            OutlinedButton(onClick = {
                makePdf("Mistake-notebook.pdf") {
                    val out = ArrayList<String>()
                    out.add("# Mistake notebook")
                    prefs.recs("mist").forEach { r ->
                        out.add("")
                        out.add(r.a)
                        out.add("Answer: " + (r.b.split("\u001F").getOrNull(r.n) ?: ""))
                        if (r.c.isNotBlank()) out.add(r.c)
                    }
                    out
                }
            }, enabled = !busy && prefs.recs("mist").isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Mistake notebook (${prefs.recs("mist").size})") }
            OutlinedButton(onClick = {
                makePdf("Saved-items.pdf") {
                    val out = ArrayList<String>()
                    out.add("# Saved items")
                    prefs.recs("bm").forEach { r ->
                        out.add("")
                        out.add(r.a)
                        out.add(r.b)
                        if (r.d.isNotBlank()) out.add("Note: ${r.d}")
                    }
                    out
                }
            }, enabled = !busy && prefs.recs("bm").isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Saved items (${prefs.recs("bm").size})") }
            if (busy) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Text("Creating PDF...", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
