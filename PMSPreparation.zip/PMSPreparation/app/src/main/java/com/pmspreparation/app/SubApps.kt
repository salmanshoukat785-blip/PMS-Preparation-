package com.pmspreparation.app

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Spellcheck
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.completeenglishgrammar.app.GrammarApp
import com.islamicstudies.academy.ui.IslamicStudiesApp
import com.pakstudies2.app.PakStudies2App
import com.pmscss.essay.EssayApp
import com.pmsnotes.economy.EconomyApp
import com.pmsprep.app.IntlAffairsApp
import com.pmsnotes.pakstudies.PakStudiesApp
import com.socialwork.academy.ui.AcademyApp

/** How a sub-app wants the system bars (each original app was built for a different style). */
enum class BarStyle {
    /** The system draws the status bar in [SubApp.statusBar] (PMS/CSS Essay and the home page). */
    SYSTEM,
    /** The app draws edge-to-edge and handles insets itself (Complete English Grammar). */
    EDGE_TO_EDGE,
}

/**
 * One entry per merged app. To add the next app: copy its package into this module,
 * give it a `XxxApp(onExit)` composable (its old MainActivity content) and add one line here.
 */
class SubApp(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val icon: ImageVector,
    val accent: Color,
    val barStyle: BarStyle,
    val statusBar: Color = Color(0xFF0B5D3B),
    val navBar: Color = Color.Black,
    val lightNavIcons: Boolean = false,
    val content: @Composable (onExit: () -> Unit) -> Unit,
)

val SUB_APPS: List<SubApp> = listOf(
    SubApp(
        id = "grammar",
        title = "Complete English Grammar",
        subtitle = "Lessons, vocabulary, quizzes",
        category = "English",
        icon = Icons.Filled.Spellcheck,
        accent = Color(0xFF3F51B5),
        barStyle = BarStyle.EDGE_TO_EDGE,
        content = { onExit -> GrammarApp(onExit) },
    ),
    SubApp(
        id = "essay",
        title = "PMS/CSS Essay",
        subtitle = "125 essay outlines, vocabulary",
        category = "Essay",
        icon = Icons.Filled.HistoryEdu,
        accent = Color(0xFF0B5D3B),
        barStyle = BarStyle.SYSTEM,
        content = { onExit -> EssayApp(onExit) },
    ),
    SubApp(
        id = "pakstudies",
        title = "Pak-Studies 1",
        subtitle = "105 topics, MCQs, timeline",
        category = "Pakistan Studies",
        icon = Icons.Filled.Public,
        accent = Color(0xFF01411C),
        barStyle = BarStyle.SYSTEM,
        statusBar = Color(0xFF012A12),
        navBar = Color.White,
        lightNavIcons = true,
        content = { onExit -> PakStudiesApp(onExit) },
    ),
    SubApp(
        id = "socialwork",
        title = "Social Work Academy",
        subtitle = "Papers, MCQs, flashcards, glossary",
        category = "Social Work",
        icon = Icons.Filled.Groups,
        accent = Color(0xFF7B3FC4),
        barStyle = BarStyle.EDGE_TO_EDGE,
        content = { onExit -> AcademyApp(onExit = onExit) },
    ),
    SubApp(
        id = "pakstudies2",
        title = "Pak-Studies II",
        subtitle = "Topics, MCQs, timeline, Urdu",
        category = "Pakistan Studies",
        icon = Icons.Filled.Flag,
        accent = Color(0xFF0B5D3B),
        barStyle = BarStyle.SYSTEM,
        statusBar = Color(0xFF08452B),
        content = { onExit -> PakStudies2App(onExit) },
    ),
    SubApp(
        id = "economy",
        title = "Economy and Development",
        subtitle = "Notes, course outline, mock test",
        category = "Economy",
        icon = Icons.Filled.TrendingUp,
        accent = Color(0xFF1F3A5F),
        barStyle = BarStyle.SYSTEM,
        statusBar = Color(0xFF1F3A5F),
        content = { onExit -> EconomyApp(onExit) },
    ),
    SubApp(
        id = "intlaffairs",
        title = "International Affairs",
        subtitle = "Topics, MCQs, revision, timelines",
        category = "International Affairs",
        icon = Icons.Filled.Language,
        accent = Color(0xFF1F3A5F),
        barStyle = BarStyle.SYSTEM,
        statusBar = Color(0xFF1F3A5F),
        navBar = Color(0xFF1F3A5F),
        content = { onExit -> IntlAffairsApp(onExit) },
    ),
    SubApp(
        id = "islamic",
        title = "Islamic Studies Academy",
        subtitle = "26 chapters, quiz, notes, glossary",
        category = "Islamic Studies",
        icon = Icons.Filled.AutoStories,
        accent = Color(0xFF07503F),
        barStyle = BarStyle.SYSTEM,
        statusBar = Color(0xFF07503F),
        navBar = Color(0xFFF7F2E3),
        lightNavIcons = true,
        content = { onExit -> IslamicStudiesApp(onExit) },
    ),
)
