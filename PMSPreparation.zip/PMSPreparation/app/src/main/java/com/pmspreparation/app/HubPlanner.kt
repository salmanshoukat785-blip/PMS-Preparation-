@file:OptIn(ExperimentalMaterial3Api::class)

package com.pmspreparation.app

import android.app.TimePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

internal fun xDayText(day: Long): String {
    val f = SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault())
    f.timeZone = TimeZone.getTimeZone("UTC")
    return f.format(Date(day * 86_400_000L))
}

internal fun xHm(min: Int): String = "%02d:%02d".format((min / 60) % 24, min % 60)

internal fun xParseHm(s: String): Int? {
    val parts = s.split(":")
    if (parts.size != 2) return null
    val h = parts[0].toIntOrNull() ?: return null
    val m = parts[1].toIntOrNull() ?: return null
    return h * 60 + m
}

internal fun xDuration(min: Int): String = if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"

// ------------------------------------------------------------------ Study planner
@Composable
fun PlannerScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val groups by produceState<List<SylGroup>>(emptyList()) { value = withContext(Dispatchers.IO) { HubSyllabus.load(ctx) } }
    val version = prefs.logVersion
    val today = prefs.today()
    val papers = groups.flatMap { g -> g.papers.map { p -> g to p } }
    val total = papers.sumOf { it.second.topicCount }
    val done = papers.sumOf { doneCount(prefs, it.first, it.second) }
    val remainingTotal = total - done
    val daysLeft = if (prefs.examDay >= 0) (prefs.examDay - today).toInt() else -1
    val weeks = remember(version, today) {
        (0..3).map { w ->
            val end = today - w * 7L
            var sum = 0L
            for (i in 0..6) sum += prefs.dayMs(end - i)
            sum
        }
    }
    val weekTargetMin = prefs.dailyGoal * 7

    ToolScaffold("Study planner", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SoftCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Syllabus coverage", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    val pct = if (total == 0) 0 else done * 100 / total
                    Text("$pct%", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth())
                    Text("$done of $total topics done", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            SoftCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Your plan", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    if (daysLeft < 0) {
                        Text("Set your exam date in Settings to get a day-by-day plan.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else if (daysLeft == 0) {
                        Text("Your exam is today. Good luck!", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                    } else {
                        val weeksLeft = ((daysLeft + 6) / 7).coerceAtLeast(1)
                        Text("$daysLeft days left (about $weeksLeft weeks).", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                        if (remainingTotal > 0) {
                            val perDay = (remainingTotal + daysLeft - 1) / daysLeft
                            Text("$remainingTotal topics remaining, so about $perDay topics a day.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            val open = papers.filter { it.second.topicCount - doneCount(prefs, it.first, it.second) > 0 }
                            if (open.isNotEmpty()) {
                                val focus = open[(today % open.size).toInt()].second
                                Text(
                                    "Today's focus: Paper ${focus.no} - ${focus.title}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                        } else if (total > 0) {
                            Text("All topics are done. Use the Revision list to keep them fresh.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }

            if (papers.isNotEmpty()) {
                Text("Paper by paper", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                val weeksLeft = if (daysLeft > 0) ((daysLeft + 6) / 7).coerceAtLeast(1) else 0
                papers.forEach { (g, p) ->
                    val d = doneCount(prefs, g, p)
                    val rem = p.topicCount - d
                    SoftCard(Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Paper ${p.no}: ${p.title}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                            LinearProgressIndicator(progress = { if (p.topicCount == 0) 0f else d.toFloat() / p.topicCount }, modifier = Modifier.fillMaxWidth())
                            val extra = if (weeksLeft > 0 && rem > 0) "  ·  about ${(rem + weeksLeft - 1) / weeksLeft} topics a week" else ""
                            Text("$d of ${p.topicCount} done$extra", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            SoftCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Weekly target vs achieved", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text("Target: ${xDuration(weekTargetMin)} a week (your daily goal x 7)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    weeks.forEachIndexed { i, ms ->
                        val min = (ms / 60_000L).toInt()
                        Text(
                            if (i == 0) "Last 7 days: ${xDuration(min)}" else "$i week${if (i > 1) "s" else ""} earlier: ${xDuration(min)}",
                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface,
                        )
                        LinearProgressIndicator(
                            progress = { if (weekTargetMin == 0) 0f else (min.toFloat() / weekTargetMin).coerceAtMost(1f) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Timetable
@Composable
fun TimetableScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val slots = prefs.recs("tt").sortedBy { xParseHm(it.a) ?: 0 }
    var adding by remember { mutableStateOf(false) }
    val now = Calendar.getInstance().let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) }

    ToolScaffold("Timetable", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add study slot") }
            if (slots.isEmpty()) {
                Text(
                    "Plan your day: add slots such as 06:00 Pak-Studies for 90 minutes.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            slots.forEach { s ->
                val start = xParseHm(s.a) ?: 0
                val current = now >= start && now < start + s.n
                SoftCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "${xHm(start)} - ${xHm(start + s.n)}${if (current) "   (now)" else ""}", fontWeight = FontWeight.Bold,
                                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            )
                            Text(s.b, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(xDuration(s.n), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { prefs.removeRec("tt", s.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }
    }

    if (adding) {
        var time by remember { mutableIntStateOf(9 * 60) }
        var subject by remember { mutableStateOf("") }
        var dur by remember { mutableIntStateOf(60) }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("New study slot") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        TimePickerDialog(ctx, { _, h, m -> time = h * 60 + m }, time / 60, time % 60, true).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Start time: ${xHm(time)}") }
                    OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Subject or paper") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(30, 45, 60, 90, 120).forEach { d ->
                            FilterChip(selected = dur == d, onClick = { dur = d }, label = { Text("$d", fontSize = 12.sp) })
                        }
                    }
                    Text("Length in minutes", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                TextButton(enabled = subject.isNotBlank(), onClick = {
                    prefs.addRec("tt", HubRec(System.currentTimeMillis(), xHm(time), subject.trim(), n = dur))
                    adding = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } },
        )
    }
}

// ------------------------------------------------------------------ Prayer-time study blocks
private val PRAYERS = listOf("Fajr", "Zuhr", "Asr", "Maghrib", "Isha")

@Composable
fun PrayerBlocksScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val saved = prefs.recs("prayer")
    val times = PRAYERS.mapIndexed { i, name -> name to saved.firstOrNull { it.id == i.toLong() }?.let { xParseHm(it.a) } }

    ToolScaffold("Prayer-time study blocks", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                "Enter today's prayer times from your local timetable (they change through the year). The app then shows the free gaps for study.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            times.forEachIndexed { i, (name, t) ->
                SoftCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                        OutlinedButton(onClick = {
                            val start = t ?: 12 * 60
                            TimePickerDialog(ctx, { _, h, m -> prefs.putRec("prayer", HubRec(i.toLong(), xHm(h * 60 + m))) }, start / 60, start % 60, true).show()
                        }) { Text(if (t == null) "Set time" else xHm(t)) }
                    }
                }
            }
            val set = times.mapNotNull { it.second }
            if (set.size == 5) {
                Text("Suggested study blocks", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                val sorted = times.sortedBy { it.second ?: 0 }
                var shown = 0
                sorted.forEachIndexed { i, (name, t) ->
                    val start = (t ?: 0) + 25                          // 25 minutes after the prayer starts
                    val next = if (i + 1 < sorted.size) (sorted[i + 1].second ?: 0) - 10 else 22 * 60 + 30
                    val len = next - start
                    if (len >= 45) {
                        shown++
                        SoftCard(Modifier.fillMaxWidth()) {
                            Column {
                                Text("${xHm(start)} - ${xHm(next)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("After $name  ·  ${xDuration(len)}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
                if (shown == 0) Text("No gap of 45 minutes or more was found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text("Blocks start 25 minutes after a prayer and end 10 minutes before the next one.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ------------------------------------------------------------------ Level and points
@Composable
fun LevelScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val version = prefs.logVersion
    val pts = remember(version, prefs.sylDone.size, prefs.mockTests, prefs.pomodoros, prefs.recVersion, prefs.streak) { prefs.points() }
    val idx = HUB_LEVELS.indexOfLast { pts >= it.first }.coerceAtLeast(0)
    val cur = HUB_LEVELS[idx]
    val next = HUB_LEVELS.getOrNull(idx + 1)
    ToolScaffold("Level and points", onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SoftCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Level ${idx + 1}: ${cur.second}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("$pts points", fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                    if (next != null) {
                        LinearProgressIndicator(
                            progress = { ((pts - cur.first).toFloat() / (next.first - cur.first)).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Text("${next.first - pts} more points for ${next.second}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("Top level reached!", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            SoftCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("How points are earned", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    listOf(
                        "1 point for every minute of study",
                        "20 points for each mixed or timed test finished",
                        "15 points for each pomodoro",
                        "5 points for each syllabus topic ticked",
                        "3 points for each revision completed",
                        "2 points for each flashcard word mastered",
                        "2 points for every day of streak",
                    ).forEach { Text("•  $it", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface) }
                }
            }
        }
    }
}
