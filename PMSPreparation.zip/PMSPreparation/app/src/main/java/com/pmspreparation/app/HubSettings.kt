package com.pmspreparation.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Settings for the joint home page: name, dark mode, colour theme, text size, tour/guide. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HubSettings(prefs: HubPrefs, onBack: () -> Unit, onReplayTour: () -> Unit, onShowGuide: () -> Unit) {
    val header = hubHeaderColor(LocalHubPalette.current, LocalHubDark.current)
    var name by remember { mutableStateOf(prefs.name) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(
            Modifier.fillMaxWidth().background(header).padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("Settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsCard("Your name") {
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(24); prefs.setName(it) },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Shown in the greeting") },
                )
            }

            SettingsCard("Dark mode") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                        FilterChip(selected = prefs.themeMode == i, onClick = { prefs.changeThemeMode(i) }, label = { Text(label) })
                    }
                }
            }

            SettingsCard("Colour theme") {
                Text("Recommended colour combinations", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                HUB_PALETTES.forEachIndexed { i, pal ->
                    val selected = prefs.palette == i
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { prefs.changePalette(i) }
                            .background(if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else Color.Transparent)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Swatch(pal.p); Swatch(pal.accent); Swatch(pal.container)
                        Spacer(Modifier.size(12.dp))
                        Text(pal.name, Modifier.weight(1f), fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                        if (selected) Icon(Icons.Filled.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            SettingsCard("Text size") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FONT_LABELS.forEachIndexed { i, label ->
                        FilterChip(selected = prefs.fontStep == i, onClick = { prefs.changeFontStep(i) }, label = { Text(label, fontSize = 12.sp) })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Sample: Unity, Faith, Discipline.", color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Applies to this home page. Each merged app keeps its own text-size setting inside its Settings.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SettingsCard("Help") {
                OutlinedButton(onClick = onShowGuide, modifier = Modifier.fillMaxWidth()) { Text("Show app guide") }
                OutlinedButton(onClick = onReplayTour, modifier = Modifier.fillMaxWidth()) { Text("Replay welcome tour") }
            }
        }
    }
}

@Composable
private fun Swatch(color: Color) {
    Box(Modifier.padding(end = 6.dp).size(26.dp).clip(CircleShape).background(color))
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            content()
        }
    }
}
