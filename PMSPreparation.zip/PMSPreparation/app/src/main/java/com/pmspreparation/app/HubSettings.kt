package com.pmspreparation.app

import android.Manifest
import android.app.DatePickerDialog
import android.os.Build
import android.os.Process
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

/** Settings for the joint home page: name, dark mode, colour theme, text size, tour/guide. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HubSettings(prefs: HubPrefs, onBack: () -> Unit, onReplayTour: () -> Unit, onShowGuide: () -> Unit) {
    val header = hubHeaderColor(LocalHubPalette.current, LocalHubDark.current)
    var name by remember { mutableStateOf(prefs.name) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pinDialog by remember { mutableStateOf(false) }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Toast.makeText(ctx, "Notifications are blocked in Android settings, so the reminder cannot show.", Toast.LENGTH_LONG).show()
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try { ctx.contentResolver.openOutputStream(uri)?.use { HubBackup.export(ctx, it) }; true } catch (e: Exception) { false }
            }
            Toast.makeText(ctx, if (ok) "Backup saved" else "Backup failed", Toast.LENGTH_LONG).show()
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val n = withContext(Dispatchers.IO) {
                try { ctx.contentResolver.openInputStream(uri)?.use { HubBackup.restore(ctx, it) } ?: 0 } catch (e: Exception) { 0 }
            }
            if (n > 0) {
                Toast.makeText(ctx, "Backup restored. The app will close; open it again.", Toast.LENGTH_LONG).show()
                delay(1500)
                Process.killProcess(Process.myPid())
            } else {
                Toast.makeText(ctx, "This file is not a valid backup", Toast.LENGTH_LONG).show()
            }
        }
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(
            Modifier.fillMaxWidth().background(header).padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("Settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsCard("Your name") {
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(24); prefs.updateName(it) },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Shown in the greeting") },
                )
            }

            SettingsCard("Dark mode") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                        FilterChip(selected = prefs.themeMode == i, onClick = { prefs.changeThemeMode(i) }, label = { Text(label) })
                    }
                }
            }

            SettingsCard("Colour theme") {
                Text("Recommended colour combinations", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                HUB_PALETTES.forEachIndexed { i, pal ->
                    val selected = prefs.palette == i
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { prefs.changePalette(i) }
                            .background(if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else Color.Transparent)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Swatch(pal.p); Swatch(pal.accent); Swatch(pal.container)
                        Spacer(Modifier.size(12.dp))
                        Text(pal.name, Modifier.weight(1f), fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                        if (selected) Icon(Icons.Filled.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            SettingsCard("Text size") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FONT_LABELS.forEachIndexed { i, label ->
                        FilterChip(selected = prefs.fontStep == i, onClick = { prefs.changeFontStep(i) }, label = { Text(label, fontSize = 12.sp) })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Sample: Unity, Faith, Discipline.", color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Applies to this home page. Each merged app keeps its own text-size setting inside its Settings.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SettingsCard("Study goal") {
                Text("Minutes per day", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(30, 60, 90, 120, 180).forEach { m ->
                        FilterChip(selected = prefs.dailyGoal == m, onClick = { prefs.changeDailyGoal(m) }, label = { Text("$m") })
                    }
                }
            }

            SettingsCard("Exam date") {
                val label = if (prefs.examDay < 0) "Not set" else {
                    val c = Calendar.getInstance()
                    c.timeInMillis = c.timeInMillis + (prefs.examDay - prefs.today()) * 86_400_000L
                    "${c.get(Calendar.DAY_OF_MONTH)}-${c.get(Calendar.MONTH) + 1}-${c.get(Calendar.YEAR)}"
                }
                Text(label, color = MaterialTheme.colorScheme.onSurface)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val now = Calendar.getInstance()
                        DatePickerDialog(ctx, { _, y, m, d ->
                            val c = Calendar.getInstance(); c.set(y, m, d, 12, 0, 0)
                            prefs.changeExamDay(epochDayOf(c))
                        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Text("Choose date") }
                    if (prefs.examDay >= 0) OutlinedButton(onClick = { prefs.changeExamDay(-1L) }) { Text("Clear") }
                }
            }

            SettingsCard("Daily reminder") {
                Text("A notification at this time every day", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(-1 to "Off", 6 to "6 AM", 8 to "8 AM", 18 to "6 PM", 21 to "9 PM").forEach { (h, label) ->
                        FilterChip(
                            selected = prefs.reminderHour == h,
                            onClick = {
                                prefs.changeReminder(h)
                                if (h >= 0 && Build.VERSION.SDK_INT >= 33 && !HubReminder.notificationsAllowed(ctx)) {
                                    notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            },
                            label = { Text(label, fontSize = 12.sp) },
                        )
                    }
                }
            }

            SettingsCard("App lock") {
                Text(
                    if (prefs.hasPin) "A 4-digit PIN is asked every time the app opens." else "Protect your notes and progress with a 4-digit PIN.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pinDialog = true }) { Text(if (prefs.hasPin) "Change PIN" else "Set PIN") }
                    if (prefs.hasPin) OutlinedButton(onClick = { prefs.changePin(null) }) { Text("Remove PIN") }
                }
            }

            SettingsCard("Backup and restore") {
                Text(
                    "Saves the progress and settings of the home page and all merged apps in one file. Keep it in a safe place (for example Google Drive) before changing phones.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton(onClick = { exportLauncher.launch("PMS-Preparation-backup.zip") }, modifier = Modifier.fillMaxWidth()) { Text("Save backup file") }
                OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Restore from backup file") }
            }

            SettingsCard("Help") {
                OutlinedButton(onClick = onShowGuide, modifier = Modifier.fillMaxWidth()) { Text("Show app guide") }
                OutlinedButton(onClick = onReplayTour, modifier = Modifier.fillMaxWidth()) { Text("Replay welcome tour") }
            }
        }
    }

    if (pinDialog) {
        var a by remember { mutableStateOf("") }
        var b by remember { mutableStateOf("") }
        val valid = a.length == 4 && a == b
        AlertDialog(
            onDismissRequest = { pinDialog = false },
            title = { Text("Set a 4-digit PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = a, onValueChange = { a = it.filter { ch -> ch.isDigit() }.take(4) }, singleLine = true,
                        label = { Text("New PIN") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    )
                    OutlinedTextField(
                        value = b, onValueChange = { b = it.filter { ch -> ch.isDigit() }.take(4) }, singleLine = true,
                        label = { Text("Repeat PIN") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    )
                    Text("If you forget it, you must clear the app's data in Android settings.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(enabled = valid, onClick = { prefs.changePin(a); pinDialog = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { pinDialog = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Swatch(color: Color) {
    Box(Modifier.padding(end = 6.dp).size(26.dp).clip(CircleShape).background(color))
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            content()
        }
    }
}
