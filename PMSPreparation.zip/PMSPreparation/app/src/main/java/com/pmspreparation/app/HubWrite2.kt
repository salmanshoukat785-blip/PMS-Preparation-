@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.pmspreparation.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

private fun words(s: String) = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
private fun wc(s: String) = words(s).size

private fun asset(ctx: Context, path: String): String? = try {
    ctx.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
} catch (e: Exception) { null }

/** Small "Copy" and "Save to notes" row used under generated text. */
@Composable
private fun TextActions(prefs: HubPrefs, title: String, text: String) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { clip.setText(AnnotatedString(text)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show() }) { Text("Copy") }
        OutlinedButton(onClick = { prefs.saveNote(null, title, text); Toast.makeText(ctx, "Saved in My notes", Toast.LENGTH_SHORT).show() }) { Text("Save to notes") }
    }
}

@Composable
private fun Heading(text: String) {
    Text(text, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
}

@Composable
private fun Hint(text: String) {
    Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

// ------------------------------------------------------------------ 11. Essay planner
@Composable
fun EssayPlannerScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val titles by produceState<List<String>>(emptyList()) { value = withContext(Dispatchers.IO) { HubContent.essayTitles(ctx) } }
    var title by remember { mutableStateOf("") }
    var thesis by remember { mutableStateOf("") }
    var intro by remember { mutableStateOf("") }
    val points = remember { mutableStateOf(listOf("", "", "")) }
    val evidence = remember { mutableStateOf(listOf("", "", "")) }
    val examples = remember { mutableStateOf(listOf("", "", "")) }
    var counter by remember { mutableStateOf("") }
    var conclusion by remember { mutableStateOf("") }
    val plan = buildString {
        append("Title: $title\nThesis: $thesis\nIntroduction: $intro\n")
        for (i in 0..2) append("\nBody ${i + 1}\n  Point: ${points.value[i]}\n  Evidence: ${evidence.value[i]}\n  Example: ${examples.value[i]}\n")
        append("\nCounter-argument and reply: $counter\nConclusion: $conclusion\n")
    }
    ToolScaffold("Essay planner", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Hint("Plan before you write: 3 body paragraphs, each with a point, evidence and an example. In a 3-hour paper spend about 20 minutes on this plan.")
            OutlinedTextField(title, { title = it }, label = { Text("Essay topic") }, modifier = Modifier.fillMaxWidth())
            if (titles.isNotEmpty()) TextButton(onClick = { title = titles.random() }) { Text("Pick a random topic from the Essay app") }
            OutlinedTextField(thesis, { thesis = it }, label = { Text("Thesis statement (your main claim)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            OutlinedTextField(intro, { intro = it }, label = { Text("Introduction: hook and background") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            for (i in 0..2) {
                Heading("Body paragraph ${i + 1}")
                OutlinedTextField(points.value[i], { v -> points.value = points.value.toMutableList().also { it[i] = v } }, label = { Text("Main point") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(evidence.value[i], { v -> evidence.value = evidence.value.toMutableList().also { it[i] = v } }, label = { Text("Evidence (fact, figure, quote)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(examples.value[i], { v -> examples.value = examples.value.toMutableList().also { it[i] = v } }, label = { Text("Example (Pakistan or world)") }, modifier = Modifier.fillMaxWidth())
            }
            OutlinedTextField(counter, { counter = it }, label = { Text("Counter-argument and your reply") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            OutlinedTextField(conclusion, { conclusion = it }, label = { Text("Conclusion: restate and way forward") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            TextActions(prefs, "Essay plan: ${title.ifBlank { "Untitled" }}", plan)
        }
    }
}

// ------------------------------------------------------------------ 12. Thesis and introduction builder
@Composable
fun ThesisBuilderScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val quotes by produceState<List<Triple<String, String, String>>>(emptyList()) {
        value = withContext(Dispatchers.IO) {
            try {
                val arr = JSONObject(asset(ctx, "essay/quotes.json") ?: "{}").optJSONArray("quotes")
                if (arr == null) emptyList() else (0 until arr.length()).map { arr.getJSONObject(it) }.map { Triple(it.optString("text"), it.optString("by"), it.optString("topic")) }
            } catch (e: Exception) { emptyList() }
        }
    }
    var topic by remember { mutableStateOf("") }
    var quote by remember { mutableStateOf<Triple<String, String, String>?>(null) }
    val t = topic.trim().ifBlank { "[topic]" }
    val theses = listOf(
        "$t is a pressing challenge for Pakistan, and addressing it requires coordinated reform of policy, institutions and public attitudes.",
        "Although $t offers some opportunities, its costs outweigh its benefits unless the state acts decisively.",
        "This essay argues that $t is shaped by [cause 1], [cause 2] and [cause 3], and that lasting solutions lie in [solution].",
        "$t can only be understood through its historical roots, its present realities and its future prospects.",
        "Neither [extreme A] nor [extreme B] can resolve $t; a balanced approach is the only workable path.",
    )
    val intros = buildList {
        quote?.let { add("Hook (quote): \"${it.first}\" (${it.second}). These words apply fully to $t.\n[Background: 2 sentences]\n[Thesis]") }
        add("Hook (question): Why does $t continue to shape the future of Pakistan more than almost any other issue?\n[Background: 2 sentences]\n[Thesis]")
        add("Hook (history): The roots of $t go back many decades, and every government since independence has faced it.\n[Background: 2 sentences]\n[Thesis]")
        add("Hook (definition): $t may be defined as [definition]. In Pakistan it appears in the form of [local picture].\n[Background]\n[Thesis]")
        add("Hook (figure): According to [source, year], [statistic] shows how serious $t has become.\n[Background]\n[Thesis]")
    }
    ToolScaffold("Thesis and introduction builder", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(topic, { topic = it }, label = { Text("Topic (for example: climate change in Pakistan)") }, modifier = Modifier.fillMaxWidth())
            Heading("Thesis statements")
            theses.forEach { th ->
                Text(th, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
                TextActions(prefs, "Thesis: $t", th)
            }
            Heading("Introduction plans")
            if (quotes.isNotEmpty()) TextButton(onClick = { quote = quotes.random() }) { Text("Add a quote hook") }
            intros.forEach { it0 ->
                Text(it0, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
                TextActions(prefs, "Introduction plan: $t", it0)
            }
            Hint("Fill the [brackets] yourself and check every fact before using it in the exam.")
        }
    }
}

// ------------------------------------------------------------------ 13. Paragraph builder (PEEL)
@Composable
fun ParagraphScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var point by remember { mutableStateOf("") }
    var evidence by remember { mutableStateOf("") }
    var explain by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    val para = listOf(point, evidence, explain, link).filter { it.isNotBlank() }.joinToString(" ")
    ToolScaffold("Paragraph practice", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Hint("A strong paragraph follows PEEL: Point, Evidence, Explanation, Link. Aim for 120 to 150 words.")
            OutlinedTextField(point, { point = it }, label = { Text("Point: topic sentence") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Hint("Starters: One major cause is...  Another dimension is...  It is widely argued that...")
            OutlinedTextField(evidence, { evidence = it }, label = { Text("Evidence: fact, figure, example") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Hint("Starters: For instance...  According to...  This is evident from...")
            OutlinedTextField(explain, { explain = it }, label = { Text("Explanation: why it matters") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Hint("Starters: This shows that...  As a result...  Consequently...")
            OutlinedTextField(link, { link = it }, label = { Text("Link: back to the thesis or on to the next point") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            if (para.isNotBlank()) {
                Heading("Your paragraph (${wc(para)} words)")
                Text(para, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
                Hint(
                    when {
                        wc(para) < 80 -> "A little short. Add detail to the evidence or the explanation."
                        wc(para) > 190 -> "Rather long. Think about splitting it into two paragraphs."
                        else -> "Good length."
                    }
                )
                TextActions(prefs, "Paragraph", para)
            }
        }
    }
}

// ------------------------------------------------------------------ 14. Writing timer with pace guide
@Composable
fun WriteTimerScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var minutes by remember { mutableIntStateOf(180) }
    var target by remember { mutableIntStateOf(1500) }
    var running by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    var left by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    LaunchedEffect(running) {
        if (running) {
            while (left > 0 && running) { delay(1000); left -= 1 }
            if (running) { running = false; done = true }
        }
    }
    // Phases as shares of the total time.
    val phases = listOf("Plan and outline" to 0.12, "Introduction" to 0.10, "Body paragraphs" to 0.50, "Conclusion" to 0.10, "Review and fix" to 0.18)
    val total = minutes * 60
    val used = total - left
    var acc = 0.0
    var current = phases.last().first
    var phaseEnd = total
    for ((name, share) in phases) {
        acc += share * total
        if (used < acc) { current = name; phaseEnd = acc.toInt(); break }
    }
    val writingMinutes = minutes * (1 - phases.first().second - phases.last().second)
    val expectedWords = if (used <= phases.first().second * total) 0 else (target * ((used - phases.first().second * total) / (writingMinutes * 60)).coerceIn(0.0, 1.0)).toInt()
    ToolScaffold("Writing timer", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!running && !done) {
                Hint("Practise a full paper with phase-by-phase pacing: plan, introduction, body, conclusion, review.")
                Heading("Total time")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(60, 120, 180).forEach { m -> FilterChip(selected = minutes == m, onClick = { minutes = m }, label = { Text("${m / 60} h") }) }
                }
                Heading("Target length")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(800, 1200, 1500, 2000).forEach { n -> FilterChip(selected = target == n, onClick = { target = n }, label = { Text("$n words") }) }
                }
                phases.forEach { (n, s) -> Text("$n: ${(s * minutes).toInt()} min", fontSize = 13.sp) }
                Button(onClick = { text = ""; left = minutes * 60; done = false; running = true }, modifier = Modifier.fillMaxWidth()) { Text("Start") }
            } else {
                if (running) {
                    Text("%d:%02d left".format(left / 60, left % 60), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Now: $current (until %d:%02d on the clock)".format((total - phaseEnd) / 60, (total - phaseEnd) % 60), fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                    val w = wc(text)
                    Text(
                        "$w words written; pace target now about $expectedWords of $target",
                        fontSize = 13.sp, color = if (w + 50 < expectedWords) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    )
                } else {
                    Heading("Finished: ${wc(text)} words")
                }
                OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 14)
                if (running) {
                    Button(onClick = { running = false; done = true }, modifier = Modifier.fillMaxWidth()) { Text("Finish") }
                } else {
                    TextActions(prefs, "Essay: timed writing", text)
                    WritingReport(text)
                    Button(onClick = { done = false }, modifier = Modifier.fillMaxWidth()) { Text("New session") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 15. Linking words
private val LINKING = listOf(
    "Adding" to listOf("moreover", "furthermore", "in addition", "besides", "not only ... but also", "what is more"),
    "Contrast" to listOf("however", "nevertheless", "on the other hand", "in contrast", "although", "whereas", "despite this"),
    "Cause and result" to listOf("consequently", "as a result", "therefore", "thus", "hence", "owing to", "due to"),
    "Example" to listOf("for instance", "for example", "such as", "namely", "to illustrate", "a case in point is"),
    "Emphasis" to listOf("indeed", "in fact", "undoubtedly", "above all", "notably", "particularly"),
    "Sequence" to listOf("firstly", "secondly", "finally", "subsequently", "meanwhile", "to begin with", "in the end"),
    "Concluding" to listOf("in conclusion", "to sum up", "in short", "on the whole", "all things considered", "taken together"),
)

@Composable
fun LinkingWordsScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    ToolScaffold("Linking words", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Hint("Tap a word or phrase to copy it, then paste it into your essay.")
            LINKING.forEach { (cat, list) ->
                Heading(cat)
                androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    list.forEach { w ->
                        FilterChip(selected = false, onClick = { clip.setText(AnnotatedString(w)); Toast.makeText(ctx, "Copied: $w", Toast.LENGTH_SHORT).show() }, label = { Text(w) })
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 16. Quotes bank
@Composable
fun QuotesBankScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val base by produceState<List<Triple<String, String, String>>>(emptyList()) {
        value = withContext(Dispatchers.IO) {
            try {
                val arr = JSONObject(asset(ctx, "essay/quotes.json") ?: "{}").optJSONArray("quotes")
                if (arr == null) emptyList() else (0 until arr.length()).map { arr.getJSONObject(it) }.map { Triple(it.optString("text"), it.optString("by"), it.optString("topic")) }
            } catch (e: Exception) { emptyList() }
        }
    }
    val clip = LocalClipboardManager.current
    var topic by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    var nt by remember { mutableStateOf("") }
    var nb by remember { mutableStateOf("") }
    var ntopic by remember { mutableStateOf("") }
    val mine = prefs.recs("qmine").map { Triple(it.a, it.b, it.c) }
    val all = mine + base
    val topics = all.map { it.third }.filter { it.isNotBlank() }.distinct().sorted()
    val shown = all.filter { topic.isEmpty() || it.third == topic }
    ToolScaffold("Quotes bank", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Hint("Quotes from the Essay app, plus your own. Check the exact wording of a quote before using it in the exam.")
            androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = topic.isEmpty(), onClick = { topic = "" }, label = { Text("All") })
                topics.forEach { t -> FilterChip(selected = topic == t, onClick = { topic = t }, label = { Text(t) }) }
            }
            if (!adding) Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add my own quote") }
            else {
                OutlinedTextField(nt, { nt = it }, label = { Text("Quote") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(nb, { nb = it }, label = { Text("Said by") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(ntopic, { ntopic = it }, label = { Text("Topic") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    if (nt.isNotBlank()) prefs.addRec("qmine", HubRec(System.currentTimeMillis(), nt.trim(), nb.trim(), ntopic.trim(), "", 0, System.currentTimeMillis()))
                    nt = ""; nb = ""; ntopic = ""; adding = false
                }, modifier = Modifier.fillMaxWidth()) { Text("Save quote") }
            }
            Hint("${shown.size} quotes")
            shown.forEach { (text, by, t) ->
                SoftCard(Modifier.fillMaxWidth(), onClick = { clip.setText(AnnotatedString("\"$text\" ($by)")) }) {
                    Column {
                        Text("\"$text\"", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("$by  •  $t  •  tap to copy", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 17. Letter, application and report templates
private val TEMPLATES = listOf(
    "Letter to the editor" to """The Editor
[Newspaper name]
[City]

Subject: [Issue in one line]

Sir,
Through the columns of your esteemed newspaper, I would like to draw the attention of the authorities to [issue].
[Paragraph 1: describe the problem, where and since when.]
[Paragraph 2: effects on people, with an example or figure.]
[Paragraph 3: your suggestions, two or three clear steps.]
I hope the concerned department will take notice and act soon.

Yours truly,
[Name]
[Address]
[Date]""",
    "Job application" to """The [Designation]
[Organisation]
[Address]

Subject: Application for the post of [post]

Respectfully,
With reference to your advertisement in [newspaper, date], I wish to apply for the post of [post].
I hold [qualification] from [institution] and have [experience].
My main strengths are [skill 1], [skill 2] and [skill 3].
I enclose my CV and copies of my certificates, and I would welcome an interview at your convenience.

Yours obediently,
[Name]
[Contact number]
[Date]""",
    "Complaint to an authority" to """The [Officer], [Department]
[Address]

Subject: Complaint regarding [problem]

Respected Sir,
It is submitted that [problem] has been affecting [area or people] since [date].
[Details: what happened, who is affected, earlier efforts made.]
You are requested to look into the matter personally and to [action wanted] within [time].
Thanking you in anticipation.

Yours faithfully,
[Name and address]
[Date]""",
    "Report" to """REPORT ON [TOPIC]
Prepared for: [reader]    Prepared by: [name]    Date: [date]

1. Introduction
[Purpose and scope in 2 or 3 lines]

2. Findings
[Point 1 with evidence]
[Point 2 with evidence]
[Point 3 with evidence]

3. Analysis
[What the findings mean]

4. Recommendations
[Recommendation 1]
[Recommendation 2]

5. Conclusion
[One short paragraph]""",
    "Notice" to """[ORGANISATION NAME]
NOTICE
Date: [date]

All [students, staff, residents] are informed that [event or decision] will take place on [date] at [time] in [place].
[One line on who must attend or what to bring.]
For further information contact [name and number].

[Name]
[Designation]""",
    "Formal email" to """Subject: [Clear subject line]

Dear [Name or Sir/Madam],

I am writing to [purpose in one sentence].
[Details in 2 or 3 short lines.]
I would be grateful if you could [request] by [date].
Thank you for your time and consideration.

Kind regards,
[Name]
[Position and contact]""",
)

@Composable
fun TemplatesScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var open by remember { mutableStateOf("") }
    ToolScaffold("Writing templates", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Hint("Standard formats for letters, applications, reports, notices and emails. Replace the [brackets] with your own details.")
            TEMPLATES.forEach { (name, body) ->
                SoftCard(Modifier.fillMaxWidth(), onClick = { open = if (open == name) "" else name }) {
                    Column {
                        Text(name, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                        if (open == name) {
                            Spacer(Modifier.height(6.dp))
                            Text(body, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            Spacer(Modifier.height(6.dp))
                            TextActions(prefs, "Template: $name", body)
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 18. Precis checker
private val STOP = setOf(
    "about", "after", "again", "against", "being", "between", "could", "every", "other", "their", "there", "these", "those", "which",
    "while", "would", "should", "where", "because", "through", "during", "before", "under", "still", "such", "only", "also", "very",
    "have", "been", "were", "that", "this", "with", "from", "they", "them", "than", "then", "will", "into", "more", "most", "many",
)

@Composable
fun PrecisCheckerScreen(prefs: HubPrefs, onBack: () -> Unit) {
    var original by remember { mutableStateOf("") }
    var precis by remember { mutableStateOf("") }
    var checked by remember { mutableStateOf(false) }
    ToolScaffold("Precis checker", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(original, { original = it; checked = false }, label = { Text("Original passage") }, modifier = Modifier.fillMaxWidth(), minLines = 6)
            OutlinedTextField(precis, { precis = it; checked = false }, label = { Text("Your precis") }, modifier = Modifier.fillMaxWidth(), minLines = 5)
            Button(onClick = { checked = true }, enabled = original.isNotBlank() && precis.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Check") }
            if (checked) {
                val ow = wc(original)
                val pw = wc(precis)
                val goal = ow / 3
                val diff = pw - goal
                Heading("Length: $pw words (target about $goal, one third of $ow)")
                Text(
                    when {
                        goal == 0 -> ""
                        kotlin.math.abs(diff) <= goal / 10 -> "Within 10% of the target. Good."
                        diff > 0 -> "About $diff words too long. Cut examples and repeated ideas."
                        else -> "About ${-diff} words too short. Check that no main idea is missing."
                    },
                    color = MaterialTheme.colorScheme.onBackground,
                )
                val counts = words(original).map { it.lowercase().trim { c -> !c.isLetter() } }.filter { it.length >= 5 && it !in STOP }
                    .groupingBy { it }.eachCount()
                val keys = counts.entries.sortedByDescending { it.value }.take(12).map { it.key }
                val low = precis.lowercase()
                Heading("Key words of the passage")
                keys.forEach { k -> Text((if (low.contains(k.take(5))) "✔ " else "✘ ") + k, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground) }
                Hint("A cross means the word (or its root) is not in your precis. Not every key word needs to appear, but check that its idea is covered. A precis should be in your own words, in reported speech, with no examples or quotes.")
                WritingReport(precis)
            }
        }
    }
}

// ------------------------------------------------------------------ 20. Essay history and comparison
@Composable
fun EssayHistoryScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val essays = prefs.notes.filter { it.title.startsWith("Essay:") }
    val ratings = prefs.recs("esr")
    var first by remember { mutableStateOf<Long?>(null) }
    var second by remember { mutableStateOf<Long?>(null) }
    fun stats(t: String): List<String> {
        val w = words(t)
        val sentences = t.split(Regex("(?<=[.!?])\\s+")).filter { it.isNotBlank() }
        val unique = w.map { it.lowercase().trim { c -> !c.isLetter() } }.filter { it.isNotEmpty() }.distinct().size
        val paras = t.split(Regex("\\n\\s*\\n")).count { it.isNotBlank() }
        return listOf(
            "Words: ${w.size}", "Sentences: ${sentences.size}",
            "Average sentence: ${if (sentences.isEmpty()) 0 else w.size / sentences.size} words",
            "Different words used: $unique", "Paragraphs: $paras",
        )
    }
    ToolScaffold("My essays", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Hint("Essays saved from Essay practice and the Writing timer appear here. Give each a score out of 10, and tick two to compare them.")
            if (essays.isEmpty()) Text("No saved essays yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            essays.forEach { n ->
                val rating = ratings.firstOrNull { it.id == n.id }?.n ?: 0
                SoftCard(Modifier.fillMaxWidth()) {
                    Column {
                        Text(n.title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                        Text("${wc(n.text)} words" + if (rating > 0) "  •  score $rating/10" else "", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            (1..10).forEach { r ->
                                FilterChip(selected = rating == r, onClick = { prefs.putRec("esr", HubRec(n.id, n.title, "", "", "", r, System.currentTimeMillis())) }, label = { Text("$r") })
                            }
                        }
                        Row {
                            TextButton(onClick = { if (first == n.id) first = null else if (second == n.id) second = null else if (first == null) first = n.id else second = n.id }) {
                                Text(if (n.id == first || n.id == second) "✔ Selected to compare" else "Select to compare")
                            }
                        }
                    }
                }
            }
            val a = essays.firstOrNull { it.id == first }
            val b = essays.firstOrNull { it.id == second }
            if (a != null && b != null) {
                Heading("Comparison")
                Text(a.title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                stats(a.text).forEach { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground) }
                Spacer(Modifier.height(4.dp))
                Text(b.title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                stats(b.text).forEach { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground) }
                val rA = ratings.firstOrNull { it.id == a.id }?.n ?: 0
                val rB = ratings.firstOrNull { it.id == b.id }?.n ?: 0
                if (rA > 0 && rB > 0) Text(if (rB > rA) "The second scored ${rB - rA} higher." else if (rA > rB) "The first scored ${rA - rB} higher." else "Same score.", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

// ------------------------------------------------------------------ 21. Dictation (speech to text)
@Composable
fun DictationScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var lang by remember { mutableStateOf("en-US") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) text = (text + " " + said).trim()
        }
    }
    ToolScaffold("Dictation", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Hint("Speak a few sentences at a time and the text is added below. Uses your phone's speech recognition (Google voice typing); it may need internet.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = lang == "en-US", onClick = { lang = "en-US" }, label = { Text("English") })
                FilterChip(selected = lang == "ur-PK", onClick = { lang = "ur-PK" }, label = { Text("Urdu") })
            }
            Button(onClick = {
                try {
                    launcher.launch(
                        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                    )
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Speech recognition is not available on this phone.", Toast.LENGTH_LONG).show()
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Tap and speak") }
            OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 10, label = { Text("${wc(text)} words") })
            if (text.isNotBlank()) {
                TextActions(prefs, "Essay: dictated draft", text)
                WritingReport(text)
            }
        }
    }
}

// ------------------------------------------------------------------ 22. Model essay reader
@Composable
fun ModelEssayScreen(prefs: HubPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val data by produceState<List<Pair<String, List<JSONObject>>>>(emptyList()) {
        value = withContext(Dispatchers.IO) {
            try {
                val cats = JSONObject(asset(ctx, "essay/essays.json") ?: "{}").optJSONArray("categories")
                if (cats == null) emptyList() else (0 until cats.length()).map { cats.getJSONObject(it) }.map { c ->
                    val es = c.optJSONArray("essays")
                    c.optString("name") to (if (es == null) emptyList() else (0 until es.length()).map { es.getJSONObject(it) })
                }
            } catch (e: Exception) { emptyList() }
        }
    }
    var cat by remember { mutableStateOf("") }
    var essay by remember { mutableStateOf<JSONObject?>(null) }
    var long by remember { mutableStateOf(false) }
    val cur = essay
    if (cur != null) {
        ToolScaffold(cur.optString("title"), { essay = null }) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !long, onClick = { long = false }, label = { Text("Short") })
                    FilterChip(selected = long, onClick = { long = true }, label = { Text("Detailed") })
                }
                val secs = cur.optJSONArray("sections")
                if (secs != null) for (i in 0 until secs.length()) {
                    val s = secs.getJSONObject(i)
                    val h = s.optString("heading")
                    val role = when {
                        h.contains("introduction", true) -> "Role: opens the topic, gives background and states the thesis."
                        h.contains("conclusion", true) -> "Role: sums up the argument and points to the way forward."
                        else -> "Role: develops one main argument with evidence."
                    }
                    SoftCard(Modifier.fillMaxWidth()) {
                        Column {
                            Text(h, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Text(role, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(4.dp))
                            Text(s.optString(if (long) "long" else "short"), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                            val pts = s.optJSONArray("points")
                            if (pts != null) for (j in 0 until pts.length()) {
                                val p = pts.getJSONObject(j)
                                Text("• " + p.optString("heading"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 3.dp))
                            }
                        }
                    }
                }
            }
        }
    } else {
        ToolScaffold("Model essays", onBack) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Hint("Read the essays of the Essay app section by section. Each part shows its role: introduction, argument or conclusion.")
                androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    data.forEach { (name, _) -> FilterChip(selected = cat == name, onClick = { cat = name }, label = { Text(name) }) }
                }
                data.firstOrNull { it.first == cat }?.second?.forEach { e ->
                    SoftCard(Modifier.fillMaxWidth(), onClick = { essay = e }) {
                        Text("${e.optInt("number")}. ${e.optString("title")}", color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    }
}
