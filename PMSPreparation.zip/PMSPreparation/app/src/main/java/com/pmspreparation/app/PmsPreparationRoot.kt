package com.pmspreparation.app

import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Root of the joint app: splash -> (first run: welcome -> onboarding) -> home page, or one full original app.
 * No NavHost on purpose, so each original app keeps its own NavHost, back stack and ViewModels untouched.
 */
@Composable
fun PmsPreparationRoot() {
    val activity = LocalContext.current as ComponentActivity
    val prefs = remember { HubPrefs(activity.applicationContext) }
    var stage by rememberSaveable { mutableStateOf("splash") }   // splash | welcome | onboarding | home
    var currentId by rememberSaveable { mutableStateOf<String?>(null) }
    var screen by rememberSaveable { mutableStateOf("") }   // "" = home page, otherwise settings or a tool
    var tab by rememberSaveable { mutableStateOf("home") }   // bottom bar: home | syllabus
    var showGuide by rememberSaveable { mutableStateOf(false) }
    val current = SUB_APPS.firstOrNull { it.id == currentId }

    // Home-page status bar follows the chosen colour theme.
    val homeBar = hubHeaderColor(HUB_PALETTES[prefs.palette], hubIsDark(prefs)).toArgb()

    // Match the system bars to whatever is on screen.
    DisposableEffect(current?.id, homeBar) {
        val window = activity.window
        if (current?.barStyle == BarStyle.EDGE_TO_EDGE) {
            activity.enableEdgeToEdge()
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            window.statusBarColor = if (current != null) current.statusBar.toArgb() else homeBar
            window.navigationBarColor = (current?.navBar ?: Color.Black).toArgb()
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.isAppearanceLightStatusBars = false
            c.isAppearanceLightNavigationBars = current?.lightNavIcons == true
        }
        onDispose { }
    }

    // Study time: time spent inside an app counts toward today's study time and the weekly report.
    DisposableEffect(current?.id) {
        val id = current?.id
        val start = System.currentTimeMillis()
        onDispose {
            if (id != null) prefs.addTime(id, (System.currentTimeMillis() - start).coerceAtMost(3 * 3_600_000L))
        }
    }
    // Keep the daily reminder armed (alarms are cleared when the phone restarts).
    // Keep the home-screen widget in step with today's progress.
    LaunchedEffect(prefs.todayMs, prefs.streak, prefs.examDay) { HubWidget.refresh(activity.applicationContext); HubCountdownWidget.refresh(activity.applicationContext) }
    LaunchedEffect(prefs.reminderHour) { HubReminder.schedule(activity.applicationContext, prefs.reminderHour) }

    if (current != null) {
        // Each app also handles back itself and calls this when it is on its own dashboard.
        BackHandler { currentId = null }
        current.content { currentId = null }
        return
    }

    // First-time guide appears once, as soon as the home page is shown.
    LaunchedEffect(stage) {
        if (stage == "home" && !prefs.guideSeen) showGuide = true
    }

    HubTheme(prefs) {
        when (stage) {
            "splash" -> HubSplash {
                stage = if (prefs.hasPin) "lock" else if (prefs.onboarded) "home" else "welcome"
            }
            "lock" -> HubLock(prefs) { stage = if (prefs.onboarded) "home" else "welcome" }
            "welcome" -> HubWelcome(prefs) { stage = "onboarding" }
            "onboarding" -> HubOnboarding {
                prefs.finishOnboarding()
                stage = "home"
            }
            else -> {
                BackHandler(enabled = screen != "") { screen = "" }
                val back = { screen = "" }
                val tipText = HubText.TIPS[screen]
                if (tipText != null && screen !in prefs.tipsSeen) {
                    val tipId = screen
                    AlertDialog(
                        onDismissRequest = { prefs.markTip(tipId) },
                        title = { Text("How it works") },
                        text = { Text(tipText) },
                        confirmButton = { TextButton(onClick = { prefs.markTip(tipId) }) { Text("Got it") } },
                    )
                }
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) { Box(Modifier.widthIn(max = 640.dp).fillMaxSize()) {
                when (screen) {
                    "settings" -> HubSettings(
                        prefs,
                        onBack = back,
                        onReplayTour = { screen = ""; stage = "onboarding" },
                        onShowGuide = { screen = ""; showGuide = true },
                    )
                    "notes" -> NotesScreen(prefs, back)
                    "checklist" -> ChecklistScreen(prefs, back)
                    "pomodoro" -> PomodoroScreen(prefs, back)
                    "calendar" -> CalendarScreen(prefs, back)
                    "badges" -> BadgesScreen(prefs, back)
                    "report" -> ReportScreen(prefs, back)
                    "mock" -> MockScreen(prefs, back)
                    "planner" -> PlannerScreen(prefs, back)
                    "revision" -> RevisionScreen(prefs, back)
                    "flashcards" -> FlashcardsScreen(prefs, back)
                    "daily" -> DailyScreen(prefs, back)
                    "timed" -> TimedPaperScreen(prefs, back)
                    "mistakes" -> MistakesScreen(prefs, back)
                    "saved" -> BookmarksScreen(prefs, onOpenId = { id ->
                        if (id == "syllabus") { tab = "syllabus"; screen = "" }
                        else SUB_APPS.firstOrNull { it.id == id }?.let { prefs.updateLastApp(it.id); screen = ""; currentId = it.id }
                    }, onBack = back)
                    "pastpapers" -> PastPapersScreen(prefs, back)
                    "affairs" -> CurrentAffairsScreen(prefs, back)
                    "essay" -> EssayScreen(prefs, back)
                    "timetable" -> TimetableScreen(prefs, back)
                    "prayer" -> PrayerBlocksScreen(prefs, back)
                    "focus" -> FocusScreen(prefs, back)
                    "level" -> LevelScreen(prefs, back)
                    "export" -> ExportScreen(prefs, back)
                    "weak" -> WeakTopicsScreen(prefs, back)
                    "smartplan" -> SmartPlanScreen(prefs, back)
                    "topictest" -> TopicTestScreen(prefs, back)
                    "savedq" -> SavedQuestionsScreen(prefs, back)
                    "recall" -> RecallScreen(prefs, back)
                    "outline" -> OutlineScreen(prefs, back)
                    "precis" -> PrecisScreen(prefs, back)
                    "checker" -> WritingCheckerScreen(prefs, back)
                    "facts" -> FactsScreen(prefs, back)
                    "vquiz" -> VocabQuizScreen(prefs, back)
                    "urdu2en" -> UrduEnglishScreen(prefs, back)
                    "sentfix" -> SentenceFixScreen(prefs, back)
                    "cloze" -> ClozeScreen(prefs, back)
                    "idiomtest" -> IdiomTestScreen(prefs, back)
                    "oneword" -> OneWordScreen(prefs, back)
                    "subjmock" -> SubjectMockScreen(prefs, back)
                    "truefalse" -> TrueFalseScreen(prefs, back)
                    "speed" -> SpeedRoundScreen(prefs, back)
                    "papermark" -> PaperMarkerScreen(prefs, back)
                    "essayplan" -> EssayPlannerScreen(prefs, back)
                    "thesis" -> ThesisBuilderScreen(prefs, back)
                    "paragraph" -> ParagraphScreen(prefs, back)
                    "writetimer" -> WriteTimerScreen(prefs, back)
                    "linking" -> LinkingWordsScreen(prefs, back)
                    "quotes" -> QuotesBankScreen(prefs, back)
                    "templates" -> TemplatesScreen(prefs, back)
                    "precischeck" -> PrecisCheckerScreen(prefs, back)
                    "essayhist" -> EssayHistoryScreen(prefs, back)
                    "dictation" -> DictationScreen(prefs, back)
                    "modelessay" -> ModelEssayScreen(prefs, back)
                    else -> {
                        BackHandler(enabled = tab != "home") { tab = "home" }
                        Scaffold(
                            bottomBar = {
                                NavigationBar {
                                    NavigationBarItem(
                                        selected = tab == "home", onClick = { tab = "home" },
                                        icon = { Icon(Icons.Filled.Home, contentDescription = null) }, label = { Text(HubText.t(prefs, "Home")) },
                                    )
                                    NavigationBarItem(
                                        selected = tab == "syllabus", onClick = { tab = "syllabus" },
                                        icon = { Icon(Icons.Filled.School, contentDescription = null) }, label = { Text(HubText.t(prefs, "Syllabus")) },
                                    )
                                    NavigationBarItem(
                                        selected = tab == "vocab", onClick = { tab = "vocab" },
                                        icon = { Icon(Icons.Filled.MenuBook, contentDescription = null) }, label = { Text(HubText.t(prefs, "Vocabulary")) },
                                    )
                                }
                            },
                        ) { pad ->
                            Box(Modifier.padding(pad)) {
                                if (tab == "syllabus") SyllabusTab(prefs)
                                else if (tab == "vocab") VocabTab(prefs, onOpenApp = { id -> prefs.updateLastApp(id); currentId = id })
                                else HomeHub(
                                    prefs,
                                    onOpen = { app -> prefs.updateLastApp(app.id); currentId = app.id },
                                    onTool = { if (it == "tab:syllabus") tab = "syllabus" else screen = it },
                                )
                            }
                        }
                        if (showGuide) HubGuideDialog {
                            prefs.markGuideSeen()
                            showGuide = false
                        }
                    }
                }
                } }
            }
        }
    }
}
