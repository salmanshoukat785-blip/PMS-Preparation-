package com.pmspreparation.app

import android.graphics.Color as AColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

private val HOME_STATUS_BAR = androidx.compose.ui.graphics.Color(0xFF0B5D3B)

/**
 * Root of the joint app: the home page (cards) or one full original app.
 * No NavHost on purpose, so each original app keeps its own NavHost, back stack and ViewModels untouched.
 */
@Composable
fun PmsPreparationRoot() {
    val activity = LocalContext.current as ComponentActivity
    var currentId by rememberSaveable { mutableStateOf<String?>(null) }
    val current = SUB_APPS.firstOrNull { it.id == currentId }

    // Match the system bars to whatever is on screen.
    DisposableEffect(current?.id) {
        val window = activity.window
        if (current?.barStyle == BarStyle.EDGE_TO_EDGE) {
            activity.enableEdgeToEdge()
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            window.statusBarColor = (current?.statusBar ?: HOME_STATUS_BAR).toArgb()
            window.navigationBarColor = AColor.BLACK
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.isAppearanceLightStatusBars = false
            c.isAppearanceLightNavigationBars = false
        }
        onDispose { }
    }

    if (current == null) {
        HomeHub(onOpen = { currentId = it.id })
    } else {
        // Each app also handles back itself and calls this when it is on its own dashboard.
        BackHandler { currentId = null }
        current.content { currentId = null }
    }
}
