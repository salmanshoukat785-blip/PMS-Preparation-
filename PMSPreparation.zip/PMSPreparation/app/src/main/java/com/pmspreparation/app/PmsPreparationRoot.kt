package com.pmspreparation.app

import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Root of the joint app: splash -> (first run: welcome -> onboarding) -> home page, or one full original app.
 * No NavHost on purpose, so each original app keeps its own NavHost, back stack and ViewModels untouched.
 */
@Composable
fun PmsPreparationRoot() {
    val activity = LocalContext.current as ComponentActivity
    val prefs = remember { HubPrefs(activity.applicationContext) }
    var stage by rememberSaveable { mutableStateOf("splash") }   // splash | welcome | onboarding | home
    var currentId by rememberSaveable { mutableStateOf<String?>(null) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showGuide by rememberSaveable { mutableStateOf(false) }
    val current = SUB_APPS.firstOrNull { it.id == currentId }

    // Home-page status bar follows the chosen colour theme.
    val homeBar = hubHeaderColor(HUB_PALETTES[prefs.palette], hubIsDark(prefs)).toArgb()

    // Match the system bars to whatever is on screen.
    DisposableEffect(current?.id, homeBar) {
        val window = activity.window
        if (current?.barStyle == BarStyle.EDGE_TO_EDGE) {
            activity.enableEdgeToEdge()
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            window.statusBarColor = if (current != null) current.statusBar.toArgb() else homeBar
            window.navigationBarColor = (current?.navBar ?: Color.Black).toArgb()
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.isAppearanceLightStatusBars = false
            c.isAppearanceLightNavigationBars = current?.lightNavIcons == true
        }
        onDispose { }
    }

    if (current != null) {
        // Each app also handles back itself and calls this when it is on its own dashboard.
        BackHandler { currentId = null }
        current.content { currentId = null }
        return
    }

    // First-time guide appears once, as soon as the home page is shown.
    LaunchedEffect(stage) {
        if (stage == "home" && !prefs.guideSeen) showGuide = true
    }

    HubTheme(prefs) {
        when (stage) {
            "splash" -> HubSplash {
                stage = if (prefs.onboarded) "home" else "welcome"
            }
            "welcome" -> HubWelcome(prefs) { stage = "onboarding" }
            "onboarding" -> HubOnboarding {
                prefs.finishOnboarding()
                stage = "home"
            }
            else -> {
                if (showSettings) {
                    BackHandler { showSettings = false }
                    HubSettings(
                        prefs,
                        onBack = { showSettings = false },
                        onReplayTour = { showSettings = false; stage = "onboarding" },
                        onShowGuide = { showSettings = false; showGuide = true },
                    )
                } else {
                    HomeHub(
                        prefs,
                        onOpen = { app -> prefs.setLastApp(app.id); currentId = app.id },
                        onSettings = { showSettings = true },
                    )
                    if (showGuide) HubGuideDialog {
                        prefs.markGuideSeen()
                        showGuide = false
                    }
                }
            }
        }
    }
}
