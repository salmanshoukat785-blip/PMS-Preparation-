package com.pmspreparation.app

import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Root of the joint app: splash -> (first run: welcome -> onboarding) -> home page, or one full original app.
 * No NavHost on purpose, so each original app keeps its own NavHost, back stack and ViewModels untouched.
 */
@Composable
fun PmsPreparationRoot() {
    val activity = LocalContext.current as ComponentActivity
    val prefs = remember { HubPrefs(activity.applicationContext) }
    var stage by rememberSaveable { mutableStateOf("splash") }   // splash | welcome | onboarding | home
    var currentId by rememberSaveable { mutableStateOf<String?>(null) }
    var screen by rememberSaveable { mutableStateOf("") }   // "" = home page, otherwise settings or a tool
    var tab by rememberSaveable { mutableStateOf("home") }   // bottom bar: home | syllabus
    var showGuide by rememberSaveable { mutableStateOf(false) }
    val current = SUB_APPS.firstOrNull { it.id == currentId }

    // Home-page status bar follows the chosen colour theme.
    val homeBar = hubHeaderColor(HUB_PALETTES[prefs.palette], hubIsDark(prefs)).toArgb()

    // Match the system bars to whatever is on screen.
    DisposableEffect(current?.id, homeBar) {
        val window = activity.window
        if (current?.barStyle == BarStyle.EDGE_TO_EDGE) {
            activity.enableEdgeToEdge()
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            window.statusBarColor = if (current != null) current.statusBar.toArgb() else homeBar
            window.navigationBarColor = (current?.navBar ?: Color.Black).toArgb()
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.isAppearanceLightStatusBars = false
            c.isAppearanceLightNavigationBars = current?.lightNavIcons == true
        }
        onDispose { }
    }

    // Study time: time spent inside an app counts toward today's study time and the weekly report.
    DisposableEffect(current?.id) {
        val id = current?.id
        val start = System.currentTimeMillis()
        onDispose {
            if (id != null) prefs.addTime(id, (System.currentTimeMillis() - start).coerceAtMost(3 * 3_600_000L))
        }
    }
    // Keep the daily reminder armed (alarms are cleared when the phone restarts).
    LaunchedEffect(prefs.reminderHour) { HubReminder.schedule(activity.applicationContext, prefs.reminderHour) }

    if (current != null) {
        // Each app also handles back itself and calls this when it is on its own dashboard.
        BackHandler { currentId = null }
        current.content { currentId = null }
        return
    }

    // First-time guide appears once, as soon as the home page is shown.
    LaunchedEffect(stage) {
        if (stage == "home" && !prefs.guideSeen) showGuide = true
    }

    HubTheme(prefs) {
        when (stage) {
            "splash" -> HubSplash {
                stage = if (prefs.hasPin) "lock" else if (prefs.onboarded) "home" else "welcome"
            }
            "lock" -> HubLock(prefs) { stage = if (prefs.onboarded) "home" else "welcome" }
            "welcome" -> HubWelcome(prefs) { stage = "onboarding" }
            "onboarding" -> HubOnboarding {
                prefs.finishOnboarding()
                stage = "home"
            }
            else -> {
                BackHandler(enabled = screen != "") { screen = "" }
                val back = { screen = "" }
                when (screen) {
                    "settings" -> HubSettings(
                        prefs,
                        onBack = back,
                        onReplayTour = { screen = ""; stage = "onboarding" },
                        onShowGuide = { screen = ""; showGuide = true },
                    )
                    "notes" -> NotesScreen(prefs, back)
                    "checklist" -> ChecklistScreen(prefs, back)
                    "pomodoro" -> PomodoroScreen(prefs, back)
                    "calendar" -> CalendarScreen(prefs, back)
                    "badges" -> BadgesScreen(prefs, back)
                    "report" -> ReportScreen(prefs, back)
                    "mock" -> MockScreen(prefs, back)
                    else -> {
                        BackHandler(enabled = tab == "syllabus") { tab = "home" }
                        Scaffold(
                            bottomBar = {
                                NavigationBar {
                                    NavigationBarItem(
                                        selected = tab == "home", onClick = { tab = "home" },
                                        icon = { Icon(Icons.Filled.Home, contentDescription = null) }, label = { Text("Home") },
                                    )
                                    NavigationBarItem(
                                        selected = tab == "syllabus", onClick = { tab = "syllabus" },
                                        icon = { Icon(Icons.Filled.School, contentDescription = null) }, label = { Text("Syllabus") },
                                    )
                                }
                            },
                        ) { pad ->
                            Box(Modifier.padding(pad)) {
                                if (tab == "syllabus") SyllabusTab(prefs)
                                else HomeHub(
                                    prefs,
                                    onOpen = { app -> prefs.updateLastApp(app.id); currentId = app.id },
                                    onTool = { screen = it },
                                )
                            }
                        }
                        if (showGuide) HubGuideDialog {
                            prefs.markGuideSeen()
                            showGuide = false
                        }
                    }
                }
            }
        }
    }
}
