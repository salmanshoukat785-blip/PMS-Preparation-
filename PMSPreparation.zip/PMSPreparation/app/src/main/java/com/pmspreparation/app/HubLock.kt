package com.pmspreparation.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** PIN screen shown at start when the app lock is on. */
@Composable
fun HubLock(prefs: HubPrefs, onUnlock: () -> Unit) {
    val pal = LocalHubPalette.current
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    LaunchedEffect(pin) {
        if (pin.length == 4) {
            if (prefs.checkPin(pin)) onUnlock() else { wrong = true; pin = "" }
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(pal.p, pal.pDark)))) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            AppLogo(80.dp)
            Spacer(Modifier.height(16.dp))
            Text("Enter your PIN", color = Color.White, fontSize = 20.sp)
            Spacer(Modifier.height(4.dp))
            Text(if (wrong) "Wrong PIN, try again" else " ", color = pal.accent, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                repeat(4) { i ->
                    Box(
                        Modifier.size(16.dp).clip(CircleShape)
                            .background(if (i < pin.length) pal.accent else Color.White.copy(alpha = 0.3f))
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
            val keys = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "<"))
            keys.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(vertical = 7.dp)) {
                    row.forEach { k ->
                        if (k.isEmpty()) {
                            Spacer(Modifier.size(68.dp))
                        } else {
                            Button(
                                onClick = {
                                    wrong = false
                                    if (k == "<") pin = pin.dropLast(1) else if (pin.length < 4) pin += k
                                },
                                modifier = Modifier.size(68.dp), shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.18f), contentColor = Color.White),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                            ) { Text(k, fontSize = 24.sp) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Forgot the PIN? Clear this app's data in Android settings.", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
        }
    }
}
