package com.pmspreparation.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import com.pmscss.essay.R

class HubPalette(
    val name: String,
    val p: Color, val pLight: Color, val pDark: Color, val container: Color,
    val accent: Color, val accentLight: Color,
)

/** Colour combinations chosen so text stays readable on both light and dark backgrounds. */
val HUB_PALETTES = listOf(
    HubPalette("Emerald & Gold", Color(0xFF0B5D3B), Color(0xFF1E8A5B), Color(0xFF06251A), Color(0xFFD7EFE2), Color(0xFFF2C14E), Color(0xFFFFF1CC)),
    HubPalette("Ocean Blue & Amber", Color(0xFF0D47A1), Color(0xFF5C9CE6), Color(0xFF0A1F44), Color(0xFFD6E6FB), Color(0xFFFFB74D), Color(0xFFFFE9C7)),
    HubPalette("Maroon & Gold", Color(0xFF7B1E3A), Color(0xFFC85A78), Color(0xFF3A0D1B), Color(0xFFF6D9E1), Color(0xFFF2C14E), Color(0xFFFFF1CC)),
    HubPalette("Royal Purple & Yellow", Color(0xFF4E2A84), Color(0xFF9B7BD1), Color(0xFF22113D), Color(0xFFE5DCF5), Color(0xFFFFCA28), Color(0xFFFFF3C4)),
    HubPalette("Teal & Coral", Color(0xFF00695C), Color(0xFF4DB6AC), Color(0xFF00302B), Color(0xFFD2F1EC), Color(0xFFFF8A65), Color(0xFFFFE3DA)),
)

/** Jameel Noori Nastaleeq, for Urdu text. Also available to any merged app as R.font.jameel_noori_nastaleeq. */
val UrduFont = FontFamily(Font(R.font.jameel_noori_nastaleeq))

/** A copy of the Material typography with [font] used for every text style (for Urdu mode). */
fun Typography.withFont(font: FontFamily): Typography = Typography(
    displayLarge = displayLarge.copy(fontFamily = font), displayMedium = displayMedium.copy(fontFamily = font),
    displaySmall = displaySmall.copy(fontFamily = font), headlineLarge = headlineLarge.copy(fontFamily = font),
    headlineMedium = headlineMedium.copy(fontFamily = font), headlineSmall = headlineSmall.copy(fontFamily = font),
    titleLarge = titleLarge.copy(fontFamily = font), titleMedium = titleMedium.copy(fontFamily = font),
    titleSmall = titleSmall.copy(fontFamily = font), bodyLarge = bodyLarge.copy(fontFamily = font),
    bodyMedium = bodyMedium.copy(fontFamily = font), bodySmall = bodySmall.copy(fontFamily = font),
    labelLarge = labelLarge.copy(fontFamily = font), labelMedium = labelMedium.copy(fontFamily = font),
    labelSmall = labelSmall.copy(fontFamily = font),
)

val FONT_STEPS = listOf(0.85f, 1f, 1.15f, 1.3f)
val FONT_LABELS = listOf("Small", "Normal", "Large", "Extra large")

val LocalHubPalette = staticCompositionLocalOf { HUB_PALETTES[0] }
val LocalHubDark = staticCompositionLocalOf { false }

@Composable
fun hubIsDark(prefs: HubPrefs): Boolean = when (prefs.themeMode) {
    1 -> false
    2 -> true
    else -> isSystemInDarkTheme()
}

fun hubHeaderColor(pal: HubPalette, dark: Boolean): Color = if (dark) pal.pDark else pal.p

@Composable
fun HubTheme(prefs: HubPrefs, content: @Composable () -> Unit) {
    val dark = hubIsDark(prefs)
    val pal = HUB_PALETTES[prefs.palette.coerceIn(0, HUB_PALETTES.lastIndex)]
    val scheme = if (dark) {
        darkColorScheme(
            primary = pal.accent, onPrimary = pal.pDark,
            primaryContainer = pal.p, onPrimaryContainer = pal.accentLight,
            secondary = pal.pLight, onSecondary = pal.pDark,
            background = Color(0xFF0E1511), onBackground = Color(0xFFE8EDE9),
            surface = Color(0xFF17211B), onSurface = Color(0xFFE8EDE9),
            surfaceVariant = Color(0xFF24312A), onSurfaceVariant = Color(0xFFC3CEC7),
        )
    } else {
        lightColorScheme(
            primary = pal.p, onPrimary = Color.White,
            primaryContainer = pal.container, onPrimaryContainer = pal.pDark,
            secondary = pal.pLight, onSecondary = Color.White,
            background = Color(0xFFF7F5EC), onBackground = Color(0xFF1B1F1C),
            surface = Color.White, onSurface = Color(0xFF1B1F1C),
            surfaceVariant = Color(0xFFEAE6D8), onSurfaceVariant = Color(0xFF3F4A43),
        )
    }
    val base = LocalDensity.current
    CompositionLocalProvider(
        LocalHubPalette provides pal,
        LocalHubDark provides dark,
        LocalDensity provides Density(base.density, base.fontScale * FONT_STEPS[prefs.fontStep]),
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
