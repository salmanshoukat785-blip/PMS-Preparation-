package com.pmspreparation.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.pmscss.essay.R
import java.util.Calendar

/** Home-screen widget: streak and today's study progress. Reads the same "hub" preferences as the app. */
class HubWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, build(context)) }
    }

    companion object {
        fun refresh(context: Context) {
            try {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, HubWidget::class.java))
                if (ids.isEmpty()) return
                val views = build(context)
                ids.forEach { manager.updateAppWidget(it, views) }
            } catch (e: Exception) { }
        }

        private fun build(context: Context): RemoteViews {
            val p = context.getSharedPreferences("hub", Context.MODE_PRIVATE)
            val today = epochDayOf(Calendar.getInstance())
            val last = p.getLong("lastDay", -1L)
            val streak = if (last >= today - 1) p.getInt("streak", 0) else 0
            val min = (p.getLong("d_$today", 0L) / 60_000L).toInt()
            val goal = p.getInt("goal", 60).coerceAtLeast(1)
            val views = RemoteViews(context.packageName, R.layout.widget_progress)
            views.setTextViewText(R.id.widget_streak, if (streak == 1) "1 day streak" else "$streak day streak")
            views.setTextViewText(R.id.widget_today, "Today: $min / $goal min")
            views.setProgressBar(R.id.widget_bar, 100, (min * 100 / goal).coerceAtMost(100), false)
            val open = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            return views
        }
    }
}

/** Second home-screen widget: days left until the exam date set in Settings. */
class HubCountdownWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, build(context)) }
    }

    companion object {
        fun refresh(context: Context) {
            try {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, HubCountdownWidget::class.java))
                if (ids.isEmpty()) return
                val views = build(context)
                ids.forEach { manager.updateAppWidget(it, views) }
            } catch (e: Exception) { }
        }

        private fun build(context: Context): RemoteViews {
            val p = context.getSharedPreferences("hub", Context.MODE_PRIVATE)
            val today = epochDayOf(Calendar.getInstance())
            val exam = p.getLong("examDay", -1L)
            val views = RemoteViews(context.packageName, R.layout.widget_countdown)
            if (exam < 0) {
                views.setTextViewText(R.id.countdown_days, "--")
                views.setTextViewText(R.id.countdown_label, "set exam date")
            } else {
                val left = exam - today
                views.setTextViewText(R.id.countdown_days, if (left >= 0) "$left" else "0")
                views.setTextViewText(R.id.countdown_label, if (left == 1L) "day to exam" else "days to exam")
            }
            val open = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(context, 1, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.countdown_root, pi)
            return views
        }
    }
}
