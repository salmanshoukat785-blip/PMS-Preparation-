@file:OptIn(ExperimentalMaterial3Api::class)

package com.pakstudies2.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pakstudies2.app.data.ContentRepository
import com.pakstudies2.app.data.Topic
import com.pakstudies2.app.data.UserStore
import com.pakstudies2.app.translate.s
import com.pakstudies2.app.translate.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun rememberAvailableTopics(): List<Topic> {
    val context = LocalContext.current
    val topics by produceState<List<Topic>>(initialValue = emptyList()) {
        value = withContext(Dispatchers.IO) { ContentRepository.loadAvailableTopics(context) }
    }
    return topics
}

// ───────────────────────── Bookmarks ─────────────────────────

private data class BookmarkItem(val topicId: Int, val topicTitle: String, val index: Int, val heading: String)

@Composable
fun BookmarksScreen(onOpenTopic: (Int) -> Unit, onBack: () -> Unit) {
    val topics = rememberAvailableTopics()
    val items = UserStore.bookmarks.mapNotNull { key ->
        val parts = key.split(":")
        val tid = parts.getOrNull(0)?.toIntOrNull() ?: return@mapNotNull null
        val idx = parts.getOrNull(1)?.toIntOrNull() ?: return@mapNotNull null
        val topic = topics.firstOrNull { it.id == tid } ?: return@mapNotNull null
        val heading = topic.headings.getOrNull(idx) ?: return@mapNotNull null
        BookmarkItem(tid, topic.title, idx, heading.title)
    }.sortedWith(compareBy({ it.topicId }, { it.index }))

    Scaffold(topBar = { StudyTopBar("Bookmarks", onBack) }) { padding ->
        if (items.isEmpty()) {
            Text(
                "No bookmarks yet. Tap ☆ next to a heading to save it here.",
                modifier = Modifier.padding(padding).padding(16.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items, key = { "${it.topicId}:${it.index}" }) { b ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpenTopic(b.topicId) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                "★ ${tr(b.heading)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                "Topic ${b.topicId}: ${tr(b.topicTitle)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Progress ─────────────────────────

@Composable
fun ProgressScreen(onBack: () -> Unit) {
    val topics = rememberAvailableTopics()
    Scaffold(topBar = { StudyTopBar("Progress", onBack) }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(topics, key = { it.id }) { t ->
                val total = t.headings.size
                val done = UserStore.readCount(t.id).coerceAtMost(total)
                val best = UserStore.scores[t.id]
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "Topic ${t.id}: ${tr(t.title)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text("Headings read: $done / $total", style = MaterialTheme.typography.bodyMedium)
                        LinearProgressIndicator(
                            progress = { if (total == 0) 0f else done.toFloat() / total },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "Self Test best score: " + (best?.let { "$it%" } ?: "not attempted"),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
            item {
                OutlinedButton(onClick = { UserStore.resetProgress() }) {
                    Text(s("Reset progress"))
                }
            }
        }
    }
}
