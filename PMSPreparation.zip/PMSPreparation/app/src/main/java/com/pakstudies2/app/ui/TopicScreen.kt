@file:OptIn(ExperimentalMaterial3Api::class)

package com.pakstudies2.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pakstudies2.app.data.ContentRepository
import com.pakstudies2.app.data.Heading
import com.pakstudies2.app.data.Topic
import com.pakstudies2.app.data.UserStore
import com.pakstudies2.app.translate.s
import com.pakstudies2.app.translate.Translator
import com.pakstudies2.app.translate.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val TABS = listOf("Overview", "Headings", "Key Points", "Vocabulary", "MCQs")

@Composable
fun TopicScreen(topicId: Int, onBack: () -> Unit, initialTab: Int = 0) {
    val context = LocalContext.current
    val topic by produceState<Topic?>(initialValue = null, topicId) {
        value = withContext(Dispatchers.IO) { ContentRepository.loadTopic(context, topicId) }
    }
    var tab by rememberSaveable { mutableStateOf(initialTab) }

    LaunchedEffect(topicId) { UserStore.updateLastTopic(topicId) }
    LaunchedEffect(topic, UserStore.language) {
        val t = topic
        if (t != null && UserStore.language == "ur") Translator.prefetch(t)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Topic $topicId", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Text("←", fontSize = 22.sp, color = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            val t = topic
            if (t == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Loading…")
                }
            } else {
                TranslationStatusBar()
                ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                    TABS.forEachIndexed { i, label ->
                        Tab(selected = tab == i, onClick = { tab = i }, text = { Text(s(label)) })
                    }
                }
                when (tab) {
                    0 -> OverviewTab(t)
                    1 -> HeadingsTab(t)
                    2 -> KeyPointsTab(t)
                    3 -> VocabularyTab(t)
                    else -> McqsTab(t)
                }
            }
        }
    }
}

// ───────────────────────── Overview ─────────────────────────

@Composable
private fun OverviewTab(topic: Topic) {
    val subCount = topic.headings.sumOf { it.subs.size }
    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                tr(topic.title),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }
        item {
            Text(
                "${topic.headings.size} headings · $subCount sub-headings · " +
                    "${topic.mcqs.size} MCQs · ${topic.vocab.size} vocabulary words",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        topic.headings.firstOrNull()?.let { first ->
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            s("In brief"),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(tr(first.short), style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
        item {
            Text(
                s("Index"),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
        itemsIndexed(topic.headings) { i, h ->
            Text("${i + 1}. ${tr(h.title)}", style = MaterialTheme.typography.bodyLarge)
        }
    }
}

// ───────────────────────── Headings ─────────────────────────

@Composable
private fun HeadingsTab(topic: Topic) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        itemsIndexed(topic.headings, key = { i, _ -> i }) { i, h ->
            HeadingCard(topicId = topic.id, index = i, heading = h)
        }
    }
}

@Composable
private fun HeadingCard(topicId: Int, index: Int, heading: Heading) {
    val number = index + 1
    var open by rememberSaveable { mutableStateOf(false) }
    val bookmarked = UserStore.isBookmarked(topicId, index)
    val isRead = UserStore.key(topicId, index) in UserStore.read
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        open = !open
                        if (open) UserStore.markRead(topicId, index)
                    }
                    .padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    (if (isRead) "✓ " else "") + "$number. ${tr(heading.title)}",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                TextButton(onClick = { UserStore.toggleBookmark(topicId, index) }) {
                    Text(
                        if (bookmarked) "★" else "☆",
                        fontSize = 22.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                Text(if (open) "▴" else "▾", fontSize = 18.sp, modifier = Modifier.padding(end = 10.dp))
            }
            if (open) {
                Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp)) {
                    val note = UserStore.noteFor(topicId, index)
                    var editingNote by remember { mutableStateOf(false) }
                    TextButton(onClick = { editingNote = true }) {
                        Text("📝 " + s(if (note.isEmpty()) "Note" else "Edit note"))
                    }
                    if (note.isNotEmpty()) {
                        Text(
                            note,
                            modifier = Modifier.padding(bottom = 8.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    if (editingNote) {
                        NoteDialog(
                            headingTitle = tr(heading.title),
                            initial = note,
                            onSave = { UserStore.saveNote(topicId, index, it) },
                            onDismiss = { editingNote = false }
                        )
                    }
                    ShortLongBlock(heading.short, heading.long)
                    heading.subs.forEach { sub ->
                        HorizontalDivider(Modifier.padding(vertical = 10.dp))
                        SubHeadingBlock(sub.title, sub.short, sub.long)
                    }
                }
            }
        }
    }
}

@Composable
private fun SubHeadingBlock(title: String, short: String, long: String) {
    var open by rememberSaveable { mutableStateOf(false) }
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { open = !open }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "◆ ${tr(title)}",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )
            Text(if (open) "▴" else "▾", fontSize = 16.sp)
        }
        if (open) {
            ShortLongBlock(short, long)
        }
    }
}

/** Short / Long toggle used for every heading and sub-heading. */
@Composable
private fun ShortLongBlock(short: String, long: String) {
    var showLong by rememberSaveable { mutableStateOf(false) }
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !showLong,
                onClick = { showLong = false },
                label = { Text(s("Short")) }
            )
            FilterChip(
                selected = showLong,
                onClick = { showLong = true },
                label = { Text(s("Long")) }
            )
        }
        Text(
            tr(if (showLong) long else short),
            modifier = Modifier.padding(top = 8.dp),
            style = MaterialTheme.typography.bodyLarge,
            lineHeight = 24.sp
        )
    }
}

// ───────────────────────── Key points ─────────────────────────

@Composable
private fun KeyPointsTab(topic: Topic) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(topic.keyPoints) { _, kp ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(12.dp)) {
                    if (kp.term.isNotEmpty()) {
                        Text(
                            tr(kp.term),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(tr(kp.text), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

// ───────────────────────── MCQs (practice, instant feedback) ─────────────────────────

@Composable
private fun McqsTab(topic: Topic) {
    val picks = remember(topic.id) {
        mutableStateListOf<Int>().apply { repeat(topic.mcqs.size) { add(-1) } }
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        itemsIndexed(topic.mcqs) { i, q ->
            McqCard(
                number = i + 1,
                mcq = q,
                selected = picks[i],
                reveal = true,
                onSelect = { picks[i] = it }
            )
        }
    }
}

// ───────────────────────── Vocabulary ─────────────────────────

@Composable
private fun VocabularyTab(topic: Topic) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(topic.vocab) { _, v ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        v.en,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        v.ur,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyLarge,
                        fontSize = 18.sp
                    )
                }
            }
        }
    }
}
