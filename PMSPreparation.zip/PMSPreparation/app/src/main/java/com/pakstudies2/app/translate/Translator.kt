package com.pakstudies2.app.translate

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.setValue
import com.google.android.gms.tasks.Task
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import com.pakstudies2.app.data.UserStore
import android.content.Context
import com.pakstudies2.app.data.Topic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.io.File
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * English -> Urdu translation with ML Kit.
 * The language model (about 30 MB) is downloaded once; after that translation works offline.
 * Results are cached in memory, so each text is translated only once per app run.
 */
object Translator {
    private val client by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.URDU)
                .build()
        )
    }

    private val cache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val downloadLock = Mutex()
    private val translateLock = Mutex()
    private var modelReady = false

    // Observable status for the status bar
    var downloading by mutableStateOf(false)
        private set
    var pending by mutableStateOf(0)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    /** Changes on every retry so that failed texts are translated again. */
    var retryTick by mutableStateOf(0)
        private set

    fun cached(text: String): String? = cache[text]

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var diskFile: File? = null
    private var unsaved = 0
    private var prefetchJob: Job? = null

    /** Loads translations saved on the device, so texts translated once appear instantly later. */
    fun init(context: Context) {
        if (diskFile != null) return
        val f = File(context.applicationContext.filesDir, "translations_v1.json")
        diskFile = f
        scope.launch {
            try {
                if (f.exists()) {
                    val o = JSONObject(f.readText(Charsets.UTF_8))
                    synchronized(cache) {
                        o.keys().forEach { k -> cache.putIfAbsent(k, o.getString(k)) }
                    }
                }
            } catch (_: Exception) {
            }
            retryTick++ // let screens pick up what was loaded
            if (UserStore.language == "ur") ensureModel() // warm up the model early
        }
    }

    private fun saveToDisk() {
        val f = diskFile ?: return
        try {
            val o = JSONObject()
            synchronized(cache) { cache.forEach { (k, v) -> o.put(k, v) } }
            f.writeText(o.toString(), Charsets.UTF_8)
            unsaved = 0
        } catch (_: Exception) {
        }
    }

    /**
     * Translates a whole topic quietly in the background (short answers first, then long ones)
     * so that screens open instantly. It pauses while the user is waiting for a visible text.
     */
    fun prefetch(topic: Topic) {
        prefetchJob?.cancel()
        prefetchJob = scope.launch {
            val first = ArrayList<String>()
            val second = ArrayList<String>()
            topic.headings.forEach { h ->
                first.add(h.title); first.add(h.short); second.add(h.long)
                h.subs.forEach { sb -> first.add(sb.title); first.add(sb.short); second.add(sb.long) }
            }
            topic.keyPoints.forEach { k -> second.add(k.text) }
            for (t in first + second) {
                if (!isActive) return@launch
                if (t.isBlank() || cache.containsKey(t)) continue
                while (pending > 0 && isActive) delay(150) // visible texts first
                if (error != null) return@launch
                if (translate(t, background = true) == null) return@launch
            }
            saveToDisk()
        }
    }

    fun retry() {
        error = null
        retryTick++
    }

    private suspend fun ensureModel(): Boolean {
        if (modelReady) return true
        return downloadLock.withLock {
            if (modelReady) return@withLock true
            downloading = true
            try {
                client.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                modelReady = true
                true
            } catch (e: Exception) {
                error = "Could not download the Urdu model. Check your internet connection."
                false
            } finally {
                downloading = false
            }
        }
    }

    /** ML Kit works best on short inputs, so long answers are translated piece by piece. */
    private const val MAX_CHUNK = 350

    private fun splitText(text: String): List<String> {
        val out = ArrayList<String>()
        for (line in text.split("\n")) {
            if (line.length <= MAX_CHUNK) { out.add(line); continue }
            // split a long line at sentence ends, then at spaces
            val sentences = line.split(Regex("(?<=[.;:!?])\\s+"))
            var cur = StringBuilder()
            fun flush() { if (cur.isNotEmpty()) { out.add(cur.toString()); cur = StringBuilder() } }
            for (sen in sentences) {
                var part = sen
                while (part.length > MAX_CHUNK) {
                    var cut = part.lastIndexOf(' ', MAX_CHUNK)
                    if (cut <= 0) cut = MAX_CHUNK
                    flush(); out.add(part.substring(0, cut)); part = part.substring(cut).trim()
                }
                if (cur.length + part.length + 1 > MAX_CHUNK) flush()
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(part)
            }
            flush()
        }
        return out
    }

    private suspend fun translatePiece(piece: String): String? {
        if (piece.isBlank()) return piece
        cache[piece]?.let { return it }
        return translateLock.withLock {
            cache[piece] ?: try {
                client.translate(piece).await().also { synchronized(cache) { cache[piece] = it }; unsaved++ }
            } catch (e: Exception) {
                null
            }
        }
    }

    /** Returns the Urdu text, or null when translation failed (see [error]). */
    suspend fun translate(text: String, background: Boolean = false): String? {
        cache[text]?.let { return it }
        if (!background) pending++
        try {
            if (!ensureModel()) return null
            val pieces = splitText(text)
            val sb = StringBuilder()
            var failed = false
            pieces.forEachIndexed { i, piece ->
                val t = translatePiece(piece)
                if (t == null) failed = true
                if (i > 0) sb.append("\n")
                sb.append(t ?: piece)
            }
            if (failed) {
                error = "Translation failed."
                return null
            }
            val result = sb.toString()
            cache[text] = result
            return result
        } finally {
            if (!background) pending--
            if (pending == 0 && unsaved > 0) scope.launch(Dispatchers.IO) { saveToDisk() }
        }
    }

    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
        addOnSuccessListener { cont.resume(it) }
        addOnFailureListener { cont.resumeWithException(it) }
    }
}

/**
 * Returns [text] unchanged in English mode. In Urdu mode it returns the ML Kit translation
 * (the English text is shown until the translation is ready).
 */
@Composable
fun tr(text: String): String {
    if (UserStore.language != "ur" || text.isBlank()) return text
    val tick = Translator.retryTick
    val result by produceState<String?>(Translator.cached(text), text, tick) {
        if (value == null) value = Translator.translate(text)
    }
    return result ?: text
}
