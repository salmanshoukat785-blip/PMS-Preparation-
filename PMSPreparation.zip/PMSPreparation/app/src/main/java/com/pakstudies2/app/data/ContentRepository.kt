package com.pakstudies2.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Loads all study content from JSON files in assets.
 *  - syllabus.json  : sections A/B/C and their topic list
 *  - topic_<id>.json: full content of one topic (added as new topics are written)
 */
object ContentRepository {

    private fun readAsset(context: Context, name: String): String =
        context.assets.open("pakstudies2/" + name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    fun loadSections(context: Context): List<Section> {
        val root = JSONObject(readAsset(context, "syllabus.json"))
        val arr = root.getJSONArray("sections")
        return arr.objects().map { s ->
            Section(
                id = s.getString("id"),
                title = s.getString("title"),
                topics = s.getJSONArray("topics").objects().map { t ->
                    TopicRef(
                        id = t.getInt("id"),
                        title = t.getString("title"),
                        available = t.optBoolean("available", false)
                    )
                }
            )
        }
    }

    fun loadTopic(context: Context, id: Int): Topic? {
        return try {
            val o = JSONObject(readAsset(context, "topic_$id.json"))
            Topic(
                id = o.getInt("id"),
                title = o.getString("title"),
                headings = o.getJSONArray("headings").objects().map { h ->
                    Heading(
                        title = h.getString("title"),
                        short = h.getString("short"),
                        long = h.getString("long"),
                        subs = h.getJSONArray("subs").objects().map { s ->
                            SubHeading(
                                s.getString("title"),
                                s.getString("short"),
                                s.getString("long")
                            )
                        }
                    )
                },
                keyPoints = o.getJSONArray("keyPoints").objects().map {
                    KeyPoint(it.getString("term"), it.getString("text"))
                },
                vocab = o.getJSONArray("vocab").objects().map {
                    VocabItem(it.getString("en"), it.getString("ur"))
                },
                mcqs = o.getJSONArray("mcqs").objects().map { q ->
                    Mcq(
                        question = q.getString("q"),
                        options = q.getJSONArray("options").strings(),
                        answer = q.getInt("answer"),
                        explanation = q.getString("explanation")
                    )
                },
                references = o.getJSONArray("references").objects().map {
                    Reference(it.getString("text"), it.optString("url", ""))
                }
            )
        } catch (e: Exception) {
            null
        }
    }

    fun loadTimeline(context: Context): List<TimelineEvent> {
        return try {
            val root = JSONObject(readAsset(context, "timeline.json"))
            root.getJSONArray("events").objects().map { e ->
                TimelineEvent(
                    year = e.getInt("year"),
                    title = e.getString("title"),
                    detail = e.getString("detail"),
                    topicId = e.optInt("topic", 0)
                )
            }.sortedBy { it.year }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** MCQs of one topic (topicId > 0) or a random mix from every available topic (topicId == 0). */
    fun buildQuestions(context: Context, topicId: Int, mixSize: Int = 10): List<Mcq> {
        return if (topicId > 0) {
            loadTopic(context, topicId)?.mcqs.orEmpty().shuffled()
        } else {
            loadSections(context)
                .flatMap { it.topics }
                .filter { it.available }
                .flatMap { loadTopic(context, it.id)?.mcqs.orEmpty() }
                .shuffled()
                .take(mixSize)
        }
    }

    fun loadAvailableTopics(context: Context): List<Topic> =
        availableTopics(context).mapNotNull { loadTopic(context, it.id) }

    fun availableTopics(context: Context): List<TopicRef> =
        loadSections(context).flatMap { it.topics }.filter { it.available }

    private fun JSONArray.objects(): List<JSONObject> =
        (0 until length()).map { getJSONObject(it) }

    private fun JSONArray.strings(): List<String> =
        (0 until length()).map { getString(it) }
}
