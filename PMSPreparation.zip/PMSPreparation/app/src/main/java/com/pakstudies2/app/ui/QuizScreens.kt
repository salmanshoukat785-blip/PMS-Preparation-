@file:OptIn(ExperimentalMaterial3Api::class)

package com.pakstudies2.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pakstudies2.app.data.ContentRepository
import com.pakstudies2.app.data.Mcq
import com.pakstudies2.app.data.TopicRef
import com.pakstudies2.app.data.UserStore
import com.pakstudies2.app.translate.s
import com.pakstudies2.app.translate.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun StudyTopBar(title: String, onBack: (() -> Unit)?) {
    TopAppBar(
        title = { Text(s(title), fontWeight = FontWeight.Bold) },
        navigationIcon = {
            if (onBack != null) {
                TextButton(onClick = onBack) {
                    Text("←", fontSize = 22.sp, color = Color.White)
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.primary,
            titleContentColor = Color.White
        )
    )
}

// ───────────────────── Self Test: choose a topic ─────────────────────

@Composable
fun SelfTestPicker(onPick: (Int) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val topics by produceState<List<TopicRef>>(initialValue = emptyList()) {
        value = withContext(Dispatchers.IO) { ContentRepository.availableTopics(context) }
    }
    Scaffold(topBar = { StudyTopBar("Self Test", onBack) }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    "Choose a topic. Answers and explanations are shown at the end of the test.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(topics, key = { it.id }) { t ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onPick(t.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Text(
                        "Topic ${t.id}: ${tr(t.title)}",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }
}

// ───────────────────── Quiz (Self Test and Random Mix) ─────────────────────

/**
 * @param topicId 0 = random mix from all available topics
 * @param immediateFeedback true: show right/wrong after each answer (Random Mix);
 *                          false: only at the end (Self Test)
 */
@Composable
fun QuizScreen(
    topicId: Int,
    title: String,
    immediateFeedback: Boolean,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var attempt by remember { mutableStateOf(0) }
    val questions by produceState<List<Mcq>?>(initialValue = null, topicId, attempt) {
        value = null
        value = withContext(Dispatchers.IO) { ContentRepository.buildQuestions(context, topicId) }
    }

    Scaffold(topBar = { StudyTopBar(title, onBack) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TranslationStatusBar()
            Box(Modifier.fillMaxSize()) {
                val qs = questions
                when {
                    qs == null -> Text(s("Loading…"), Modifier.padding(16.dp))
                    qs.isEmpty() -> Text("No questions available yet.", Modifier.padding(16.dp))
                    else -> QuizBody(
                        scoreTopicId = if (immediateFeedback) 0 else topicId,
                        questions = qs,
                        immediateFeedback = immediateFeedback,
                        onRestart = { attempt++ },
                        onBack = onBack
                    )
                }
            }
        }
    }
}

@Composable
private fun QuizBody(
    scoreTopicId: Int,
    questions: List<Mcq>,
    immediateFeedback: Boolean,
    onRestart: () -> Unit,
    onBack: () -> Unit
) {
    var index by remember(questions) { mutableStateOf(0) }
    var finished by remember(questions) { mutableStateOf(false) }
    val answers = remember(questions) {
        mutableStateListOf<Int>().apply { repeat(questions.size) { add(-1) } }
    }

    if (finished) {
        ResultView(scoreTopicId, questions, answers, onRestart, onBack)
        return
    }

    val last = index == questions.size - 1
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Question ${index + 1} of ${questions.size}",
            style = MaterialTheme.typography.labelLarge
        )
        LinearProgressIndicator(
            progress = { (index + 1f) / questions.size },
            modifier = Modifier.fillMaxWidth()
        )
        McqCard(
            number = index + 1,
            mcq = questions[index],
            selected = answers[index],
            reveal = immediateFeedback,
            onSelect = { answers[index] = it }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!immediateFeedback && index > 0) {
                OutlinedButton(onClick = { index-- }) { Text(s("Previous")) }
            }
            Button(
                onClick = { if (last) finished = true else index++ },
                enabled = answers[index] != -1
            ) {
                Text(s(if (last) "Finish" else "Next"))
            }
        }
    }
}

@Composable
private fun ResultView(
    scoreTopicId: Int,
    questions: List<Mcq>,
    answers: List<Int>,
    onRestart: () -> Unit,
    onBack: () -> Unit
) {
    val score = questions.indices.count { answers[it] == questions[it].answer }
    val percent = score * 100 / questions.size
    LaunchedEffect(Unit) { UserStore.saveScore(scoreTopicId, percent) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(s("Result"), style = MaterialTheme.typography.labelLarge)
                Text(
                    "$score / ${questions.size}  ($percent%)",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onRestart) { Text(s("Try again")) }
            OutlinedButton(onClick = onBack) { Text(s("Back")) }
        }

        val wrong = questions.indices.filter { answers[it] != questions[it].answer }
        if (wrong.isNotEmpty()) {
            Text(
                "Review (${wrong.size} incorrect)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            wrong.forEach { i ->
                val q = questions[i]
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            "${i + 1}. ${tr(q.question)}",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Your answer: " + (answers[i].takeIf { it >= 0 }?.let { tr(q.options[it]) } ?: "none"),
                            color = Color(0xFFB3261E)
                        )
                        Text(
                            "Correct answer: ${tr(q.options[q.answer])}",
                            color = Color(0xFF0B5D3B),
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(tr(q.explanation), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        } else {
            Text("All answers correct.", fontWeight = FontWeight.SemiBold)
        }
    }
}
