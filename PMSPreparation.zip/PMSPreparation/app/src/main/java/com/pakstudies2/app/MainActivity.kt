package com.pakstudies2.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import com.pakstudies2.app.translate.s
import com.pakstudies2.app.ui.NotesScreen
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.pakstudies2.app.data.UserStore
import com.pakstudies2.app.ui.BookmarksScreen
import com.pakstudies2.app.ui.HomeScreen
import com.pakstudies2.app.ui.PakStudiesTheme
import com.pakstudies2.app.ui.ProgressScreen
import com.pakstudies2.app.ui.QuizScreen
import com.pakstudies2.app.ui.SelfTestPicker
import com.pakstudies2.app.ui.SettingsScreen
import com.pakstudies2.app.ui.TimelineScreen
import com.pakstudies2.app.ui.TopicScreen

/** The whole original "Pak-Studies II" app. [onExit] returns to the PMS Preparation home. */
@Composable
fun PakStudies2App(onExit: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    remember {
        UserStore.init(ctx)
        com.pakstudies2.app.translate.Translator.init(ctx)
        true
    }
    PakStudiesTheme {
        App(onExit)
    }
}

private const val HOME = "home"
private const val TOPIC = "topic"
private const val SELF_PICK = "selfpick"
private const val SELF_TEST = "selftest"
private const val MIX = "mix"
private const val TIMELINE = "timeline"
private const val BOOKMARKS = "bookmarks"
private const val PROGRESS = "progress"
private const val SETTINGS = "settings"
private const val NOTES = "notes"

@Composable
fun App(onExit: () -> Unit) {
    // Urdu = right-to-left layout; text size multiplies the system font scale
    val direction = if (UserStore.language == "ur") LayoutDirection.Rtl else LayoutDirection.Ltr
    val base = LocalDensity.current
    val density = Density(base.density, base.fontScale * UserStore.textScale)

    CompositionLocalProvider(
        LocalLayoutDirection provides direction,
        LocalDensity provides density
    ) {
        AppRoutes(onExit)
    }
}

private val MAIN_TABS = listOf(
    Triple(HOME, "Home", "🏠"),
    Triple(NOTES, "My Notes", "📝"),
    Triple(BOOKMARKS, "Bookmarks", "★"),
    Triple(PROGRESS, "Progress", "📈"),
    Triple(SETTINGS, "Settings", "⚙")
)

@Composable
private fun AppRoutes(onExit: () -> Unit) {
    var route by rememberSaveable { mutableStateOf(HOME) }
    val showBottomBar = MAIN_TABS.any { it.first == route }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    MAIN_TABS.forEach { (r, label, icon) ->
                        NavigationBarItem(
                            selected = route == r,
                            onClick = { route = r },
                            icon = { Text(icon) },
                            label = { Text(s(label), maxLines = 1, fontSize = 11.sp) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner)) {
            Routes(route = route, onRoute = { route = it }, onExit = onExit)
        }
    }
}

@Composable
private fun Routes(route: String, onRoute: (String) -> Unit, onExit: () -> Unit) {
    // topic id used by TOPIC and SELF_TEST routes
    var topicId by rememberSaveable { mutableStateOf(0) }
    // tab a topic opens on (1 = Headings, used when coming from Bookmarks)
    var topicTab by rememberSaveable { mutableStateOf(0) }

    BackHandler(enabled = true) {
        if (route == HOME) onExit() else onRoute(if (route == SELF_TEST) SELF_PICK else HOME)
    }

    when (route) {
        TOPIC -> TopicScreen(topicId = topicId, onBack = { onRoute(HOME) }, initialTab = topicTab)
        SELF_PICK -> SelfTestPicker(
            onPick = { topicId = it; onRoute(SELF_TEST) },
            onBack = { onRoute(HOME) }
        )
        SELF_TEST -> QuizScreen(
            topicId = topicId,
            title = "Self Test",
            immediateFeedback = false,
            onBack = { onRoute(SELF_PICK) }
        )
        MIX -> QuizScreen(
            topicId = 0,
            title = "Random Mix",
            immediateFeedback = true,
            onBack = { onRoute(HOME) }
        )
        TIMELINE -> TimelineScreen(onBack = { onRoute(HOME) })
        NOTES -> NotesScreen()
        BOOKMARKS -> BookmarksScreen(
            onOpenTopic = { topicId = it; topicTab = 1; onRoute(TOPIC) },
            onBack = { onRoute(HOME) }
        )
        PROGRESS -> ProgressScreen(onBack = { onRoute(HOME) })
        SETTINGS -> SettingsScreen(onBack = { onRoute(HOME) })
        else -> HomeScreen(
            onOpenTopic = { topicId = it; topicTab = 0; onRoute(TOPIC) },
            onSelfTest = { onRoute(SELF_PICK) },
            onRandomMix = { onRoute(MIX) },
            onTimeline = { onRoute(TIMELINE) },
            onBookmarks = { onRoute(BOOKMARKS) },
            onProgress = { onRoute(PROGRESS) },
            onSettings = { onRoute(SETTINGS) }
        )
    }
}
