package com.pakstudies2.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import com.pakstudies2.app.data.UserStore
import com.pmspreparation.app.UrduFont
import com.pmspreparation.app.withFont
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green = Color(0xFF0B5D3B)
private val GreenContainer = Color(0xFFD7EFE1)

private val Colors = lightColorScheme(
    primary = Green,
    onPrimary = Color.White,
    primaryContainer = GreenContainer,
    onPrimaryContainer = Color(0xFF062E1D),
    secondary = Color(0xFF8A5A00),
    background = Color(0xFFF7F9F7),
    surface = Color.White,
    surfaceVariant = Color(0xFFEAF1EC)
)

@Composable
fun PakStudiesTheme(content: @Composable () -> Unit) {
    val typography = if (UserStore.language == "ur") Typography().withFont(UrduFont) else Typography()
    MaterialTheme(colorScheme = Colors, typography = typography, content = content)
}
