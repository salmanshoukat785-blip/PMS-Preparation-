package com.pakstudies2.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.pakstudies2.app.data.UserStore
import com.pakstudies2.app.translate.Translator
import com.pakstudies2.app.translate.s

/** Shows the state of the Urdu translation. Hidden in English mode. */
@Composable
fun TranslationStatusBar() {
    if (UserStore.language != "ur") return

    val error = Translator.error
    val (message, bg) = when {
        error != null -> error to Color(0xFFF8D7D7)
        Translator.downloading ->
            "Downloading the Urdu language model (first time only)…" to Color(0xFFFFF3CD)
        Translator.pending > 0 -> "Translating to Urdu…" to Color(0xFFFFF3CD)
        else -> "Urdu translation ready" to MaterialTheme.colorScheme.primaryContainer
    }

    Column(Modifier.fillMaxWidth().background(bg)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                message,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF1B1B1B)
            )
            if (error != null) {
                TextButton(onClick = { Translator.retry() }) { Text(s("Retry")) }
            }
        }
        if (error == null && (Translator.downloading || Translator.pending > 0)) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        }
    }
}
