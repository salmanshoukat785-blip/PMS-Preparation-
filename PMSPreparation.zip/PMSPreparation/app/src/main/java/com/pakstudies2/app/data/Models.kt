package com.pakstudies2.app.data

data class SubHeading(val title: String, val short: String, val long: String)

data class Heading(
    val title: String,
    val short: String,
    val long: String,
    val subs: List<SubHeading>
)

data class KeyPoint(val term: String, val text: String)

data class VocabItem(val en: String, val ur: String)

data class Mcq(
    val question: String,
    val options: List<String>,
    val answer: Int,
    val explanation: String
)

data class Reference(val text: String, val url: String)

data class Topic(
    val id: Int,
    val title: String,
    val headings: List<Heading>,
    val keyPoints: List<KeyPoint>,
    val vocab: List<VocabItem>,
    val mcqs: List<Mcq>,
    val references: List<Reference>
)

data class TimelineEvent(
    val year: Int,
    val title: String,
    val detail: String,
    val topicId: Int
)

data class TopicRef(val id: Int, val title: String, val available: Boolean)

data class Section(val id: String, val title: String, val topics: List<TopicRef>)
