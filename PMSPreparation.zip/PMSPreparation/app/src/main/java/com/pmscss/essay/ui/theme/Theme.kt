package com.pmscss.essay.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView

class Palette(
    val name: String,
    val p: Color, val pLight: Color, val pDark: Color, val pc: Color,
    val gold: Color, val goldDark: Color, val goldLight: Color,
)

val PALETTES = listOf(
    Palette("Emerald & Gold", Color(0xFF0B5D3B), Color(0xFF1E8A5B), Color(0xFF06251A), Color(0xFFD7EFE2),
        Color(0xFFF2C14E), Color(0xFFC99A2E), Color(0xFFFFF1CC)),
    Palette("Ocean Blue", Color(0xFF0D47A1), Color(0xFF5C9CE6), Color(0xFF0A1F44), Color(0xFFD6E6FB),
        Color(0xFFFFB74D), Color(0xFFE08A00), Color(0xFFFFE9C7)),
    Palette("Maroon", Color(0xFF7B1E3A), Color(0xFFC85A78), Color(0xFF3A0D1B), Color(0xFFF6D9E1),
        Color(0xFFF2C14E), Color(0xFFC99A2E), Color(0xFFFFF1CC)),
    Palette("Royal Purple", Color(0xFF4E2A84), Color(0xFF9B7BD1), Color(0xFF22113D), Color(0xFFE5DCF5),
        Color(0xFFFFCA28), Color(0xFFC79A00), Color(0xFFFFF3C4)),
)

private fun lightScheme(c: Palette) = lightColorScheme(
    primary = c.p, onPrimary = Paper,
    primaryContainer = c.pc, onPrimaryContainer = c.pDark,
    secondary = c.goldDark, onSecondary = Ink,
    secondaryContainer = c.goldLight, onSecondaryContainer = Ink,
    background = Paper, onBackground = Ink,
    surface = Paper, onSurface = Ink,
    surfaceVariant = Color(0xFFEAE6D8), onSurfaceVariant = Color(0xFF3F4A43),
)

private fun darkScheme(c: Palette) = darkColorScheme(
    primary = c.gold, onPrimary = c.pDark,
    primaryContainer = c.p, onPrimaryContainer = c.goldLight,
    secondary = c.pLight, onSecondary = c.pDark,
    secondaryContainer = c.pDark, onSecondaryContainer = c.pc,
    background = NightBg, onBackground = Color(0xFFE8EDE9),
    surface = NightSurface, onSurface = Color(0xFFE8EDE9),
    surfaceVariant = Color(0xFF24312A), onSurfaceVariant = Color(0xFFC3CEC7),
)

/** themeMode: 0 = follow system, 1 = light, 2 = dark. */
@Composable
fun PMSEssayTheme(themeMode: Int = 0, palette: Int = 0, content: @Composable () -> Unit) {
    val dark = when (themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val pal = PALETTES[palette.coerceIn(0, PALETTES.lastIndex)]
    val scheme = if (dark) darkScheme(pal) else lightScheme(pal)
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as? Activity)?.window
            w?.statusBarColor = scheme.primary.toArgb()
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
