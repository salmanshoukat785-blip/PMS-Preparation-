package com.pmscss.essay.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.material.icons.filled.Delete
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import com.pmscss.essay.data.Bookmarks
import com.pmscss.essay.data.Essay
import com.pmscss.essay.data.Translator
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.data.toOutlineText
import com.pmscss.essay.data.toPlainText

/** Short Detail is shown first; the Long Detail button expands/collapses the long text separately. English / Urdu switch on top. */
@Composable
private fun DetailBlock(title: String, short: String, long: String) {
    var showLong by rememberSaveable { mutableStateOf(false) }
    val urdu = LocalEssayUrdu.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    fun fullText(): String {
        val base = listOf(title, short, long).filter { it.isNotBlank() }.joinToString("\n\n")
        if (!urdu) return base
        val ur = listOf(short, long).filter { it.isNotBlank() }.mapNotNull { Translator.cached(context, it) }
        return if (ur.isEmpty()) base else base + "\n\n" + ur.joinToString("\n\n")
    }
    SelectionContainer {
        Column(Modifier.fillMaxWidth()) {
            if (short.isNotBlank()) {
                Text("Short Detail", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                if (urdu) UrduText(short) else VocabText(short)
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (long.isNotBlank()) {
                    FilledTonalButton(onClick = { showLong = !showLong }) {
                        Text(if (showLong) "Hide Long Detail" else "Long Detail")
                    }
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { clipboard.setText(AnnotatedString(fullText())); toast(context, "Copied") }) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = "Copy")
                }
                IconButton(onClick = { shareText(context, fullText()) }) {
                    Icon(Icons.Filled.Share, contentDescription = "Share")
                }
            }
            AnimatedVisibility(showLong && long.isNotBlank()) {
                Column {
                    Spacer(Modifier.height(4.dp))
                    if (urdu) UrduText(long) else VocabText(long)
                }
            }
        }
    }
}

@Composable
private fun HeadingRow(text: String, expanded: Boolean, onClick: () -> Unit, sub: Boolean, prefix: String = "") {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        TransHeading(text, modifier = Modifier.weight(1f), prefix = prefix,
            style = if (sub) MaterialTheme.typography.titleSmall else MaterialTheme.typography.titleMedium)
        Icon(if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null)
    }
}

@Composable
private fun PointItem(heading: String, short: String, long: String) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 2.dp)) {
            HeadingRow(heading, expanded, { expanded = !expanded }, sub = true, prefix = "➢ ")
            AnimatedVisibility(expanded) { Column(Modifier.padding(bottom = 12.dp)) { DetailBlock(heading, short, long) } }
        }
    }
}

/** All headings and sub-headings of the essay together, without the details. */
@Composable
private fun OutlineTab(essay: Essay, prefs: UserPrefs, showNote: Boolean) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val text = essay.toOutlineText()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            TransHeading(essay.title, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(2.dp))
            Text("Outline · ${essay.sections.size} headings", style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { clipboard.setText(AnnotatedString(text)); toast(context, "Outline copied") }) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Copy")
                }
                OutlinedButton(onClick = { shareText(context, text) }) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Share")
                }
            }
        }
        if (showNote) item {
            OutlinedTextField(
                value = prefs.notes[essay.number] ?: "",
                onValueChange = { prefs.setNote(essay.number, it) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("My note (saved on this phone)") },
                minLines = 2,
            )
        }
        items(essay.sections, key = { it.heading }) { s ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp)) {
                    TransHeading(s.heading, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary)
                    s.points.forEach { p ->
                        Row(Modifier.padding(start = 8.dp, top = 6.dp)) {
                            Text("➢  ", style = MaterialTheme.typography.bodyMedium)
                            TransHeading(p.heading, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

/** Quick-revision view: every heading with its sub-points and their short details, in one scroll. */
@Composable
private fun KeyPointsTab(essay: Essay) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val text = remember(essay.number) {
        buildString {
            append(essay.title).append("\nKey Points\n")
            essay.keyPoints.forEach { append("• ").append(it).append('\n') }
            essay.sections.forEach { sec ->
                append('\n').append(sec.heading).append('\n')
                if (sec.short.isNotBlank()) append(sec.short).append('\n')
                sec.points.forEach { p -> append("• ").append(p.heading); if (p.short.isNotBlank()) append(": ").append(p.short); append('\n') }
            }
        }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            TransHeading(essay.title, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(2.dp))
            Text("Key Points · quick revision", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { clipboard.setText(AnnotatedString(text)); toast(context, "Key points copied") }) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp)); Text("Copy")
                }
                OutlinedButton(onClick = { shareText(context, text) }) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp)); Text("Share")
                }
            }
        }
        if (essay.keyPoints.isNotEmpty()) item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Essay key points", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    essay.keyPoints.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
                }
            }
        }
        items(essay.sections, key = { it.heading }) { sec ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    TransHeading(sec.heading, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary)
                    if (sec.short.isNotBlank()) VocabText(sec.short)
                    sec.points.forEach { p ->
                        Text(
                            buildAnnotatedString {
                                append("➢ ")
                                withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append(p.heading) }
                                if (p.short.isNotBlank()) { append(" — "); append(p.short) }
                            },
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EssayScreen(essay: Essay, bookmarks: Bookmarks, prefs: UserPrefs, onDelete: (() -> Unit)? = null, onBack: () -> Unit) {
    var confirmDelete by remember { mutableStateOf(false) }
    val context = LocalContext.current
    LaunchedEffect(essay.number) { prefs.setLast(essay.number) }
    val read = prefs.isRead(essay.number)
    var urduMode by rememberSaveable { mutableStateOf(prefs.essayLang == 1) }
    var tab by rememberSaveable { mutableStateOf(0) } // 0 = Details, 1 = Key Points, 2 = Outline
    // Essays without Short/Long Detail show only the outline, without tabs.
    val hasDetails = essay.sections.any { sec ->
        sec.short.isNotBlank() || sec.long.isNotBlank() || sec.points.any { it.short.isNotBlank() || it.long.isNotBlank() }
    }
    AppScaffold(
        title = "Essay ${essay.number}", onBack = onBack,
        actions = {
            IconButton(onClick = {
                prefs.toggleRead(essay.number)
                toast(context, if (prefs.isRead(essay.number)) "Marked as read" else "Marked as unread")
            }) {
                Icon(if (read) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                    contentDescription = "Mark as read")
            }
            if (onDelete != null) IconButton(onClick = { confirmDelete = true }) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete essay")
            }
            IconButton(onClick = { shareText(context, essay.toPlainText()) }) {
                Icon(Icons.Filled.Share, contentDescription = "Share essay")
            }
            IconButton(onClick = { bookmarks.toggle(essay.number) }) {
                Icon(if (bookmarks.isBookmarked(essay.number)) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    contentDescription = "Bookmark")
            }
        },
    ) { pad ->
        if (confirmDelete && onDelete != null) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("Delete this essay?") },
                text = { Text("This essay was added by you. It will be removed from the app, and this cannot be undone.") },
                confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Delete") } },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
            )
        }
        CompositionLocalProvider(LocalEssayUrdu provides urduMode) {
        Column(Modifier.padding(pad)) {
            if (essay.source.isNotBlank()) {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Text(essay.source, Modifier.padding(10.dp), style = MaterialTheme.typography.labelMedium)
                }
            }
            Row(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = !urduMode, onClick = { urduMode = false }, label = { Text("English") })
                FilterChip(selected = urduMode, onClick = { urduMode = true }, label = { Text("اردو") })
                if (urduMode) Text("online translation", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }
            if (hasDetails) TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Details") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Key Points") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Outline") })
            }
            if (!hasDetails || tab == 2) {
                OutlineTab(essay, prefs, showNote = !hasDetails)
            } else if (tab == 1) {
                KeyPointsTab(essay)
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { TransHeading(essay.title, style = MaterialTheme.typography.headlineSmall) }
                    item {
                        OutlinedTextField(
                            value = prefs.notes[essay.number] ?: "",
                            onValueChange = { prefs.setNote(essay.number, it) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("My note (saved on this phone)") },
                            minLines = 2,
                        )
                    }
                    items(essay.sections, key = { it.heading }) { s ->
                        var expanded by rememberSaveable { mutableStateOf(false) }
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(horizontal = 16.dp, vertical = 2.dp)) {
                                HeadingRow(s.heading, expanded, { expanded = !expanded }, sub = false)
                                AnimatedVisibility(expanded) {
                                    Column(Modifier.padding(bottom = 14.dp)) {
                                        if (s.short.isNotBlank() || s.long.isNotBlank()) DetailBlock(s.heading, s.short, s.long)
                                        s.points.forEach { p -> PointItem(p.heading, p.short, p.long) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        }
    }
}
