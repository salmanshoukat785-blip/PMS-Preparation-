package com.pmscss.essay.ui

import com.pmspreparation.app.UrduFont
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.data.VocabWord
import kotlin.random.Random

/** Shuffled deck of all words. Words already marked "known" are skipped. */
@Composable
fun FlashcardScreen(words: List<VocabWord>, prefs: UserPrefs, onBack: () -> Unit) {
    val seed = rememberSaveable { Random.nextLong() }
    val deck = remember(seed) { words.shuffled(Random(seed)) }
    var index by rememberSaveable { mutableStateOf(0) }
    var flipped by rememberSaveable { mutableStateOf(false) }

    var i = index
    while (i < deck.size && deck[i].word in prefs.knownWords) i++
    val remaining = deck.drop(i).count { it.word !in prefs.knownWords }

    AppScaffold(title = "Flashcards", onBack = onBack) { pad ->
        if (i >= deck.size) {
            Column(Modifier.fillMaxSize().padding(pad).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center) {
                Text("All done! 🎉", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text("${prefs.knownWords.size} words known, ${prefs.reviewWords.size} to review.")
                Spacer(Modifier.height(16.dp))
                Button(onClick = { index = 0; flipped = false }) { Text("Start again") }
            }
        } else {
            val w = deck[i]
            Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$remaining cards left", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(progress = { if (deck.isEmpty()) 0f else i.toFloat() / deck.size }, modifier = Modifier.fillMaxWidth())
                Card(Modifier.fillMaxWidth().weight(1f).padding(vertical = 16.dp).clickable { flipped = !flipped }) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        if (!flipped) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(w.word, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                Text(w.pos, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.height(24.dp))
                                Text("Tap to reveal", style = MaterialTheme.typography.labelMedium)
                            }
                        } else {
                            Column(Modifier.verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(w.word, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text(w.urdu, style = MaterialTheme.typography.headlineSmall.copy(fontFamily = UrduFont), textAlign = TextAlign.Center)
                                Spacer(Modifier.height(8.dp))
                                Text(w.meaning, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                                if (w.example.isNotBlank()) {
                                    Spacer(Modifier.height(12.dp))
                                    Text("“${w.example}”", style = MaterialTheme.typography.bodySmall, fontStyle = FontStyle.Italic,
                                        textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { prefs.markReview(w.word); index = i + 1; flipped = false }, modifier = Modifier.weight(1f)) {
                        Text("Review again")
                    }
                    Button(onClick = { prefs.markKnown(w.word); index = i + 1; flipped = false }, modifier = Modifier.weight(1f)) {
                        Text("Known")
                    }
                }
            }
        }
    }
}
