package com.pmscss.essay.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.data.VocabWord

@Composable
private fun WordCard(w: VocabWord, prefs: UserPrefs, onEssay: (Int) -> Unit) {
    var open by rememberSaveable(w.word) { mutableStateOf(false) }
    val status = when {
        w.word in prefs.knownWords -> 1
        w.word in prefs.reviewWords -> 2
        else -> 0
    }
    Card(Modifier.fillMaxWidth().clickable { open = !open }) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(w.word, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("  ${w.pos}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    Text(w.urdu, style = MaterialTheme.typography.bodyLarge)
                }
                if (status == 1) Icon(Icons.Filled.CheckCircle, contentDescription = "Known", tint = MaterialTheme.colorScheme.primary)
                if (status == 2) Icon(Icons.Filled.Replay, contentDescription = "Review", tint = MaterialTheme.colorScheme.secondary)
            }
            AnimatedVisibility(open) {
                Column(Modifier.padding(top = 8.dp)) {
                    Text(w.meaning, style = MaterialTheme.typography.bodyMedium)
                    if (w.example.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("“${w.example}”", style = MaterialTheme.typography.bodySmall, fontStyle = FontStyle.Italic)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { if (status == 1) prefs.clearMark(w.word) else prefs.markKnown(w.word) }) { Text("Known") }
                        TextButton(onClick = { if (status == 2) prefs.clearMark(w.word) else prefs.markReview(w.word) }) { Text("Review") }
                        Spacer(Modifier.weight(1f))
                        if (w.essay > 0) TextButton(onClick = { onEssay(w.essay) }) { Text("Essay ${w.essay}") }
                    }
                }
            }
        }
    }
}

@Composable
fun VocabScreen(words: List<VocabWord>, prefs: UserPrefs, onEssay: (Int) -> Unit, onFlashcards: () -> Unit, onBack: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(0) } // 0 all, 1 new, 2 review, 3 known
    val q = query.trim().lowercase()
    val shown = words.filter { w ->
        val okFilter = when (filter) {
            1 -> w.word !in prefs.knownWords && w.word !in prefs.reviewWords
            2 -> w.word in prefs.reviewWords
            3 -> w.word in prefs.knownWords
            else -> true
        }
        okFilter && (q.isEmpty() || w.word.contains(q) || w.meaning.lowercase().contains(q) || w.urdu.contains(q))
    }
    AppScaffold(title = "Vocabulary", onBack = onBack) { pad ->
        Column(Modifier.padding(pad)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${prefs.knownWords.size} known · ${prefs.reviewWords.size} to review", style = MaterialTheme.typography.titleSmall)
                    Text("${words.size} words from your essays", style = MaterialTheme.typography.bodySmall)
                }
                Button(onClick = onFlashcards) { Text("Flashcards") }
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                placeholder = { Text("Search word, meaning or Urdu…") },
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("All", "New", "Review", "Known").forEachIndexed { i, label ->
                    if (filter == i) {
                        Button(onClick = { filter = i }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text(label, maxLines = 1) }
                    } else {
                        OutlinedButton(onClick = { filter = i }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text(label, maxLines = 1) }
                    }
                }
            }
            if (shown.isEmpty()) Text("No words here yet.", Modifier.padding(16.dp))
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.word }) { w -> WordCard(w, prefs, onEssay) }
            }
        }
    }
}
