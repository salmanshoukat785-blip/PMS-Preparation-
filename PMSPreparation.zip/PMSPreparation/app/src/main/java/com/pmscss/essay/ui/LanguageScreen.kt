package com.pmscss.essay.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmscss.essay.data.Idiom
import com.pmscss.essay.data.Quote

private val urduStyle = TextStyle(fontSize = 20.sp, lineHeight = 32.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right)

@Composable
private fun CopyShare(text: String) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    Row {
        IconButton(onClick = { clipboard.setText(AnnotatedString(text)); toast(context, "Copied") }) {
            Icon(Icons.Filled.ContentCopy, contentDescription = "Copy")
        }
        IconButton(onClick = { shareText(context, text) }) {
            Icon(Icons.Filled.Share, contentDescription = "Share")
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun QuotesTab(quotes: List<Quote>) {
    val topics = remember(quotes) { listOf("All") + quotes.map { it.topic }.filter { it.isNotBlank() }.distinct() }
    var topic by rememberSaveable { mutableStateOf("All") }
    val shown = remember(topic, quotes) { if (topic == "All") quotes else quotes.filter { it.topic == topic } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                topics.forEach { t -> FilterChip(selected = topic == t, onClick = { topic = t }, label = { Text(t) }) }
            }
        }
        item { Text("${shown.size} quotes and proverbs. Use one only when it fits the essay and you are sure of the wording.", style = MaterialTheme.typography.bodySmall) }
        items(shown, key = { it.text }) { q ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("“${q.text}”", style = MaterialTheme.typography.titleSmall, fontStyle = FontStyle.Italic)
                    if (q.by.isNotBlank()) Text("— ${q.by}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    if (q.urdu.isNotBlank()) Text(q.urdu, modifier = Modifier.fillMaxWidth(), style = urduStyle)
                    if (q.use.isNotBlank()) Text("Useful for: ${q.use}", style = MaterialTheme.typography.bodySmall)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (q.topic.isNotBlank()) AssistChip(onClick = { topic = q.topic }, label = { Text(q.topic) })
                        Spacer(Modifier.weight(1f))
                        CopyShare("“${q.text}”" + if (q.by.isNotBlank()) " — ${q.by}" else "")
                    }
                }
            }
        }
    }
}

@Composable
private fun IdiomsTab(idioms: List<Idiom>) {
    var type by rememberSaveable { mutableStateOf("All") }
    var query by rememberSaveable { mutableStateOf("") }
    val shown = remember(type, query, idioms) {
        idioms.filter {
            (type == "All" || it.type.equals(type.removeSuffix("s"), ignoreCase = true)) &&
                (query.isBlank() || it.phrase.contains(query, true) || it.meaning.contains(query, true) || it.urdu.contains(query))
        }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Search idioms and phrases") }, singleLine = true)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Idioms", "Phrases").forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) }) }
            }
        }
        item { Text("${shown.size} items", style = MaterialTheme.typography.bodySmall) }
        items(shown, key = { it.phrase }) { i ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(i.phrase, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary)
                        CopyShare("${i.phrase} — ${i.meaning}\n${i.urdu}\nExample: ${i.example}")
                    }
                    if (i.urdu.isNotBlank()) Text(i.urdu, modifier = Modifier.fillMaxWidth(), style = urduStyle)
                    if (i.meaning.isNotBlank()) Text(i.meaning, style = MaterialTheme.typography.bodyMedium)
                    if (i.example.isNotBlank()) Text("“${i.example}”", style = MaterialTheme.typography.bodySmall, fontStyle = FontStyle.Italic)
                }
            }
        }
    }
}

/** Two tabs: Quotes & Proverbs, and Idioms & Phrases (both offline, with Urdu meanings). */
@Composable
fun LanguageScreen(quotes: List<Quote>, idioms: List<Idiom>, initialTab: Int, onBack: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf(initialTab.coerceIn(0, 1)) }
    AppScaffold(title = "Language Bank", onBack = onBack) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Quotes & Proverbs") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Idioms & Phrases") })
            }
            if (tab == 0) QuotesTab(quotes) else IdiomsTab(idioms)
        }
    }
}
