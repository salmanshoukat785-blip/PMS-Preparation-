package com.pmscss.essay.data

import kotlinx.serialization.Serializable

@Serializable
data class VocabWord(
    val word: String,
    val pos: String = "",
    val meaning: String = "",
    val urdu: String = "",
    val example: String = "",
    val essay: Int = 0,
    val heading: String = "",
    val count: Int = 0,
)

@Serializable
data class VocabData(val vocabulary: List<VocabWord> = emptyList())
