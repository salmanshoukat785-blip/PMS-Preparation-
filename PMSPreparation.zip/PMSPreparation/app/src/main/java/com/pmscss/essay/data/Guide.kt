package com.pmscss.essay.data

import kotlinx.serialization.Serializable

@Serializable
data class GuideStep(val title: String, val detail: String)

@Serializable
data class GeneralGuide(
    val title: String,
    val intro: String,
    val outline: List<String> = emptyList(),
    val steps: List<GuideStep> = emptyList(),
    val examTips: List<String> = emptyList(),
    val mistakes: List<String> = emptyList(),
)

@Serializable
data class CategoryGuide(
    val categoryId: Int,
    val name: String,
    val summary: String,
    val steps: List<GuideStep> = emptyList(),
    val keyAreas: List<String> = emptyList(),
    val pakistanContext: List<String> = emptyList(),
    val thesisExample: String = "",
    val conclusionTip: String = "",
    val avoid: List<String> = emptyList(),
)

@Serializable
data class GuideData(val general: GeneralGuide, val categories: List<CategoryGuide> = emptyList())
