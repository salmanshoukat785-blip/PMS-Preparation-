package com.pmscss.essay.ui

import com.pmspreparation.app.UrduFont
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmscss.essay.data.VocabIndex
import com.pmscss.essay.data.VocabWord

/** Provided once from AppNav: whether vocabulary words are underlined (Settings switch). */
val LocalVocabUnderline = compositionLocalOf { true }

private const val TAG = "vocab"
private val WORD = Regex("[A-Za-z]+")

/** Essay text in which vocabulary words are underlined; tapping one shows its Urdu meaning. */
@Composable
fun VocabText(text: String, modifier: Modifier = Modifier, style: TextStyle = MaterialTheme.typography.bodyMedium) {
    if (!LocalVocabUnderline.current) {
        Text(text, modifier = modifier, style = style)
        return
    }
    val context = LocalContext.current
    val index = remember { VocabIndex.get(context) }
    val accent = MaterialTheme.colorScheme.primary
    var selected by remember { mutableStateOf<VocabWord?>(null) }

    val annotated = remember(text, index, accent) {
        buildAnnotatedString {
            val seen = HashSet<String>() // underline each word once per block, to keep the text readable
            var last = 0
            for (m in WORD.findAll(text)) {
                val v = VocabIndex.find(m.value, index) ?: continue
                if (!seen.add(v.word.lowercase())) continue
                append(text.substring(last, m.range.first))
                val start = length
                withStyle(SpanStyle(textDecoration = TextDecoration.Underline, color = accent, fontWeight = FontWeight.Medium)) {
                    append(m.value)
                }
                addStringAnnotation(TAG, v.word.lowercase(), start, length)
                last = m.range.last + 1
            }
            append(text.substring(last))
        }
    }

    ClickableText(
        text = annotated,
        modifier = modifier,
        style = style.copy(color = MaterialTheme.colorScheme.onSurface),
        onClick = { offset ->
            annotated.getStringAnnotations(TAG, offset, offset).firstOrNull()?.let { a ->
                selected = index[a.item]
            }
        },
    )

    selected?.let { w -> VocabDialog(w) { selected = null } }
}

@Composable
private fun VocabDialog(w: VocabWord, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = {
            Text(
                w.word.replaceFirstChar { it.uppercase() } + if (w.pos.isNotBlank()) "  (${w.pos})" else "",
                fontWeight = FontWeight.SemiBold,
            )
        },
        text = {
            Column(Modifier.fillMaxWidth()) {
                if (w.urdu.isNotBlank()) {
                    Text(
                        w.urdu,
                        modifier = Modifier.fillMaxWidth(),
                        style = TextStyle(fontFamily = UrduFont, fontSize = 24.sp, lineHeight = 38.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right),
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Spacer(Modifier.height(10.dp))
                }
                if (w.meaning.isNotBlank()) Text(w.meaning, style = MaterialTheme.typography.bodyMedium)
                if (w.example.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text("“${w.example}”", style = MaterialTheme.typography.bodySmall, fontStyle = FontStyle.Italic)
                }
            }
        },
    )
}
