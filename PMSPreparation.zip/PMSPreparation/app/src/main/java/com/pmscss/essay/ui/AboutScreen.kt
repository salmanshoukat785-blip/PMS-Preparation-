package com.pmscss.essay.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pmscss.essay.R

@Composable
fun AboutScreen(essays: Int, categories: Int, words: Int, guides: Int, onUserGuide: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val version = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
    } catch (e: Exception) { "" }
    AppScaffold(title = "About", onBack = onBack) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(104.dp).clip(CircleShape).background(Color(0xFF0B5D3B))) {
                Image(painterResource(R.drawable.ic_launcher_foreground), contentDescription = null, modifier = Modifier.fillMaxSize())
            }
            Spacer(Modifier.height(12.dp))
            Text("PMS/CSS Essay", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (version.isNotBlank()) Text("Version $version", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(12.dp))
            Text(
                "An offline study companion for Punjab PMS 2027 essay preparation, with outlines, a writing guide and vocabulary.",
                style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("What's inside", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    Text("• $essays essay outlines in $categories categories")
                    Text("• Headings and sub-headings for every essay, with Short and Long Detail for essays 101–125")
                    Text("• $words vocabulary words with Urdu meanings")
                    Text("• $guides essay writing guides")
                    Text("• Bookmarks, notes, search, progress and study streak")
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Privacy", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    Text("The app works fully offline. It needs no account and no internet permission. Your bookmarks, notes and progress stay on your phone.")
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Please note", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    Text("This is a study aid. Verify facts and figures from official sources before using them in an exam. The app is not affiliated with PPSC or any government body.")
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onUserGuide, modifier = Modifier.fillMaxWidth()) { Text("Open User Guide") }
            Spacer(Modifier.height(12.dp))
            Text("Built with Kotlin and Jetpack Compose", style = MaterialTheme.typography.labelSmall)
        }
    }
}
