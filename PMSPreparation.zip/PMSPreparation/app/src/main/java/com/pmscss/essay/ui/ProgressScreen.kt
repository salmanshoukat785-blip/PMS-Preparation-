package com.pmscss.essay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.Category
import com.pmscss.essay.data.UserPrefs

@Composable
private fun StatTile(icon: ImageVector, value: Int, label: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(4.dp))
            Text("$value", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun OverallTab(categories: List<Category>, prefs: UserPrefs, bookmarkCount: Int, totalEssays: Int, vocabTotal: Int) {
    val read = prefs.readSet.size
    val frac = if (totalEssays == 0) 0f else read.toFloat() / totalEssays
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(progress = { frac }, modifier = Modifier.size(96.dp), strokeWidth = 10.dp)
                        Text("${(frac * 100).toInt()}%", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.padding(start = 18.dp)) {
                        Text("Overall Progress", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("$read of $totalEssays essays read", style = MaterialTheme.typography.bodyMedium)
                        Text(if (read == 0) "Start your first essay today!" else "Keep it up!",
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(Icons.Filled.CheckCircle, read, "Read", Modifier.weight(1f))
                StatTile(Icons.Filled.Bookmark, bookmarkCount, "Saved", Modifier.weight(1f))
                StatTile(Icons.Filled.EditNote, prefs.notes.size, "Notes", Modifier.weight(1f))
            }
        }
        item {
            val known = prefs.knownWords.size
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Vocabulary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("$known known · ${prefs.reviewWords.size} to review · $vocabTotal total", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { if (vocabTotal == 0) 0f else known.toFloat() / vocabTotal }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        item { Text("By category", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(categories, key = { it.id }) { cat ->
            val r = cat.essays.count { prefs.isRead(it.number) }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Row {
                        Text(cat.name, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                        Text("$r / ${cat.essays.size}", style = MaterialTheme.typography.labelLarge)
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { if (cat.essays.isEmpty()) 0f else r.toFloat() / cat.essays.size },
                        modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun StreakTab(prefs: UserPrefs) {
    val streak = prefs.streak()
    val week = prefs.weekVisited()
    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(56.dp))
                    Text("$streak ${if (streak == 1) "Day" else "Days"}", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                    Text("Current study streak", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    Text("Open the app every day to keep it going!", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(Icons.Filled.EmojiEvents, prefs.longestStreak(), "Longest streak", Modifier.weight(1f))
                StatTile(Icons.Filled.CalendarMonth, prefs.totalDaysStudied(), "Days studied", Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("This week", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        days.forEachIndexed { i, d ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(d, style = MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.height(6.dp))
                                Box(
                                    Modifier.size(32.dp).clip(CircleShape).background(
                                        if (week[i]) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    if (week[i]) Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.onPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(categories: List<Category>, prefs: UserPrefs, bookmarkCount: Int, totalEssays: Int, vocabTotal: Int, onBack: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }
    AppScaffold(title = "My Progress", onBack = onBack) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Overall") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Study streak") })
            }
            if (tab == 0) OverallTab(categories, prefs, bookmarkCount, totalEssays, vocabTotal) else StreakTab(prefs)
        }
    }
}
