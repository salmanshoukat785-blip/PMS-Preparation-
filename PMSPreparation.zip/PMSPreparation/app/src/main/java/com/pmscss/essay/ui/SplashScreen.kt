package com.pmscss.essay.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pmscss.essay.R
import kotlinx.coroutines.delay

/** Fixed brand colours so the splash looks the same in light and dark mode. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1700)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF0B5D3B)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.ic_launcher_foreground), contentDescription = null, modifier = Modifier.size(180.dp))
            Text("PMS/CSS Essay", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
                color = Color(0xFFF2C14E))
            Spacer(Modifier.height(6.dp))
            Text("Punjab PMS 2027 · Essay Outlines", style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.85f))
        }
    }
}
