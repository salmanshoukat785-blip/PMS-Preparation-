package com.pmscss.essay.data

import android.content.Context

/** Fast word lookup over the bundled vocabulary, used to underline words inside essay text. */
object VocabIndex {
    @Volatile private var map: Map<String, VocabWord>? = null

    fun get(context: Context): Map<String, VocabWord> = map ?: synchronized(this) {
        map ?: Repository.loadVocab(context).vocabulary
            .filter { it.word.isNotBlank() }
            .associateBy { it.word.lowercase() }
            .also { map = it }
    }

    /** Exact match first, then simple plural / tense / adverb endings (reforms, reformed, reforming). */
    fun find(token: String, index: Map<String, VocabWord>): VocabWord? {
        val t = token.lowercase()
        index[t]?.let { return it }
        if (t.length < 5) return null
        val candidates = ArrayList<String>(6)
        if (t.endsWith("ies")) candidates += t.dropLast(3) + "y"
        if (t.endsWith("ied")) candidates += t.dropLast(3) + "y"
        if (t.endsWith("es")) candidates += t.dropLast(2)
        if (t.endsWith("s")) candidates += t.dropLast(1)
        if (t.endsWith("ed")) { candidates += t.dropLast(2); candidates += t.dropLast(1) }
        if (t.endsWith("ing")) { candidates += t.dropLast(3); candidates += t.dropLast(3) + "e" }
        if (t.endsWith("ly")) candidates += t.dropLast(2)
        for (c in candidates) index[c]?.let { return it }
        return null
    }
}
