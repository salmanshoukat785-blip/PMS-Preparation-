package com.pmscss.essay.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmscss.essay.data.Category
import com.pmscss.essay.data.Essay
import kotlinx.coroutines.delay
import kotlin.random.Random

private val DURATIONS = listOf(30, 60, 120, 180)

private fun fmt(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

/**
 * Exam practice: pick a category (or all), get five random topics like in the paper, choose one and write against a countdown.
 * The countdown is based on the clock, so it stays correct even if the screen is locked for a while.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MockTimerScreen(categories: List<Category>, onOpenEssay: (Int) -> Unit, onBack: () -> Unit) {
    val all = remember(categories) { categories.flatMap { it.essays } }
    var phase by rememberSaveable { mutableStateOf(0) }        // 0 setup, 1 choose topic, 2 running, 3 finished
    var catId by rememberSaveable { mutableStateOf(0) }          // 0 = all categories
    var minutes by rememberSaveable { mutableStateOf(180) }
    var seed by rememberSaveable { mutableStateOf(Random.nextLong()) }
    var chosen by rememberSaveable { mutableStateOf(-1) }
    var endAt by rememberSaveable { mutableStateOf(0L) }
    var pausedLeft by rememberSaveable { mutableStateOf(0) }
    var running by rememberSaveable { mutableStateOf(false) }
    var peek by rememberSaveable { mutableStateOf(false) }
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }

    val pool = remember(catId, categories) { if (catId == 0) all else categories.firstOrNull { it.id == catId }?.essays ?: all }
    val picks: List<Essay> = remember(seed, pool) { pool.shuffled(Random(seed)).take(5) }
    val essay = all.firstOrNull { it.number == chosen }

    LaunchedEffect(running) { while (running) { nowMs = System.currentTimeMillis(); delay(500) } }
    val left = if (running) maxOf(0, ((endAt - nowMs + 999) / 1000).toInt()) else pausedLeft
    LaunchedEffect(left, phase) { if (phase == 2 && left <= 0) { running = false; pausedLeft = 0; phase = 3 } }

    val view = LocalView.current
    DisposableEffect(phase) {
        view.keepScreenOn = phase == 2
        onDispose { view.keepScreenOn = false }
    }

    AppScaffold(title = "Mock Timer", onBack = onBack) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (phase) {
                0 -> {
                    Text("Practise like the real paper: you get five topics, choose one and write before the time ends.",
                        style = MaterialTheme.typography.bodyMedium)
                    Text("Category", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = catId == 0, onClick = { catId = 0 }, label = { Text("All") })
                        categories.forEach { c ->
                            FilterChip(selected = catId == c.id, onClick = { catId = c.id }, label = { Text(c.name, maxLines = 1) })
                        }
                    }
                    Text("Time", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DURATIONS.forEach { d ->
                            FilterChip(selected = minutes == d, onClick = { minutes = d },
                                label = { Text(if (d >= 60) "${d / 60} hr" + if (d % 60 != 0) " ${d % 60} min" else "" else "$d min") })
                        }
                    }
                    Text("A 3-hour paper is best split into planning and outline (about 15 to 20 minutes), writing (about 2 hours) and revision (the last 20 to 25 minutes).",
                        style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { seed = Random.nextLong(); phase = 1 }, modifier = Modifier.fillMaxWidth()) { Text("Get topics") }
                }
                1 -> {
                    Text("Choose one topic", style = MaterialTheme.typography.titleMedium)
                    picks.forEach { e ->
                        Card(Modifier.fillMaxWidth().clickable {
                            chosen = e.number; pausedLeft = minutes * 60
                            endAt = System.currentTimeMillis() + pausedLeft * 1000L; nowMs = System.currentTimeMillis()
                            running = true; peek = false; phase = 2
                        }, shape = RoundedCornerShape(16.dp)) {
                            Text("${e.title}", Modifier.padding(16.dp), style = MaterialTheme.typography.titleSmall)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { seed = Random.nextLong() }) { Text("Shuffle topics") }
                        TextButton(onClick = { phase = 0 }) { Text("Back") }
                    }
                }
                2 -> {
                    val total = minutes * 60
                    val frac = if (total == 0) 0f else (total - left).toFloat() / total
                    val stage = when {
                        frac < 0.10f -> "Planning: decode the topic, brainstorm and write the outline"
                        frac < 0.90f -> "Writing: follow your outline, one idea per paragraph"
                        else -> "Revision: check the conclusion, spelling and heading numbers"
                    }
                    Text(essay?.title ?: "", style = MaterialTheme.typography.titleMedium)
                    Text(fmt(left), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.displayMedium.copy(fontSize = 56.sp), fontWeight = FontWeight.Bold,
                        color = if (left <= 600) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    LinearProgressIndicator(progress = { frac.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(8.dp))
                    Text(stage, style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (running) {
                            Button(onClick = { pausedLeft = left; running = false }) { Text("Pause") }
                        } else {
                            Button(onClick = { endAt = System.currentTimeMillis() + pausedLeft * 1000L; nowMs = System.currentTimeMillis(); running = true }) { Text("Resume") }
                        }
                        OutlinedButton(onClick = { running = false; phase = 3 }) { Text("Finish") }
                    }
                    TextButton(onClick = { peek = !peek }) { Text(if (peek) "Hide outline" else "Peek at the outline (hint)") }
                    if (peek && essay != null) {
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                essay.sections.forEach { Text(it.heading, style = MaterialTheme.typography.bodyMedium) }
                            }
                        }
                    }
                }
                else -> {
                    Text("Time is over", style = MaterialTheme.typography.headlineSmall)
                    Text(essay?.title ?: "", style = MaterialTheme.typography.titleMedium)
                    Text("Now compare your essay with the outline, key points and details of this topic and note what you missed.",
                        style = MaterialTheme.typography.bodyMedium)
                    if (essay != null) Button(onClick = { onOpenEssay(essay.number) }, modifier = Modifier.fillMaxWidth()) { Text("Open this essay") }
                    OutlinedButton(onClick = { phase = 0; chosen = -1 }, modifier = Modifier.fillMaxWidth()) { Text("New mock") }
                }
            }
        }
    }
}
