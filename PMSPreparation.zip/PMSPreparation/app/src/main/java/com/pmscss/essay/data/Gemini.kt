package com.pmscss.essay.data

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Generated(val category: String, val sections: List<Section>)

/** Creates a new essay (outline + Short/Long details) from a topic name using the Google Gemini API. */
object Gemini {
    private val json = Json { ignoreUnknownKeys = true }

    private fun prompt(topic: String, categories: List<String>) = """
You are an expert on Pakistan's CSS and Punjab PMS English essay papers. Create study material for the essay topic below, in exactly the pattern used by the PMS/CSS Essay app.

TOPIC: "$topic"

PATTERN
- Exactly 6 numbered main sections in this order: 1. Introduction (2 points); 2. the background or the situation in Pakistan (2 to 3 points); 3. causes or challenges (3 to 5 points); 4. effects or impact (3 to 4 points); 5. solutions, reforms or the way forward (3 to 5 points); 6. Conclusion (1 point). Adapt the section titles to the topic (for example "Causes of Terrorism" instead of "Causes") but keep this order.
- Every section has "short" (1 to 2 sentences, a summary) and "long" (2 to 4 sentences with more detail).
- Every point has "heading" (a short phrase, not a full sentence), "short" (1 sentence) and "long" (2 to 3 sentences with concrete facts).

CONTENT RULES
- Write topic-specific information: facts, causes, effects, Pakistani institutions, laws, articles of the Constitution, programmes and examples. Do NOT write advice about how to write an essay.
- Focus on Pakistan, with short international comparisons where useful.
- Use clear, correct English.
- Use only facts you are confident about. If a number or year is uncertain, use a rounded or hedged form ("about", "more than") or leave it out. Never invent statistics, laws or quotations.

CATEGORY
Choose the best category from this list: ${categories.joinToString("; ")}. If none fits well, invent a short new category name (2 to 4 words, title case).

OUTPUT
Return ONLY valid JSON, with no markdown, in exactly this shape:
{"category":"...","sections":[{"heading":"1. Introduction","short":"...","long":"...","points":[{"heading":"...","short":"...","long":"..."}]}]}
""".trim()

    private fun request(apiKey: String, model: String, text: String): String {
        val body = buildJsonObject {
            putJsonArray("contents") { add(buildJsonObject { putJsonArray("parts") { add(buildJsonObject { put("text", text) }) } }) }
            putJsonObject("generationConfig") {
                put("responseMimeType", "application/json")
                put("temperature", 0.4)
                put("maxOutputTokens", 16000)
                if (model.contains("2.5-flash")) putJsonObject("thinkingConfig") { put("thinkingBudget", 0) }
            }
        }.toString()
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 15_000; c.readTimeout = 150_000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code != 200) {
                val err = c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val msg = try { json.parseToJsonElement(err).jsonObject["error"]?.jsonObject?.get("message")?.let { (it as? JsonPrimitive)?.contentOrNull } } catch (e: Exception) { null }
                throw IOException(
                    when {
                        code == 400 && (msg ?: "").contains("API key", true) -> "The API key is not valid. Please check it in Settings."
                        code == 400 || code == 404 -> "Request rejected (model name may be wrong): ${msg ?: code}"
                        code == 403 -> "This key is not allowed to use the model. ${msg ?: ""}".trim()
                        code == 429 -> "Free limit reached for now. Please wait a few minutes and try again."
                        else -> "Gemini error $code. ${msg ?: ""}".trim()
                    }
                )
            }
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun str(o: JsonObject, k: String) = ((o[k] as? JsonPrimitive)?.contentOrNull ?: "").trim()

    private fun parse(raw: String, topic: String): Generated {
        val root = json.parseToJsonElement(raw).jsonObject
        val text = root["candidates"]?.jsonArray?.firstOrNull()?.jsonObject?.get("content")?.jsonObject
            ?.get("parts")?.jsonArray?.firstOrNull()?.jsonObject?.let { str(it, "text") }
            ?: throw IOException("Gemini returned no text (the topic may have been blocked).")
        val t = text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val i = t.indexOf('{'); val j = t.lastIndexOf('}')
        if (i < 0 || j <= i) throw IOException("The answer was not in the expected format.")
        val obj = json.parseToJsonElement(t.substring(i, j + 1)).jsonObject
        val secs = (obj["sections"] as? JsonArray)?.mapNotNull { it as? JsonObject } ?: emptyList()
        if (secs.size < 4) throw IOException("The answer had too few sections.")
        val sections = secs.mapIndexed { n, s ->
            var h = str(s, "heading")
            if (h.isBlank()) throw IOException("A section had no heading.")
            if (!Regex("^\\d+\\.").containsMatchIn(h)) h = "${n + 1}. $h"
            val pts = (s["points"] as? JsonArray)?.mapNotNull { it as? JsonObject }?.map { p ->
                val ph = str(p, "heading"); val ps = str(p, "short"); val pl = str(p, "long")
                if (ph.isBlank() || ps.isBlank() || pl.isBlank()) throw IOException("A sub-point was incomplete.")
                Point(ph, ps, pl)
            } ?: emptyList()
            val ss = str(s, "short"); val sl = str(s, "long")
            if (pts.isEmpty() || ss.isBlank() || sl.isBlank()) throw IOException("A section was incomplete.")
            Section(h, ss, sl, pts)
        }
        val cat = str(obj, "category").ifBlank { "My Essays" }
        return Generated(cat, sections)
    }

    /** Blocking: run on Dispatchers.IO. Tries twice when the answer is malformed. */
    fun generate(apiKey: String, model: String, topic: String, categories: List<String>): Generated {
        if (apiKey.isBlank()) throw IOException("Please add your Gemini API key in Settings first.")
        var last: IOException? = null
        repeat(2) {
            try { return parse(request(apiKey, model, prompt(topic, categories)), topic) }
            catch (e: IOException) { last = e; if (e.message?.contains("key", true) == true || e.message?.contains("limit", true) == true) throw e }
            catch (e: Exception) { last = IOException("The answer was not in the expected format.") }
        }
        throw last ?: IOException("Could not create the essay.")
    }
}
