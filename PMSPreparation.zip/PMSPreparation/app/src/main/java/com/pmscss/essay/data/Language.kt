package com.pmscss.essay.data

import kotlinx.serialization.Serializable

@Serializable
data class Quote(
    val text: String,
    val by: String = "",
    val topic: String = "",
    val urdu: String = "",
    val use: String = "",
)

@Serializable
data class QuoteData(val quotes: List<Quote> = emptyList())

@Serializable
data class Idiom(
    val phrase: String,
    val type: String = "idiom",
    val urdu: String = "",
    val meaning: String = "",
    val example: String = "",
)

@Serializable
data class IdiomData(val idioms: List<Idiom> = emptyList())
