package com.pmscss.essay.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pmscss.essay.data.EssayData
import com.pmscss.essay.data.search

@Composable
fun SearchScreen(data: EssayData, onEssay: (Int) -> Unit, onBack: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val hits = remember(query) { data.search(query) }
    AppScaffold(title = "Search", onBack = onBack) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                placeholder = { Text("Search titles, headings, details…") },
            )
            if (query.trim().length >= 2 && hits.isEmpty()) {
                Text("No results", Modifier.padding(horizontal = 16.dp))
            }
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(hits) { _, h ->
                    Card(Modifier.fillMaxWidth().clickable { onEssay(h.essay.number) }) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Essay ${h.essay.number}: ${h.essay.title}", style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (h.label != "Essay ${h.essay.number}") Text(h.label, style = MaterialTheme.typography.titleSmall)
                            if (h.snippet.isNotBlank()) Text(h.snippet, style = MaterialTheme.typography.bodySmall, maxLines = 3,
                                overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
