package com.pmscss.essay

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.pmscss.essay.data.Bookmarks
import com.pmscss.essay.data.FONT_SCALES
import com.pmscss.essay.data.Repository
import com.pmscss.essay.data.UserEssays
import com.pmscss.essay.data.UserPrefs
import com.pmscss.essay.ui.AppNav
import com.pmscss.essay.ui.theme.PMSEssayTheme

/** The whole original "PMS/CSS Essay" app (what its MainActivity used to show). [onExit] returns to the PMS Preparation home. */
@Composable
fun EssayApp(onExit: () -> Unit) {
    val appContext = LocalContext.current.applicationContext
    val data = remember { Repository.load(appContext) }
    val vocab = remember { Repository.loadVocab(appContext).vocabulary }
    val guide = remember { Repository.loadGuide(appContext) }
    val prefs = remember { UserPrefs(appContext) }
    val bookmarks = remember { Bookmarks(appContext) }
    val userEssays = remember { UserEssays(appContext) }
    val base = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(base.density, base.fontScale * FONT_SCALES[prefs.fontStep])
    ) {
        PMSEssayTheme(prefs.themeMode, prefs.palette) {
            Surface(Modifier.fillMaxSize()) { AppNav(data, vocab, guide, bookmarks, prefs, userEssays, onExit) }
        }
    }
}
