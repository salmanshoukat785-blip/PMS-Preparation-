package com.pmscss.essay.ui.theme

import androidx.compose.ui.graphics.Color

val Green900 = Color(0xFF06251A)
val Green700 = Color(0xFF0B5D3B)
val Green500 = Color(0xFF1E8A5B)
val Green100 = Color(0xFFD7EFE2)
val Gold500 = Color(0xFFF2C14E)
val Gold700 = Color(0xFFC99A2E)
val Gold100 = Color(0xFFFFF1CC)
val Paper = Color(0xFFF7F5EE)
val Ink = Color(0xFF16201B)
val NightBg = Color(0xFF0F1512)
val NightSurface = Color(0xFF18211C)
