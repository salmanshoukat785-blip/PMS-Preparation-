package com.pmsnotes.pakstudies.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.data.StudyMode
import com.pmsnotes.pakstudies.data.titleIn

@Composable
fun NotesScreen(
    vm: AppViewModel,
    onBack: (() -> Unit)?,
    onTopic: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val sections = vm.data?.sections ?: emptyList()
    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar(vm.mode.label(LocalUr.current), onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    vm.mode.hint(LocalUr.current),
                    fontSize = 13.sp,
                    color = Color(0xFF555555)
                )
            }
            sections.forEach { section ->
                item(key = "section_${section.id}") { SectionHeader(section) }
                items(section.topics, key = { it.id }) { topic ->
                    TopicCard(topic) { onTopic(topic.id) }
                }
            }
        }
    }
}

@Composable
fun BookmarksScreen(
    vm: AppViewModel,
    onTopic: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val saved = vm.allTopics.filter { it.id in vm.bookmarks }
    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar(tr("Bookmarks", "بُک مارکس"))
        if (saved.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    tr("No bookmarks yet.\nTap ☆ inside a topic.", "ابھی کوئی بُک مارک نہیں۔\nکسی موضوع کے اندر ☆ دبائیں۔"),
                    textAlign = TextAlign.Center,
                    fontSize = 16.sp,
                    color = Color(0xFF555555)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(saved, key = { it.id }) { topic ->
                    TopicCard(topic) { onTopic(topic.id) }
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(vm: AppViewModel, modifier: Modifier = Modifier) {
    val sections = vm.data?.sections ?: emptyList()
    val total = vm.allTopics.size
    val done = vm.allTopics.count { it.id in vm.visited }
    val fraction = if (total == 0) 0f else done.toFloat() / total

    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar(tr("Progress", "پیش رفت"))
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(tr("Overall Progress", "مجموعی پیش رفت"), fontWeight = FontWeight.Bold, color = GreenPrimary)
                        Text(
                            tr("$done / $total topics read", "$done / $total موضوعات پڑھے"),
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                        ProgressBar(fraction)
                        Text(
                            tr("Bookmarks: ${vm.bookmarks.size}", "بُک مارکس: ${vm.bookmarks.size}"),
                            fontSize = 14.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
            items(sections, key = { it.id }) { section ->
                val sectionDone = section.topics.count { it.id in vm.visited }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            "${section.id}. ${urdu(section.title, section.titleUr)}",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                        Text(
                            "$sectionDone / ${section.topics.size}",
                            fontSize = 13.sp,
                            color = Color(0xFF555555),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                        ProgressBar(
                            if (section.topics.isEmpty()) 0f else sectionDone.toFloat() / section.topics.size
                        )
                    }
                }
            }
            item {
                Text(
                    tr("A topic counts as read once you open it.", "موضوع کھلتے ہی پڑھا ہوا شمار ہو جاتا ہے۔"),
                    fontSize = 12.sp,
                    color = Color(0xFF777777)
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, modifier: Modifier = Modifier) {
    var confirmReset by remember { mutableStateOf(false) }
    val ur = LocalUr.current
    val options = listOf(
        (if (ur) "چھوٹا" else "Small") to 0.9f,
        (if (ur) "درمیانہ" else "Medium") to 1.0f,
        (if (ur) "بڑا" else "Large") to 1.2f,
        (if (ur) "بہت بڑا" else "Extra Large") to 1.4f
    )

    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar(tr("Settings", "سیٹنگز"))
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(tr("Language", "زبان"), fontWeight = FontWeight.Bold, color = GreenPrimary)
                        listOf("en" to "English", "ur" to "اردو (آن لائن ترجمہ)").forEach { (code, label) ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { vm.updateLang(code) }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = vm.lang == code, onClick = null)
                                Text(label, modifier = Modifier.padding(start = 12.dp))
                            }
                        }
                    }
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(tr("Text size", "متن کا سائز"), fontWeight = FontWeight.Bold, color = GreenPrimary)
                        options.forEach { (label, scale) ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { vm.updateFontScale(scale) }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = vm.fontScale == scale, onClick = null)
                                Text(label, modifier = Modifier.padding(start = 12.dp))
                            }
                        }
                    }
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(tr("Progress and bookmarks", "پیش رفت اور بُک مارکس"), fontWeight = FontWeight.Bold, color = GreenPrimary)
                        Button(
                            onClick = { confirmReset = true },
                            modifier = Modifier.padding(top = 8.dp)
                        ) { Text(tr("Reset", "ری سیٹ کریں")) }
                    }
                }
            }
            item {
                Text(
                    tr("Pak-Studies 1\n${vm.allTopics.size} topics, ${vm.allTopics.sumOf { it.headings.size }} headings. Works offline. Urdu translation needs internet the first time.", "Pak-Studies 1\n${vm.allTopics.size} موضوعات، ${vm.allTopics.sumOf { it.headings.size }} عنوانات۔ آف لائن چلتی ہے۔ اردو ترجمے کے لیے پہلی بار انٹرنیٹ چاہیے۔"),
                    fontSize = 13.sp,
                    color = Color(0xFF666666),
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text(tr("Reset?", "ری سیٹ کریں؟")) },
            text = { Text(tr("Read topics and bookmarks will be cleared.", "پڑھے ہوئے موضوعات اور بُک مارکس مٹ جائیں گے۔")) },
            confirmButton = {
                TextButton(onClick = {
                    vm.resetProgress()
                    confirmReset = false
                }) { Text(tr("Yes", "ہاں")) }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text(tr("No", "نہیں")) }
            }
        )
    }
}
