package com.pmsnotes.pakstudies.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.data.TimelineEvent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimelineScreen(
    vm: AppViewModel,
    onTopic: (Int) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val groups = vm.timeline.groupBy { it.era }
    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar(tr("Timeline", "ٹائم لائن"), onBack)
        if (vm.timeline.isEmpty()) {
            Text(
                tr("No timeline data found.", "ٹائم لائن کا ڈیٹا نہیں ملا۔"),
                modifier = Modifier.padding(16.dp)
            )
            return@Column
        }
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            groups.forEach { (era, events) ->
                item(key = "era-$era") {
                    Text(
                        urdu(era),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(GreenPrimary, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
                items(events, key = { "${it.y}-${it.e.hashCode()}" }) { ev ->
                    EventRow(ev, onTopic)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EventRow(ev: TimelineEvent, onTopic: (Int) -> Unit) {
    Card(
        onClick = { if (ev.t > 0) onTopic(ev.t) },
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Text(
                ev.y,
                modifier = Modifier.width(78.dp),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF6A1B9A)
            )
            Column(Modifier.weight(1f)) {
                Text(urdu(ev.e, ev.eUr), fontSize = 15.sp, lineHeight = 21.sp)
                if (ev.t > 0) {
                    Text(
                        tr("Topic ${ev.t}", "ٹاپک ${ev.t}") + "  " + chev(),
                        fontSize = 12.sp,
                        color = GreenPrimary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}
