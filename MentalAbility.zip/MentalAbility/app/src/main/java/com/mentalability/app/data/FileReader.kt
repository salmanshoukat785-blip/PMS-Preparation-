package com.mentalability.app.data

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

object FileReader {
    /** DOCX se plain text nikalta hai (Gemini DOCX direct nahi leta). */
    fun docxText(bytes: ByteArray): String {
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    return xml.replace("</w:p>", "\n").replace(Regex("<[^>]+>"), "")
                        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                }
                e = zip.nextEntry
            }
        }
        return ""
    }
}
