package com.mentalability.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** level 1 = Main, level 2 = Sub, level 3 = Related (topic). parentId 0 = root. */
@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentId: Long = 0,
    val level: Int = 1
)

@Entity(tableName = "mcqs", indices = [Index(value = ["key"], unique = true)])
data class McqEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val question: String,
    val optionsJson: String,   // JSON array of strings
    val answerIndex: Int,      // 0-based
    val categoryId: Long,      // hamesha level-3 (Related) category
    val key: String            // normalized question, duplicate check ke liye
)

data class CategoryWithCount(val id: Long, val name: String, val level: Int, val count: Int)

// c = category jis ke neeche ke saare MCQs chahiye (khud, bache, pote)
private const val UNDER =
    "(m.categoryId = c.id" +
    " OR m.categoryId IN (SELECT id FROM categories WHERE parentId = c.id)" +
    " OR m.categoryId IN (SELECT id FROM categories WHERE parentId IN (SELECT id FROM categories WHERE parentId = c.id)))"

@Dao
interface AppDao {
    @Query("SELECT c.id AS id, c.name AS name, c.level AS level, (SELECT COUNT(*) FROM mcqs m WHERE " + UNDER + ") AS count FROM categories c WHERE c.parentId = :parentId ORDER BY c.name")
    fun children(parentId: Long): Flow<List<CategoryWithCount>>

    @Query("SELECT m.* FROM mcqs m, categories c WHERE c.id = :id AND " + UNDER)
    suspend fun mcqsUnder(id: Long): List<McqEntity>

    @Query("SELECT * FROM categories")
    suspend fun allCategories(): List<CategoryEntity>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getCategory(id: Long): CategoryEntity?

    @Query("SELECT * FROM categories WHERE parentId = :parentId AND name = :name COLLATE NOCASE LIMIT 1")
    suspend fun findChild(parentId: Long, name: String): CategoryEntity?

    @Insert suspend fun insertCategory(c: CategoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertMcq(m: McqEntity): Long

    @Query("SELECT COUNT(*) FROM mcqs WHERE key = :key")
    suspend fun countKey(key: String): Int
}

@Database(entities = [CategoryEntity::class, McqEntity::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "mental_ability.db")
                .fallbackToDestructiveMigration()
                .build().also { inst = it }
        }
    }
}
