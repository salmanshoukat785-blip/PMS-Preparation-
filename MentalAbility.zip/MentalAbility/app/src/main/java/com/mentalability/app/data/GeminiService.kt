package com.mentalability.app.data

import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import org.json.JSONArray

data class ParsedMcq(
    val question: String, val options: List<String>, val answerIndex: Int,
    val main: String, val sub: String, val topic: String
)

object GeminiService {
    // Agar model band ho jaye to yahan naya Gemini model name likh dena.
    private const val MODEL = "gemini-2.5-flash"

    private val model by lazy {
        Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            MODEL,
            generationConfig = generationConfig { responseMimeType = "application/json" }
        )
    }

    /** taxonomy: maujooda categories, har line "Main > Sub > Related" */
    suspend fun extract(
        bytes: ByteArray?, mime: String?, text: String?, taxonomy: List<String>
    ): List<ParsedMcq> {
        val existing = if (taxonomy.isEmpty()) "(none yet)" else taxonomy.joinToString("\n")
        val prompt = """
Extract ALL multiple-choice questions from the provided file.
Return ONLY a JSON array. Each item:
{"question": string, "options": [strings], "answer": 0-based index of correct option, "main": string, "sub": string, "topic": string}
If the file doesn't mark the correct answer, work it out yourself.

Every MCQ gets a 3-level category:
- "main": broad subject, e.g. English, Math, Science, Urdu, Islamiat, General Knowledge, Computer.
- "sub": a branch inside that subject, e.g. Grammar, Algebra, Physics.
- "topic": the specific related topic, e.g. Tenses, Linear Equations, Motion.
Each name should be 1-3 words, in English.

Existing categories (Main > Sub > Topic):
$existing

Matching rules, applied level by level:
- If the MCQ fits an existing Main, use that exact Main name; otherwise create a new Main.
- Under that Main, if it fits an existing Sub, use that exact name; otherwise create a new Sub.
- Under that Sub, if it fits an existing Topic, use that exact name; otherwise create a new Topic.
Ignore the file name; judge by the MCQ content only.
""".trimIndent()

        val input = content {
            if (bytes != null && mime != null) inlineData(bytes, mime)
            text(if (text != null) "$prompt\n\nFILE CONTENT:\n$text" else prompt)
        }
        val raw = model.generateContent(input).text.orEmpty()
            .trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

        val arr = JSONArray(raw)
        val out = mutableListOf<ParsedMcq>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val opts = o.getJSONArray("options").let { a -> List(a.length()) { a.getString(it) } }
            if (opts.size < 2) continue
            out += ParsedMcq(
                o.getString("question"), opts,
                o.optInt("answer", 0).coerceIn(0, opts.size - 1),
                o.optString("main", "General").ifBlank { "General" }.trim(),
                o.optString("sub", "General").ifBlank { "General" }.trim(),
                o.optString("topic", "General").ifBlank { "General" }.trim()
            )
        }
        return out
    }
}
