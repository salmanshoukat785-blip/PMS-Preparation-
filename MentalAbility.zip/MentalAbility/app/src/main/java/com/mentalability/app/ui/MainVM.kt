package com.mentalability.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mentalability.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray

class MainVM(app: Application) : AndroidViewModel(app) {
    val dao = AppDb.get(app).dao()
    val status = MutableStateFlow<String?>(null)
    val busy = MutableStateFlow(false)

    private suspend fun taxonomyLines(): List<String> {
        val byParent = dao.allCategories().groupBy { it.parentId }
        val lines = mutableListOf<String>()
        for (main in byParent[0L].orEmpty())
            for (sub in byParent[main.id].orEmpty())
                for (topic in byParent[sub.id].orEmpty())
                    lines += "${main.name} > ${sub.name} > ${topic.name}"
        return lines
    }

    private suspend fun getOrCreate(name: String, parentId: Long, level: Int): CategoryEntity {
        val n = name.trim().ifBlank { "General" }
        return dao.findChild(parentId, n) ?: CategoryEntity(
            id = dao.insertCategory(CategoryEntity(name = n, parentId = parentId, level = level)),
            name = n, parentId = parentId, level = level
        )
    }

    fun import(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        busy.value = true
        status.value = "Reading file..."
        try {
            val cr = getApplication<Application>().contentResolver
            val mime = cr.getType(uri) ?: "application/octet-stream"
            val bytes = cr.openInputStream(uri)!!.use { it.readBytes() }
            if (bytes.size > 15 * 1024 * 1024) error("File must be smaller than 15 MB")

            val taxonomy = taxonomyLines()
            val parsed = when {
                mime.contains("wordprocessingml") ->
                    GeminiService.extract(null, null, FileReader.docxText(bytes), taxonomy)
                mime.startsWith("text/") && mime != "text/html" ->
                    GeminiService.extract(null, null, bytes.toString(Charsets.UTF_8), taxonomy)
                else -> GeminiService.extract(bytes, mime, null, taxonomy)
            }
            if (parsed.isEmpty()) { status.value = "No MCQs found in this file"; return@launch }

            val touched = linkedSetOf<String>()
            var added = 0
            var skipped = 0
            for (m in parsed) {
                // Same question (spaces/case/punctuation ignore) pehle se ho to skip
                val key = m.question.lowercase().filter { it.isLetterOrDigit() }
                if (key.isEmpty() || dao.countKey(key) > 0) { skipped++; continue }
                val main = getOrCreate(m.main, 0, 1)
                val sub = getOrCreate(m.sub, main.id, 2)
                val topic = getOrCreate(m.topic, sub.id, 3)
                val id = dao.insertMcq(McqEntity(
                    question = m.question,
                    optionsJson = JSONArray(m.options).toString(),
                    answerIndex = m.answerIndex,
                    categoryId = topic.id,
                    key = key
                ))
                if (id > 0) { added++; touched += "${main.name} > ${sub.name} > ${topic.name}" } else skipped++
            }
            status.value = "$added MCQs added" +
                (if (skipped > 0) ", $skipped duplicates skipped" else "") +
                (if (touched.isNotEmpty()) "\n" + touched.joinToString("\n") else "")
        } catch (e: Exception) {
            status.value = "Error: ${e.message}"
        } finally {
            busy.value = false
        }
    }
}
