package com.mentalability.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mentalability.app.data.CategoryWithCount
import com.mentalability.app.data.McqEntity
import org.json.JSONArray

/** parentId 0 = Main categories, phir Sub, phir Related. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    parentId: Long,
    onOpen: (CategoryWithCount) -> Unit,
    onQuiz: (Long) -> Unit,
    onBack: () -> Unit,
    vm: MainVM = viewModel()
) {
    val items by remember(parentId) { vm.dao.children(parentId) }.collectAsState(emptyList())
    val status by vm.status.collectAsState()
    val busy by vm.busy.collectAsState()
    var crumb by remember { mutableStateOf("Mental Ability") }
    LaunchedEffect(parentId) {
        if (parentId == 0L) { crumb = "Mental Ability"; return@LaunchedEffect }
        val names = mutableListOf<String>()
        var cur = vm.dao.getCategory(parentId)
        while (cur != null) {
            names.add(0, cur.name)
            cur = if (cur.parentId == 0L) null else vm.dao.getCategory(cur.parentId)
        }
        crumb = names.joinToString(" > ")
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.import(uri)
    }
    val total = items.sumOf { it.count }
    val label = when (items.firstOrNull()?.level ?: 1) {
        1 -> "Main categories"
        2 -> "Sub categories"
        else -> "Related categories"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(crumb, maxLines = 2) },
                navigationIcon = { if (parentId != 0L) TextButton(onClick = onBack) { Text("Back") } }
            )
        },
        floatingActionButton = {
            if (parentId == 0L) ExtendedFloatingActionButton(
                onClick = { if (!busy) picker.launch("*/*") },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Upload file") }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (parentId == 0L) {
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                status?.let { Text(it) }
            } else if (total > 0) {
                Button(onClick = { onQuiz(parentId) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Start quiz ($total MCQs)")
                }
            }
            if (items.isEmpty()) Text("No categories yet. Upload a file.")
            else Text(label, style = MaterialTheme.typography.labelLarge)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items) { c ->
                    Card(Modifier.fillMaxWidth().clickable { onOpen(c) }) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.name, style = MaterialTheme.typography.titleMedium)
                                Text("${c.count} MCQs")
                            }
                            Text("›", style = MaterialTheme.typography.headlineSmall)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(categoryId: Long, onBack: () -> Unit, vm: MainVM = viewModel()) {
    val dao = vm.dao
    var title by remember { mutableStateOf("") }
    var mcqs by remember { mutableStateOf<List<McqEntity>?>(null) }
    LaunchedEffect(categoryId) {
        title = dao.getCategory(categoryId)?.name.orEmpty()
        mcqs = dao.mcqsUnder(categoryId).shuffled()
    }
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var round by remember { mutableIntStateOf(0) }

    Scaffold(topBar = {
        TopAppBar(title = { Text(title) }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val list = mcqs
            when {
                list == null -> CircularProgressIndicator()
                index >= list.size -> {
                    Text("Result", style = MaterialTheme.typography.headlineMedium)
                    Text("Score: $score / ${list.size}", style = MaterialTheme.typography.titleLarge)
                    Button(onClick = { index = 0; score = 0; selected = null; round++ }) { Text("Try again") }
                    OutlinedButton(onClick = onBack) { Text("Back") }
                }
                else -> {
                    val q = list[index]
                    val original = JSONArray(q.optionsJson).let { a -> List(a.length()) { a.getString(it) } }
                    // Har baar options shuffle, taake sab answers A/B/C/D na rahein
                    val (opts, correct) = remember(q.id, round) { shuffleOptions(original, q.answerIndex) }
                    Text("Q${index + 1}/${list.size}")
                    Text(q.question, style = MaterialTheme.typography.titleMedium)
                    opts.forEachIndexed { i, o ->
                        val color = when {
                            selected == null -> MaterialTheme.colorScheme.surfaceVariant
                            i == correct -> MaterialTheme.colorScheme.primaryContainer
                            i == selected -> MaterialTheme.colorScheme.errorContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = color),
                            modifier = Modifier.fillMaxWidth().clickable(enabled = selected == null) {
                                selected = i
                                if (i == correct) score++
                            }
                        ) { Text(o, Modifier.padding(14.dp)) }
                    }
                    Spacer(Modifier.weight(1f, false))
                    Button(enabled = selected != null, onClick = { index++; selected = null }) {
                        Text(if (index == list.size - 1) "Finish" else "Next")
                    }
                }
            }
        }
    }
}

/** Options shuffle karta hai. "All of the above" type options ho to order wahi rehta hai. */
private fun shuffleOptions(opts: List<String>, answer: Int): Pair<List<String>, Int> {
    val fixed = opts.any { o ->
        listOf("above", "both", "all of", "none of", "neither").any { o.contains(it, ignoreCase = true) }
    }
    if (fixed) return opts to answer
    val order = opts.indices.shuffled()
    return order.map { opts[it] } to order.indexOf(answer)
}
