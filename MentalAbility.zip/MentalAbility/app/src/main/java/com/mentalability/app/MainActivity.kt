package com.mentalability.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mentalability.app.ui.BrowseScreen
import com.mentalability.app.ui.QuizScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val nav = rememberNavController()
                val longArg = listOf(navArgument("id") { type = NavType.LongType })
                NavHost(nav, startDestination = "browse/0") {
                    composable("browse/{id}", arguments = longArg) {
                        BrowseScreen(
                            parentId = it.arguments!!.getLong("id"),
                            onOpen = { c ->
                                // Related (level 3) par seedha quiz, warna agla level
                                nav.navigate(if (c.level >= 3) "quiz/${c.id}" else "browse/${c.id}")
                            },
                            onQuiz = { id -> nav.navigate("quiz/$id") },
                            onBack = { nav.popBackStack() }
                        )
                    }
                    composable("quiz/{id}", arguments = longArg) {
                        QuizScreen(it.arguments!!.getLong("id"), onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
