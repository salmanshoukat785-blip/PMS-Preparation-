# Mental Ability (Kotlin + Compose + Gemini)

## Setup
1. Firebase Console -> naya project -> Android app add karo, package: `com.mentalability.app`
2. Firebase AI Logic section mein "Gemini Developer API" enable karo
3. `google-services.json` download karke `app/` folder mein rakho
4. Android Studio mein folder open karo -> Sync -> Run

## GitHub se APK
Repo Settings -> Secrets -> `GOOGLE_SERVICES_JSON_BASE64` (file ka base64).
Push karo -> Actions tab -> artifact se APK download.
